"""Petasus additions to authentik's Django settings.

authentik imports this module as data.user_settings when it is mounted at
/data/user_settings.py (authentik/root/settings.py: _update_settings("data.user_settings")).
"""

from django.utils.cache import patch_vary_headers
from django.utils.translation import get_language, get_language_from_request, override


class BrowserLanguageMiddleware:
    """Answer in the browser's language when neither the brand nor the user picked one.

    authentik ships no LocaleMiddleware, so the server-side text of the login page (the
    button, error messages) stays English for every visitor unless the brand pins a single
    locale. HTML pages also get <html lang>, which lets the brand CSS pick its copy.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        user = getattr(request, "user", None)
        pinned = request.brand.default_locale or (
            user is not None and user.is_authenticated and user.locale(request)
        )
        if pinned:
            response = self.get_response(request)
            language = get_language()
        else:
            language = get_language_from_request(request)
            with override(language):
                response = self.get_response(request)
            patch_vary_headers(response, ("Accept-Language",))
        return self._tag_html(response, language)

    @staticmethod
    def _tag_html(response, language):
        if response.streaming or not response.get("Content-Type", "").startswith("text/html"):
            return response
        response.content = response.content.replace(
            b"<html>", f'<html lang="{language}">'.encode(), 1
        )
        return response


MIDDLEWARE = ["data.user_settings.BrowserLanguageMiddleware"]
