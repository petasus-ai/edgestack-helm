# petasus-resource-manager chart

edgespray installs this chart from its own tree, not from this repository:
every change to this directory must be replicated to
`deployments/petasus-resource-manager/` in
[petasus-io/edgespray](https://github.com/petasus-io/edgespray) (branch
`master-cilium`), with the chart `version` kept at plain `3.5.0` (no
`-cilium` suffix). The copy is manual for now; CI automation for that push is
planned.
