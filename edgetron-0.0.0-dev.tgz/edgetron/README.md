# Edgetron
Edgetron is an abstraction layer used for provisioning virtual infrastructure in the purpose of hosting Kubernetes service. Edgetron exposes MM3 interface to MEPM OP for northbound, to southbound, it invokes standarized cluster-api to provision Kubernetes cluster.

## TL;DR;

```console
$ git clone https://gitlab.tde.sktelecom.com/PETASUS/edgetron.git && cd edgetron
$ helm install my-edgetron deployment/edgetron
```

## Introduction

This chart bootstraps a [edgetron](https://gitlab.tde.sktelecom.com/PETASUS/edgetron) deployment on a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

Edgetron charts can be used with [Kubeapps](https://kubeapps.com/) for deployment and management of Helm Charts in clusters. 

## Prerequisites

- Kubernetes 1.12+
- Helm 2.12+ or Helm 3.0-beta3+

## Installing the Chart

To install the chart with the release name `my-edgetron`:

```console
$ helm install my-edgetron deployment/edgetron
```

These commands deploy edgetron on the Kubernetes cluster in the default configuration. The [Parameters](#parameters) section lists the parameters that can be configured during installation.

> **Tip**: List all releases using `helm list`

## Uninstalling the Chart

To uninstall/delete the `my-edgetron` deployment:

```console
$ helm delete my-edgetron
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## Parameters

The following tables lists the configurable parameters of the SONA chart and their default values.
| Parameter                            | Description                                                            | Default                                  |
|--------------------------------------|------------------------------------------------------------------------|------------------------------------------|
| `edgetronImage.registry`             | Edgetron container image registry                                      | `registry.tde.sktelecom.com`             |
| `edgetronImage.repository`           | Edgetron container image repository                                    | `petasus/edgetron`                       |
| `edgetronImage.tag`                  | Edgetron container image tag                                           | `latest`                                 |
| `edgetronImage.pullPolicy`           | Edgetron container image pull policy                                   | `IfNotPresent`                           |
| `edgetronWatcherImage.repository`    | Edgetron watcher container image repository                            | `petasus/edgetron/watcher`               |
| `vmEventImage.repository`            | VM event operator container image repository                           | `petasus/vm-event-operator`              |
| `replicaCount`                       | Edgetron POD replica number                                            | `1`                                      |
| `service.type`                       | Edgetron service type                                                  | `NodePort`                               |
| `service.port`                       | Edgetron service port number                                           | `8080`                                   |
| `service.nodePort`                   | Edgetron service node port number                                      | `30080`                                  |
| `auth.existingSecret`                | Secret with the keys `jwt-secret`, `username`, `password`; the chart then creates none | `""`                     |
| `auth.username`                      | Account ks-apiserver takes edgetron tokens with                        | `edgetron`                               |
| `auth.password`                      | Its password; empty keeps the Secret's current one or generates one    | `""`                                     |
| `auth.jwtSecret`                     | Key edgetron signs tokens with; empty keeps the current one or generates one | `""`                               |
| `auth.accessTokenTTLSeconds`         | Access token lifetime                                                  | `3600`                                   |
| `auth.refreshTokenTTLSeconds`        | Refresh token lifetime                                                 | `86400`                                  |
| `auth.readers`                       | Read-only accounts for other apps in the cluster, `{name, password}` each, kept in the Secret `edgetron-readers`; an empty password keeps the current one or generates one | `[]` |
| `gateway.readOnlyApi`                | Route the API through the Gateway for read-only accounts (login, GET, placement dry-runs) | `true`                |
| `networkPolicy.enabled`              | Let only ks-apiserver, the Gateway and `extraIngressFrom` reach edgetron | `true`                                 |
| `networkPolicy.apiserver.namespace`  | Namespace of ks-apiserver (ks-installer installs it in petasus-system)  | `petasus-system`                         |
| `networkPolicy.apiserver.podLabels`  | Labels of the ks-apiserver pods                                        | `app: ks-apiserver`                      |
| `networkPolicy.gateway.podLabels`    | Labels of the Gateway's data plane pods                                | `gateway.networking.k8s.io/gateway-name: edgetron-gateway` |
| `networkPolicy.extraIngressFrom`     | More NetworkPolicy peers allowed to reach edgetron, such as the pods of the apps in `auth.readers` | `[]`         |
| `site.labelKey`                      | Node label whose value is the node's site (GPU node map); scheduling by site is a nodeSelector on it | `topology.kubernetes.io/zone` |
| `rtt.enabled`                        | Measure the RTT between sites: one probe per Site in the namespace `petasus-rtt`, kept by the watcher | `true`             |
| `rtt.probeImage.repository`          | Site RTT probe image repository                                        | `petasus/edgetron/rtt-probe`             |
| `rtt.probeImage.tag`                 | Site RTT probe image tag                                               | the chart's appVersion                   |
| `rtt.prometheusUrl`                  | Prometheus edgetron reads the probes' series from; empty: `http://prometheus-k8s.kubesphere-monitoring-system.svc:9090` | `http://prometheus-operated.monitoring-system.svc:9090` |
| `rtt.serviceMonitor`                 | Make the probes' ServiceMonitor (when its CRD exists)                  | `true`                                   |
| `rtt.scrapeInterval`                 | How often Prometheus scrapes the probes; a probe counts as down after 60 s without an answer, so two missed scrapes plus a 10 s round must stay under that | `15s` |
| `rtt.prometheusRule`                 | Make the p50/p95 recording rules (when the PrometheusRule CRD exists)   | `true`                                   |
| `rtt.ruleLabels`                     | Labels the Prometheus' ruleSelector picks                              | `prometheus: k8s`, `role: alert-rules`   |
| `rtt.exposure`                       | What tenants see in the scheduling step, on a new install (`rtt`, `trend`, `avail`, `count`, `nodes`); an upgrade keeps what operators set | `true, true, true, false, false` |
| `rtt.networkPolicy.enabled`          | Let only the probes, edgetron and `rtt.networkPolicy.scrapeNamespaces` reach the probes | `true`                  |

Specify each parameter using the `--set key=value[,key=value]` argument to `helm install`. For example,

```console
$ helm install my-edgetron \
  --set service.type=ClusterIP deployment/edgetron
```

The above command sets the default service type as ClusterIP.

Alternatively, a YAML file that specifies the values for the parameters can be provided while installing the chart. For example,

```console
$ helm install my-edgetron -f values.yaml deployment/edgetron
```

> **Tip**: You can use the default [values.yaml](values.yaml)

## Authentication and access

ks-apiserver is the only caller of the edgetron API. It takes a token with the
account in the Secret `edgetron-auth` (keys `jwt-secret`, `username`,
`password`), which it reads itself, and edgetron signs tokens with
`jwt-secret`. The first install generates the password and the signing key;
upgrades keep them.

A NetworkPolicy lets only ks-apiserver, the Gateway and the peers in
`networkPolicy.extraIngressFrom` reach edgetron. The Gateway routes the API docs
(`/edgetron/docs`, `/edgetron/redoc`, `/edgetron/v1/openapi.json`,
`/edgetron/static`) to it and, with `gateway.readOnlyApi` (on by default), the
API for read-only accounts: logging in, `GET` and the placement dry-runs, so Try
it out on `/edgetron/docs` works. It marks those requests, and edgetron takes no
other account through it.

Read-only accounts (`auth.readers`) are for other apps: they read everything but
a cluster's kubeconfig, its etcd snapshots and the license key. Apps in the
cluster call `edgetron-service` directly, with their pods in
`networkPolicy.extraIngressFrom`.

Upgrading a cluster that runs an older edgetron or ks-apiserver: an older
edgetron image ignores the Secret and keeps the built-in account, and an older
ks-apiserver keeps its own, so a generated account would lock them out of
each other. Do the first upgrade with the current account, and rotate once
both images are the new ones:

```console
$ helm upgrade edgetron deployment/edgetron -n edgestack-system --reset-then-reuse-values \
    --set auth.password=<current password> --set auth.jwtSecret=<current signing key>
```

Upgrade with `--reset-then-reuse-values` (Helm 3.14 or later), never
`--reuse-values`: `--reuse-values` also keeps the previous chart's defaults,
so a default this chart changes, such as the namespace the NetworkPolicy lets
ks-apiserver in from, would not apply and ks-apiserver could be cut off from
edgetron.

To rotate the account and the signing key, delete the Secret, or set new
`auth.password` and `auth.jwtSecret`, and upgrade. Clear values set earlier,
which `--reset-then-reuse-values` would otherwise keep:

```console
$ kubectl -n edgestack-system delete secret edgetron-auth
$ helm upgrade edgetron deployment/edgetron -n edgestack-system --reset-then-reuse-values \
    --set auth.password= --set auth.jwtSecret=
```

The Secret's checksum on the pod template restarts edgetron with the new
values. ks-apiserver needs no restart: its old token is refused, and it takes
a new one with the account it reads from the Secret. While the pods roll, old
and new pods sign with different keys, so a few requests may be refused and
retried.

