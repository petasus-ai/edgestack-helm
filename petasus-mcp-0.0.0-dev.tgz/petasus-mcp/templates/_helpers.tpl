{{- define "petasus-mcp.fullname" -}}
{{- if contains .Chart.Name .Release.Name -}}
{{- .Release.Name | trunc 57 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name .Chart.Name | trunc 57 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{- define "petasus-mcp.redis" -}}
{{- include "petasus-mcp.fullname" . }}-redis
{{- end -}}

{{- define "petasus-mcp.labels" -}}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version | replace "+" "_" }}
app.kubernetes.io/name: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/* The pods of one component: server or redis. */}}
{{- define "petasus-mcp.selector" -}}
app.kubernetes.io/name: {{ .context.Chart.Name }}
app.kubernetes.io/instance: {{ .context.Release.Name }}
app.kubernetes.io/component: {{ .component }}
{{- end -}}

{{- define "petasus-mcp.secret" -}}
{{- .Values.existingSecret | default (include "petasus-mcp.fullname" .) -}}
{{- end -}}

{{/* publicUrl, checked: scheme and host, nothing else; https but on the local host, as
the server requires. */}}
{{- define "petasus-mcp.publicUrl" -}}
{{- $url := urlParse (required "publicUrl is required: the console's address as AI clients reach it" .Values.publicUrl) -}}
{{- if or (not (has $url.scheme (list "https" "http"))) (not $url.host) (not (has $url.path (list "" "/"))) $url.query $url.fragment $url.userinfo -}}
{{- fail (printf "publicUrl %q is not a console address such as https://console.example:30880" .Values.publicUrl) -}}
{{- end -}}
{{- $name := regexReplaceAll ":[0-9]*$" (lower $url.host) "" -}}
{{- if and (eq $url.scheme "http") (not (has $name (list "localhost" "127.0.0.1"))) -}}
{{- fail (printf "publicUrl %q must be https" .Values.publicUrl) -}}
{{- end -}}
{{- printf "%s://%s" $url.scheme (lower $url.host) -}}
{{- end -}}

{{/* The Host headers /mcp answers for publicUrl, comma-separated: its host, and the bare
name too when it names the default port, which clients leave out of the header. */}}
{{- define "petasus-mcp.publicHosts" -}}
{{- /* publicUrl itself, which "petasus-mcp.publicUrl" checks: helm lint lets a failed check
     through. */ -}}
{{- $url := urlParse (.Values.publicUrl | default "") -}}
{{- $host := lower $url.host -}}
{{- $hosts := list $host -}}
{{- $default := ternary ":443" ":80" (eq $url.scheme "https") -}}
{{- if hasSuffix $default $host -}}
{{- $hosts = append $hosts (trimSuffix $default $host) -}}
{{- end -}}
{{- join "," $hosts -}}
{{- end -}}

{{/* The server's Redis URL, with its password from the environment. */}}
{{- define "petasus-mcp.redisUrl" -}}
{{- $external := .Values.redis.external -}}
{{- if $external.host -}}
{{- $username := $external.username | default "" | toString -}}
{{- if not (regexMatch "^[A-Za-z0-9_-]*$" $username) -}}
{{- fail "redis.external.username must be letters, digits, - and _: it goes into the server's Redis URL as it is" -}}
{{- end -}}
{{- if not (regexMatch "^[0-9]+$" ($external.port | toString)) -}}
{{- fail "redis.external.port must be a port number" -}}
{{- end -}}
{{- if or (lt (int $external.port) 1) (gt (int $external.port) 65535) -}}
{{- fail "redis.external.port must be between 1 and 65535" -}}
{{- end -}}
{{- if not (regexMatch "^[0-9]+$" ($external.db | toString)) -}}
{{- fail "redis.external.db must be a database number, 0 or more" -}}
{{- end -}}
{{- if and .Values.networkPolicy.enabled (not $external.podLabels) -}}
{{- fail "redis.external.podLabels is required with the network policy: it lets the server reach that Redis" -}}
{{- end -}}
{{- printf "redis://%s:$(REDIS_PASSWORD)@%s:%d/%d" $username $external.host (int $external.port) (int $external.db) -}}
{{- else -}}
{{- printf "redis://:$(REDIS_PASSWORD)@%s:6379/0" (include "petasus-mcp.redis" .) -}}
{{- end -}}
{{- end -}}

{{/* Redis's configuration, in its ConfigMap and checksummed on its pod. */}}
{{- define "petasus-mcp.redisConf" -}}
port 6379
dir /data
maxmemory {{ .Values.redis.maxmemory }}
maxmemory-policy noeviction
appendonly yes
appendfsync everysec
save ""
# The password, written at start from the Secret: never in the command line.
include /run/redis/auth.conf
{{- end -}}
