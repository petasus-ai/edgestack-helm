#!/bin/bash
# The realm settings keycloak-config-cli cannot make without taking over a whole list the
# administrators share (templates/config-cli.yaml). Run after it, with Keycloak's admin CLI,
# on every install, upgrade and rollback; every step is safe to repeat.
set -euo pipefail

kcadm() { /opt/keycloak/bin/kcadm.sh "$@" --config /tmp/kcadm.config; }

# The master realm's administrator; the password comes from KC_CLI_PASSWORD.
kcadm config credentials --server "$KEYCLOAK_URL" --realm master --user "$KEYCLOAK_USER"

# Every user holds default-roles-petasus. It must not give the account console and its API
# (managing one's own profile and credentials outside the console, KC-19), the linking of
# external accounts, or offline tokens, which outlive the SSO session. The MFA policy "all"
# is a composite of the same role, so the three are taken out one by one rather than the
# composite being written whole.
kcadm remove-roles -r petasus --rname default-roles-petasus \
  --cclientid account --rolename manage-account --rolename manage-account-links
kcadm remove-roles -r petasus --rname default-roles-petasus --rolename offline_access

# A login through an identity provider never runs the browser flow's second factor; the
# post-login flow petasus-post-broker does. Identity providers are the administrators'
# (made in the admin console), so each one without a post-login flow gets it.
kcadm get identity-provider/instances -r petasus --fields alias,postBrokerLoginFlowAlias \
    --format csv --noquotes |
  while IFS=, read -r alias post; do
    if [ -n "$alias" ] && [ -z "$post" ]; then
      kcadm update "identity-provider/instances/$alias" -r petasus -s postBrokerLoginFlowAlias=petasus-post-broker
      echo "identity provider $alias: post-login flow petasus-post-broker"
    fi
  done
echo "realm petasus finished"
