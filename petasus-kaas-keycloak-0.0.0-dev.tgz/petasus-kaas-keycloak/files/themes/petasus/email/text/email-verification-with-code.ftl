<#ftl output_format="plainText">
${msg("petasusEmailVerifyTitle")}

${msg("petasusEmailCodeBody")}

${code}

${msg("petasusEmailVerifyIgnore")}

--
${msg("petasusEmailFooter", realmName)}
