<#ftl output_format="plainText">
${msg("petasusEmailTestTitle")}

${msg("petasusEmailTestBody", realmName)}

--
${msg("petasusEmailFooter", realmName)}
