<#ftl output_format="plainText">
<#assign expiresIn = linkExpirationFormatter(linkExpiration)><#if ["ko", "ja"]?seq_contains(locale.language)><#assign expiresIn = expiresIn?replace(" ", "")></#if>
${msg("petasusEmailLinkTitle", identityProviderDisplayName)}

${msg("petasusEmailLinkBody", identityProviderDisplayName, realmName, identityProviderContext.username)}

${link}

${msg("petasusEmailExpires", expiresIn)}
${msg("petasusEmailLinkIgnore")}

--
${msg("petasusEmailFooter", realmName)}
