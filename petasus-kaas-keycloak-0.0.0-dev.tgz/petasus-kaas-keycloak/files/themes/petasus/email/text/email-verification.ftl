<#ftl output_format="plainText">
<#assign expiresIn = linkExpirationFormatter(linkExpiration)><#if ["ko", "ja"]?seq_contains(locale.language)><#assign expiresIn = expiresIn?replace(" ", "")></#if>
${msg("petasusEmailVerifyTitle")}

${msg("petasusEmailVerifyBody", realmName)}

${link}

${msg("petasusEmailExpires", expiresIn)}
${msg("petasusEmailVerifyIgnore")}

--
${msg("petasusEmailFooter", realmName)}
