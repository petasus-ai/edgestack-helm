<#ftl output_format="plainText">
<#assign expiresIn = linkExpirationFormatter(linkExpiration)><#if ["ko", "ja"]?seq_contains(locale.language)><#assign expiresIn = expiresIn?replace(" ", "")></#if>
${msg("petasusEmailActionsTitle")}

${msg("petasusEmailActionsBody", realmName)}
<#if requiredActions??><#list requiredActions as reqActionItem>
- ${msg("requiredAction.${reqActionItem}")}
</#list></#if>

${link}

${msg("petasusEmailExpires", expiresIn)}
${msg("petasusEmailActionsIgnore")}

--
${msg("petasusEmailFooter", realmName)}
