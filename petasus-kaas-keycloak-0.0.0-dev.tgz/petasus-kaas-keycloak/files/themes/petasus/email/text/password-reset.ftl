<#ftl output_format="plainText">
<#assign expiresIn = linkExpirationFormatter(linkExpiration)><#if ["ko", "ja"]?seq_contains(locale.language)><#assign expiresIn = expiresIn?replace(" ", "")></#if>
${msg("petasusEmailResetTitle")}

${msg("petasusEmailResetBody", realmName)}

${link}

${msg("petasusEmailExpires", expiresIn)}
${msg("petasusEmailResetIgnore")}

--
${msg("petasusEmailFooter", realmName)}
