<#import "template.ftl" as layout>
<@layout.emailLayout title=msg("petasusEmailVerifyTitle")>
<@layout.p>${msg("petasusEmailCodeBody")}</@layout.p>
<p style="margin:8px 0 24px;padding:14px 0;border-radius:8px;background-color:#f3f1fd;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:26px;font-weight:700;letter-spacing:0.18em;text-align:center;color:#151a30;">${code}</p>
<@layout.note>${msg("petasusEmailVerifyIgnore")}</@layout.note>
</@layout.emailLayout>
