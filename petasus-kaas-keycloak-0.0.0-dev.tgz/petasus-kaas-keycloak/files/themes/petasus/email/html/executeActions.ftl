<#import "template.ftl" as layout>
<@layout.emailLayout title=msg("petasusEmailActionsTitle")>
<@layout.p>${msg("petasusEmailActionsBody", realmName)}</@layout.p>
<#if requiredActions??>
<ul style="margin:0 0 8px;padding:0 0 0 20px;color:#151a30;font-weight:600;">
<#list requiredActions as reqActionItem>
<li style="margin:0 0 4px;">${msg("requiredAction.${reqActionItem}")}</li>
</#list>
</ul>
</#if>
<@layout.button href=link label=msg("petasusEmailActionsButton")/>
<@layout.fallback href=link/>
<@layout.note>${layout.expires()}<br>${msg("petasusEmailActionsIgnore")}</@layout.note>
</@layout.emailLayout>
