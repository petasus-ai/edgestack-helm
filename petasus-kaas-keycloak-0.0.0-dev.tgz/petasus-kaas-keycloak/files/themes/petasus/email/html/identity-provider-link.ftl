<#import "template.ftl" as layout>
<@layout.emailLayout title=msg("petasusEmailLinkTitle", identityProviderDisplayName)>
<@layout.p>${msg("petasusEmailLinkBody", identityProviderDisplayName, realmName, identityProviderContext.username)}</@layout.p>
<@layout.button href=link label=msg("petasusEmailLinkButton")/>
<@layout.fallback href=link/>
<@layout.note>${layout.expires()}<br>${msg("petasusEmailLinkIgnore")}</@layout.note>
</@layout.emailLayout>
