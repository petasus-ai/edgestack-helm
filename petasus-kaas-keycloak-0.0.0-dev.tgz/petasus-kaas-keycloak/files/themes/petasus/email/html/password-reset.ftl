<#import "template.ftl" as layout>
<@layout.emailLayout title=msg("petasusEmailResetTitle")>
<@layout.p>${msg("petasusEmailResetBody", realmName)}</@layout.p>
<@layout.button href=link label=msg("petasusEmailResetButton")/>
<@layout.fallback href=link/>
<@layout.note>${layout.expires()}<br>${msg("petasusEmailResetIgnore")}</@layout.note>
</@layout.emailLayout>
