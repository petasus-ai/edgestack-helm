<#import "template.ftl" as layout>
<@layout.emailLayout title=msg("petasusEmailTestTitle")>
<@layout.p>${msg("petasusEmailTestBody", realmName)}</@layout.p>
</@layout.emailLayout>
