<#import "template.ftl" as layout>
<@layout.emailLayout title=msg("petasusEmailVerifyTitle")>
<@layout.p>${msg("petasusEmailVerifyBody", realmName)}</@layout.p>
<@layout.button href=link label=msg("petasusEmailVerifyButton")/>
<@layout.fallback href=link/>
<@layout.note>${layout.expires()}<br>${msg("petasusEmailVerifyIgnore")}</@layout.note>
</@layout.emailLayout>
