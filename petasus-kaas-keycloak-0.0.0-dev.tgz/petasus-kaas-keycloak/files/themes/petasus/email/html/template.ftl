<#--
  The frame of every mail: a white card on a pale wash of the accent, the brand at the
  top as the console's logo spells it, and a footer. Mail clients ignore most CSS, so
  the layout is tables and every style is inline. Mails take the purple accent: a
  mail has no console cookie to read.
-->
<#assign pkFont = "'Pretendard', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Apple SD Gothic Neo', 'Malgun Gothic', 'Hiragino Sans', 'Yu Gothic', 'PingFang SC', 'Microsoft YaHei', Arial, sans-serif">

<#macro emailLayout title="">
<!DOCTYPE html>
<html lang="${locale.language}" dir="${(ltr)?then('ltr','rtl')}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="light">
<meta name="supported-color-schemes" content="light">
<title>${title?has_content?then(title, realmName!'')}</title>
</head>
<body style="margin:0;padding:0;background-color:#f3f1fd;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#f3f1fd;">
<tr>
<td align="center" style="padding:40px 16px;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width:520px;background-color:#ffffff;border-radius:16px;border:1px solid #e4e1f7;">
<tr>
<td style="height:6px;line-height:6px;font-size:0;background-color:#3617ce;background-image:linear-gradient(90deg,#5233f2,#3617ce 52%,#2a0fb0);border-radius:16px 16px 0 0;">&nbsp;</td>
</tr>
<tr>
<td style="padding:36px 40px 0;font-family:${pkFont};">
<span style="font-size:22px;font-weight:600;letter-spacing:-0.01em;color:#3617ce;">Petasus</span>
<span style="display:inline-block;margin-left:4px;padding:0 7px;border-radius:4px;background-color:#3617ce;font-size:15px;font-weight:600;line-height:22px;color:#ffffff;vertical-align:3px;">kubernetes</span>
</td>
</tr>
<#if title?has_content>
<tr>
<td style="padding:28px 40px 0;font-family:${pkFont};font-size:24px;font-weight:700;line-height:1.3;letter-spacing:-0.02em;color:#151a30;">${title}</td>
</tr>
</#if>
<tr>
<td style="padding:12px 40px 36px;font-family:${pkFont};font-size:15px;line-height:1.6;color:#5a6079;">
<#nested>
</td>
</tr>
</table>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width:520px;">
<tr>
<td style="padding:20px 40px 0;font-family:${pkFont};font-size:12px;line-height:1.6;color:#6b7189;text-align:center;">${msg("petasusEmailFooter", realmName!'')}</td>
</tr>
</table>
</td>
</tr>
</table>
</body>
</html>
</#macro>

<#-- When the link expires. Korean and Japanese write no space between a number and its unit; the console's Chinese does -->
<#function expires>
    <#local text = linkExpirationFormatter(linkExpiration)>
    <#if ["ko", "ja"]?seq_contains(locale.language)>
        <#local text = text?replace(" ", "")>
    </#if>
    <#return msg("petasusEmailExpires", text)>
</#function>

<#-- A paragraph of the mail's body -->
<#macro p>
<p style="margin:0 0 16px;">
<#nested>
</p>
</#macro>

<#-- The one thing to do: the console's primary button -->
<#macro button href label>
<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:24px 0;">
<tr>
<td align="center" style="border-radius:8px;background-color:#3617ce;background-image:linear-gradient(135deg,#5233f2 0%,#3617ce 52%,#2a0fb0 100%);">
<a href="${href}" target="_blank" style="display:inline-block;padding:13px 28px;font-family:${pkFont};font-size:15px;font-weight:600;line-height:1.4;color:#ffffff;text-decoration:none;border-radius:8px;">${label} &rarr;</a>
</td>
</tr>
</table>
</#macro>

<#-- The link again, for a client that does not show the button -->
<#macro fallback href>
<p style="margin:0 0 16px;font-size:12px;line-height:1.5;color:#6b7189;">${msg("petasusEmailLinkFallback")}<br><a href="${href}" target="_blank" style="color:#8a8fa6;word-break:break-all;">${href}</a></p>
</#macro>

<#-- The quiet lines at the end: when the link expires, and what to do if it was not you -->
<#macro note>
<p style="margin:16px 0 0;padding-top:16px;border-top:1px solid #e4e6ef;font-size:13px;line-height:1.6;color:#6b7189;">
<#nested>
</p>
</#macro>
