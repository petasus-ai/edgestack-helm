<#import "template.ftl" as layout>
<#import "user-profile-commons.ftl" as userProfileCommons>
<#import "buttons.ftl" as buttons>
<#-- The first login through a company sign-in: the profile it brought, to check -->
<@layout.registrationLayout displayMessage=messagesPerField.exists('global') displayRequiredFields=true; section>
    <#if section = "header">
        ${msg("loginIdpReviewProfileTitle")}
    <#elseif section = "lead">
        ${msg("petasusReviewProfileLead")}
    <#elseif section = "form">
        <form id="kc-idp-review-profile-form" class="pk-form" data-pk-busy action="${url.loginAction}" method="post">
            <@userProfileCommons.userProfileFormFields/>
            <@buttons.actionGroup>
                <@buttons.button id="kc-submit" label="doSubmit"/>
            </@buttons.actionGroup>
        </form>
    </#if>
</@layout.registrationLayout>
