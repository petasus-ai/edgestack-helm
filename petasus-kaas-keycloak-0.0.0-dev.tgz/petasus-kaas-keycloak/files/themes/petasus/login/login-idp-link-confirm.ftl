<#import "template.ftl" as layout>
<#import "buttons.ftl" as buttons>
<#-- A company sign-in whose user already has an account here: link the two, or review the profile -->
<@layout.registrationLayout displayMessage=false; section>
    <#if section = "header">
        ${msg("confirmLinkIdpTitle")}
    <#elseif section = "lead">
        <#if message?has_content>${kcSanitize(message.summary)?no_esc}</#if>
    <#elseif section = "form">
        <form id="kc-register-form" class="pk-form" action="${url.loginAction}" method="post">
            <@buttons.actionGroup>
                <@buttons.button name="submitAction" id="linkAccount" value="linkAccount" label="confirmLinkIdpContinue"/>
                <#if !hideReviewButton?has_content>
                    <@buttons.button name="submitAction" id="updateProfile" value="updateProfile" label="confirmLinkIdpReviewProfile" type="secondary"/>
                </#if>
            </@buttons.actionGroup>
        </form>
    </#if>
</@layout.registrationLayout>
