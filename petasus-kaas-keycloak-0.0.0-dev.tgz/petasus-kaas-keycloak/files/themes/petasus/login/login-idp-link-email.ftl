<#import "template.ftl" as layout>
<#-- Linking a company sign-in by email: where the mail went, and what to do without it -->
<@layout.registrationLayout; section>
    <#if section = "header">
        ${msg("emailLinkIdpTitle", idpDisplayName)}
    <#elseif section = "lead">
        ${msg("emailLinkIdp1", idpDisplayName, brokerContext.username, realm.displayName)}
    <#elseif section = "form">
        <#-- Chinese and Japanese put no space around the link -->
        <#assign sp = ["ja", "zh"]?seq_contains(locale.currentLanguageTag?keep_before("-"))?then("", " ")>
        <div class="pk-form">
            <p class="pk-note" id="instruction2">${msg("emailLinkIdp2")}${sp}<a href="${url.loginAction}">${msg("doClickHere")}</a>${sp}${msg("emailLinkIdp3")}</p>
            <p class="pk-note" id="instruction3">${msg("emailLinkIdp4")}${sp}<a href="${url.loginAction}">${msg("doClickHere")}</a>${sp}${msg("emailLinkIdp5")}</p>
        </div>
    </#if>
</@layout.registrationLayout>
