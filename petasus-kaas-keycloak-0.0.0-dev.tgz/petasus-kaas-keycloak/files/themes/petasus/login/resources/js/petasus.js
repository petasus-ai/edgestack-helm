// What the console's login page does in the browser, for the login service's screens:
// the empty-field messages, the busy state while a form is on its way, the password
// rules ticked off as they are met, and the choice between authenticator apps.

const sheet = document.querySelector('.pk-sheet')

// A form that has been sent shows the console's busy state: a bar along the top of
// the sheet, the lead turned into a spinner, and the form dimmed
const setBusy = (busy, text) => {
  if (!sheet) {
    return
  }
  const lead = document.getElementById('pk-lead')
  const status = sheet.querySelector('.pk-busy')
  sheet.classList.toggle('pk-is-busy', busy)
  if (lead) {
    lead.hidden = busy
  }
  if (status) {
    if (text) {
      status.querySelector('span').textContent = text
    }
    status.hidden = !busy
  }
}

// Fields the user left empty, with the console's messages under them
const validate = form => {
  let first
  form.querySelectorAll('.pk-validate-messages [data-for]').forEach(message => {
    const input = form.querySelector(`[name="${message.dataset.for}"]`)
    if (!input || input.value !== '') {
      return
    }
    showError(input, message.textContent)
    first = first || input
  })
  if (first) {
    return false
  }
  return true
}

const showError = (input, text) => {
  const field = input.closest('.pk-field')
  const container = document.getElementById(`input-error-container-${input.name}`)
  if (field) {
    field.classList.add('pk-has-error')
  }
  if (container) {
    const error = document.createElement('div')
    error.className = 'pk-error-text'
    error.id = `input-error-${input.name}`
    error.textContent = text
    container.replaceChildren(error)
    input.setAttribute('aria-describedby', error.id)
  }
  input.setAttribute('aria-invalid', 'true')
}

const clearError = input => {
  const field = input.closest('.pk-field')
  const container = document.getElementById(`input-error-container-${input.name}`)
  if (field) {
    field.classList.remove('pk-has-error')
  }
  if (container) {
    container.replaceChildren()
  }
  input.removeAttribute('aria-invalid')
}

document.querySelectorAll('form[data-pk-validate]').forEach(form => {
  form.querySelectorAll('input').forEach(input =>
    input.addEventListener('input', () => {
      if (input.getAttribute('aria-invalid') === 'true') {
        clearError(input)
      }
    })
  )
})

document.querySelectorAll('form[data-pk-busy]').forEach(form => {
  form.addEventListener('submit', event => {
    // A way out (cancel) leaves without the busy state
    const submitter = event.submitter
    if (submitter && submitter.classList.contains('pk-back')) {
      return
    }
    if (form.hasAttribute('data-pk-validate') && !validate(form)) {
      event.preventDefault()
      return
    }
    if (form.dataset.pkSent) {
      event.preventDefault()
      return
    }
    form.dataset.pkSent = 'true'
    setBusy(true, form.dataset.pkBusy)
  })
})

// Back to a page the browser kept: it is no longer on its way
window.addEventListener('pageshow', event => {
  if (event.persisted) {
    setBusy(false)
    document.querySelectorAll('form[data-pk-sent]').forEach(form => {
      delete form.dataset.pkSent
    })
  }
})

// The password rules, ticked off as the new password meets them
const count = (value, pattern) => (value.match(pattern) || []).length
const RULES = {
  length: (value, rule) =>
    value.length >= Number(rule.dataset.min || 0) &&
    (!rule.dataset.max || value.length <= Number(rule.dataset.max)),
  upper: (value, rule) => count(value, /\p{Lu}/gu) >= Number(rule.dataset.min),
  lower: (value, rule) => count(value, /\p{Ll}/gu) >= Number(rule.dataset.min),
  digits: (value, rule) => count(value, /\p{Nd}/gu) >= Number(rule.dataset.min),
  special: (value, rule) =>
    count(value, /[^\p{L}\p{Nd}]/gu) >= Number(rule.dataset.min),
  username: value => {
    const username = (document.getElementById('username') || {}).value
    return value !== '' && (!username || value.toLowerCase() !== username.toLowerCase())
  },
}

document.querySelectorAll('[data-pk-rules]').forEach(list => {
  const input = document.getElementById(list.dataset.pkRules)
  if (!input) {
    return
  }
  const check = () => {
    list.querySelectorAll('li[data-rule]').forEach(rule => {
      const test = RULES[rule.dataset.rule]
      rule.classList.toggle('pk-ok', !!test && input.value !== '' && test(input.value, rule))
    })
  }
  input.addEventListener('input', check)
  check()
})

// Several authenticator apps: the one whose code is typed
document.querySelectorAll('.pk-device').forEach(device =>
  device.addEventListener('click', () => {
    const selected = document.getElementById('selectedCredentialId')
    if (selected) {
      selected.value = device.dataset.credential
    }
    document.querySelectorAll('.pk-device').forEach(other => {
      const on = other === device
      other.classList.toggle('pk-selected', on)
      other.setAttribute('aria-checked', String(on))
    })
  })
)

// Copying a code to the clipboard
document.querySelectorAll('[data-copy]').forEach(button =>
  button.addEventListener('click', async () => {
    const input = document.getElementById(button.dataset.copy)
    try {
      await navigator.clipboard.writeText(input.value)
      button.setAttribute('aria-label', button.dataset.successLabel)
    } catch (err) {
      button.setAttribute('aria-label', button.dataset.failureLabel)
    }
  })
)
