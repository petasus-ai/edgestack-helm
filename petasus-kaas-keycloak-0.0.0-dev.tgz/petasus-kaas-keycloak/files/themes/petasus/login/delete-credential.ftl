<#import "template.ftl" as layout>
<#import "buttons.ftl" as buttons>
<#-- Removing an authenticator app, security key or passkey from the console's Security tab -->
<@layout.registrationLayout displayMessage=false; section>
    <#if section = "header">
        ${msg("deleteCredentialTitle", credentialLabel)}
    <#elseif section = "lead">
        ${msg("deleteCredentialMessage", credentialLabel)}
    <#elseif section = "form">
        <form class="pk-form" action="${url.loginAction}" method="POST">
            <@buttons.actionGroup>
                <button type="submit" name="accept" id="kc-accept" class="pk-button pk-danger"><span>${msg("doConfirmDelete")}</span></button>
                <button type="submit" name="cancel-aia" id="kc-decline" class="pk-back">${msg("doCancel")}</button>
            </@buttons.actionGroup>
        </form>
    </#if>
</@layout.registrationLayout>
