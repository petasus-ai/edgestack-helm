<#import "template.ftl" as layout>
<#import "field.ftl" as field>
<#import "buttons.ftl" as buttons>
<#import "social-providers.ftl" as identityProviders>
<#import "passkeys.ftl" as passkeys>
<#import "divider.ftl" as divider>
<#--
  The login form, as the console's: a welcome, the username and password with their
  icons, the "Log In" button, the company's sign-in servers under an "or" line, and
  the help line at the bottom. A failed login shows in the box above the form, as the
  console's does, and not under the fields.

  The form posts the page's language back as kc_locale. The console sends its own
  language as ui_locales, but a language saved on the user's profile outranks that
  once the user is known; kc_locale outranks both, so the screens after the password
  stay in the console's language, and the profile takes it for the mails that follow.
-->
<#assign pkAction = url.loginAction>
<#if realm.internationalizationEnabled && (locale.currentLanguageTag)?has_content>
    <#assign pkAction = pkAction + (pkAction?contains("?"))?then("&", "?") + "kc_locale=" + locale.currentLanguageTag?url('UTF-8')>
</#if>
<@layout.registrationLayout displayInfo=realm.password && realm.registrationAllowed && !registrationDisabled??; section>
    <#if section = "header">
        ${msg("petasusWelcome")}
    <#elseif section = "lead">
        ${msg("petasusWelcomeDesc")}
    <#elseif section = "form">
        <#if realm.password>
            <form id="kc-form-login" class="pk-form" data-pk-busy data-pk-validate action="${pkAction}" method="post" novalidate="novalidate">
                <#if !usernameHidden??>
                    <#assign label>
                        <#if !realm.loginWithEmailAllowed>${msg("username")}<#elseif !realm.registrationEmailAsUsername>${msg("usernameOrEmail")}<#else>${msg("email")}</#if>
                    </#assign>
                    <@field.input name="username" label=label error="" icon="user" placeholder="user@example.com"
                        autocomplete="${(enableWebAuthnConditionalUI?has_content)?then('username webauthn', 'username')}" value=login.username!''/>
                </#if>
                <@field.password name="password" label=msg("password") error="" placeholder=msg("petasusPasswordPlaceholder")
                    autofocus=usernameHidden?? autocomplete="current-password">
                    <#if realm.rememberMe && !usernameHidden??>
                        <@field.checkbox name="rememberMe" label=msg("rememberMe") value=login.rememberMe??/>
                    </#if>
                </@field.password>
                <input type="hidden" id="id-hidden-input" name="credentialId"<#if auth.selectedCredential?has_content> value="${auth.selectedCredential}"</#if>>
                <div class="pk-validate-messages" hidden>
                    <span data-for="username">${msg("petasusUsernameRequired")}</span>
                    <span data-for="password">${msg("petasusPasswordRequired")}</span>
                </div>
                <@buttons.loginButton/>
            </form>
        </#if>
    <#elseif section = "socialProviders">
        <#-- Passkeys and the company's sign-in servers share one "or" line -->
        <#assign pkIdps = realm.password && social.providers?? && social.providers?has_content>
        <#if pkIdps || enableWebAuthnConditionalUI?has_content>
            <div class="pk-alt" id="kc-social-providers">
                <@divider.or/>
                <@passkeys.conditionalUIData/>
                <#if pkIdps>
                    <@identityProviders.buttons social=social/>
                </#if>
            </div>
        </#if>
    <#elseif section = "info">
        <#if realm.password && realm.registrationAllowed && !registrationDisabled??>
            <p class="pk-note">${msg("noAccount")} <a href="${url.registrationUrl}">${msg("doRegister")}</a></p>
        </#if>
    <#elseif section = "help">
        <#if realm.resetPasswordAllowed>
            ${msg("petasusForgotPassword")} <a href="${url.loginResetCredentialsUrl}">${msg("petasusResetPassword")}</a>
        <#else>
            ${msg("petasusAskAdmin")}
        </#if>
    </#if>
</@layout.registrationLayout>
