<#import "template.ftl" as layout>
<#import "buttons.ftl" as buttons>
<#-- A security key or passkey that did not work: the reason, and another try -->
<@layout.registrationLayout; section>
    <#if section = "header">
        ${msg("webauthn-error-title")}
    <#elseif section = "lead">
        ${msg("petasusKeyErrorLead")}
    <#elseif section = "form">
        <script type="text/javascript">
            <#outputformat "JavaScript">
            refreshPage = () => {
                document.getElementById('isSetRetry').value = 'retry';
                document.getElementById('executionValue').value = ${execution?c};
                document.getElementById('kc-error-credential-form').requestSubmit();
            }
            </#outputformat>
        </script>

        <form id="kc-error-credential-form" class="pk-form" action="${url.loginAction}" method="post">
            <input type="hidden" id="executionValue" name="authenticationExecution"/>
            <input type="hidden" id="isSetRetry" name="isSetRetry"/>
            <@buttons.actionGroup>
                <button type="button" id="kc-try-again" name="try-again" class="pk-button pk-primary" onclick="refreshPage()">
                    <span>${msg("doTryAgain")}</span><@buttons.arrowIcon/>
                </button>
                <#if isAppInitiatedAction??>
                    <button type="submit" id="cancelWebAuthnAIA" name="cancel-aia" value="true" class="pk-back">${msg("doCancel")}</button>
                </#if>
            </@buttons.actionGroup>
        </form>
    </#if>
</@layout.registrationLayout>
