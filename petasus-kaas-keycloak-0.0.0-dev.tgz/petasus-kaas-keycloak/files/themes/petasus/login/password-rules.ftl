<#--
  What a new password needs, from the realm's password policy, as the console lists it
  under its password field. petasus.js ticks each rule off as the user types; the
  server checks them again.
-->
<#macro rules field="password-new">
    <#assign p = passwordPolicies!{}>
    <#if (p.length)?? || (p.maxLength)?? || (p.upperCase)?? || (p.lowerCase)?? || (p.digits)?? || (p.specialChars)?? || (p.notUsername!false)>
        <div class="pk-rules" data-pk-rules="${field}">
            <p class="pk-rules-title">${msg("petasusPasswordMust")}</p>
            <ul>
                <#if (p.length)?? && (p.maxLength)??>
                    <li data-rule="length" data-min="${p.length?c}" data-max="${p.maxLength?c}">${msg("petasusRuleLengthRange", p.length?c, p.maxLength?c)}</li>
                <#elseif (p.length)??>
                    <li data-rule="length" data-min="${p.length?c}">${msg("petasusRuleLengthMin", p.length?c)}</li>
                <#elseif (p.maxLength)??>
                    <li data-rule="length" data-max="${p.maxLength?c}">${msg("petasusRuleLengthMax", p.maxLength?c)}</li>
                </#if>
                <#if (p.upperCase)??>
                    <li data-rule="upper" data-min="${p.upperCase?c}">${msg("petasusRuleUpper", p.upperCase?c)}</li>
                </#if>
                <#if (p.lowerCase)??>
                    <li data-rule="lower" data-min="${p.lowerCase?c}">${msg("petasusRuleLower", p.lowerCase?c)}</li>
                </#if>
                <#if (p.digits)??>
                    <li data-rule="digits" data-min="${p.digits?c}">${msg("petasusRuleDigits", p.digits?c)}</li>
                </#if>
                <#if (p.specialChars)??>
                    <li data-rule="special" data-min="${p.specialChars?c}">${msg("petasusRuleSpecial", p.specialChars?c)}</li>
                </#if>
                <#if p.notUsername!false>
                    <li data-rule="username">${msg("petasusRuleNotUsername")}</li>
                </#if>
            </ul>
        </div>
    </#if>
</#macro>
