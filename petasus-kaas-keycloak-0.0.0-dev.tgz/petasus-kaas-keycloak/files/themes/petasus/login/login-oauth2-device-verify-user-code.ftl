<#import "template.ftl" as layout>
<#import "field.ftl" as field>
<#import "buttons.ftl" as buttons>
<#-- kubectl's device login: the code the terminal shows -->
<@layout.registrationLayout; section>
    <#if section = "header">
        ${msg("oauth2DeviceVerificationTitle")}
    <#elseif section = "lead">
        ${msg("petasusDeviceLead")}
    <#elseif section = "form">
        <form id="kc-user-verify-device-user-code-form" class="pk-form" data-pk-busy action="${url.oauth2DeviceVerificationAction}" method="post">
            <@field.input name="device_user_code" label=msg("verifyOAuth2DeviceUserCode") autofocus=true icon="otp" placeholder="ABCD-EFGH"/>
            <@buttons.actionGroup>
                <@buttons.button id="kc-login" label="doSubmit"/>
            </@buttons.actionGroup>
        </form>
    </#if>
</@layout.registrationLayout>
