<#import "template.ftl" as layout>
<#import "buttons.ftl" as buttons>
<#-- A login page that was left open too long: start again, or go on where it was -->
<@layout.registrationLayout; section>
    <#if section = "header">
        ${msg("pageExpiredTitle")}
    <#elseif section = "lead">
        ${msg("petasusPageExpiredLead")}
    <#elseif section = "form">
        <div class="pk-form">
            <@buttons.actionGroup>
                <a id="loginRestartLink" class="pk-button pk-primary" href="${url.loginRestartFlowUrl}"><span>${msg("petasusRestartLogin")}</span><@buttons.arrowIcon/></a>
                <a id="loginContinueLink" class="pk-button pk-secondary" href="${url.loginAction}">${msg("petasusContinueLogin")}</a>
            </@buttons.actionGroup>
        </div>
    </#if>
</@layout.registrationLayout>
