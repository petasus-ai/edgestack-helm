<#import "hero.ftl" as hero>
<#--
  The layout of every login screen: the console's login page (ks-console
  src/core/containers/Login). A white sheet on the left holds the logo, the title, a
  lead line, the form and a help line at the bottom; the hero (hero.ftl) fills the
  right. Under 64rem the sheet takes the whole width and the hero steps aside.

  A page fills these sections: "header" (the title), "lead" (one line under it),
  "form", "socialProviders", "info" and "help" (the line at the bottom of the sheet).
  keycloak.v2 pages give only the first ones; theirs render the same way.
-->
<#macro registrationLayout bodyClass="" displayInfo=false displayMessage=true displayRequiredFields=false>
<#assign pkLead><#nested "lead"></#assign>
<#assign pkHelp><#nested "help"></#assign>
<!DOCTYPE html>
<html lang="${lang}" data-accent="purple">
<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <meta name="color-scheme" content="light">
    <title>${realm.displayName!realm.name}</title>
    <link rel="icon" href="/assets/favicon.ico" type="image/x-icon">
    <script>
        // The console's accent, read before anything is painted. The page is always light.
        (function () {
            var match = document.cookie.match(/(?:^|;\s*)accent=([^;]*)/);
            if (match && decodeURIComponent(match[1]) === "green") {
                document.documentElement.setAttribute("data-accent", "green");
            }
        })();
    </script>
    <#list (properties.styles!"")?split(" ") as style>
        <#if style?has_content>
            <link href="${url.resourcesPath}/${style}" rel="stylesheet">
        </#if>
    </#list>
    <script type="importmap">
        {
            "imports": {
                "rfc4648": "${url.resourcesCommonPath}/vendor/rfc4648/rfc4648.js"
            }
        }
    </script>
    <#if scripts??>
        <#list scripts as script>
            <script src="${script}" type="text/javascript"></script>
        </#list>
    </#if>
    <script type="module" src="${url.resourcesPath}/js/passwordVisibility.js"></script>
    <script type="module" src="${url.resourcesPath}/js/petasus.js"></script>
    <script type="module">
        <#outputformat "JavaScript">
        import { startSessionPolling } from ${(url.resourcesPath + "/js/authChecker.js")?c};

        startSessionPolling(
            ${url.ssoLoginInOtherTabsUrl?c}
        );
        </#outputformat>
    </script>
    <script type="module">
        document.addEventListener("click", (event) => {
            const link = event.target.closest("a[data-once-link]");

            if (!link) {
                return;
            }

            if (link.getAttribute("aria-disabled") === "true") {
                event.preventDefault();
                return;
            }

            const { disabledClass } = link.dataset;

            if (disabledClass) {
                link.classList.add(...disabledClass.trim().split(/\s+/));
            }

            link.setAttribute("role", "link");
            link.setAttribute("aria-disabled", "true");
        });
    </script>
    <#if authenticationSession??>
        <script type="module">
            <#outputformat "JavaScript">
            import { checkAuthSession } from ${(url.resourcesPath + "/js/authChecker.js")?c};

            checkAuthSession(
                ${authenticationSession.authSessionIdHash?c}
            );
            </#outputformat>
        </script>
    </#if>
</head>

<body class="${bodyClass}" data-page-id="login-${pageId}">
<div class="pk-page">
    <main class="pk-sheet">
        <div class="pk-progress" aria-hidden="true"></div>
        <div class="pk-brand">
            <a href="/" class="pk-logo"><img class="pk-logo-img" src="/assets/logo.svg" alt="Petasus Kubernetes"></a>
            <h1 class="pk-title" id="kc-page-title"><#nested "header"></h1>
        </div>
        <#if pkLead?markup_string?trim?has_content>
            <p class="pk-lead" id="pk-lead">${pkLead}</p>
        <#else>
            <div class="pk-lead pk-lead-empty" id="pk-lead"></div>
        </#if>
        <p class="pk-lead pk-busy" role="status" hidden>
            <svg class="pk-spinner" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="8" cy="8" r="6.5" stroke-opacity="0.18"/><path d="M8 1.5a6.5 6.5 0 0 1 6.5 6.5" stroke-linecap="round"/></svg>
            <span>${msg("petasusSigningIn")}</span>
        </p>
        <div class="pk-body">
            <#if auth?has_content && auth.showUsername() && !auth.showResetCredentials()>
                <#nested "show-username">
                <div class="pk-user" id="kc-username">
                    <svg class="pk-user-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4.5 20c1.2-3.6 4.1-5.5 7.5-5.5s6.3 1.9 7.5 5.5"/></svg>
                    <span class="pk-user-name" id="kc-attempted-username">${auth.attemptedUsername}</span>
                    <a class="pk-user-switch" id="reset-login" href="${url.loginRestartFlowUrl}" title="${msg("restartLoginTooltip")}" aria-label="${msg("restartLoginTooltip")}">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 12a9 9 0 0 1 15.3-6.4L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15.3 6.4L3 16"/><path d="M3 21v-5h5"/></svg>
                    </a>
                </div>
            </#if>

            <#-- An application-initiated action does not warn that the action is needed -->
            <#if displayMessage && message?has_content && (message.type != 'warning' || !isAppInitiatedAction??)>
                <div class="pk-alert pk-alert-${message.type}" role="alert">
                    <span class="pk-alert-text kc-feedback-text">${kcSanitize(message.summary)?no_esc}</span>
                </div>
            </#if>

            <#nested "form">

            <#if auth?has_content && auth.showTryAnotherWayLink()>
                <form id="kc-select-try-another-way-form" class="pk-another" action="${url.loginAction}" method="post" novalidate="novalidate">
                    <input type="hidden" name="tryAnotherWay" value="on">
                    <button type="submit" id="try-another-way" class="pk-back">${msg("doTryAnotherWay")}</button>
                </form>
            </#if>

            <#if switchOrganizationEnabled?? && switchOrganizationEnabled>
                <form id="kc-switch-organization-form" class="pk-another" action="${url.loginAction}" method="post" novalidate="novalidate">
                    <input type="hidden" name="switchOrganization" value="true">
                    <button type="submit" id="switch-organization" class="pk-back">${msg("doSwitchOrganization")}</button>
                </form>
            </#if>

            <#nested "socialProviders">

            <#if displayInfo>
                <div id="kc-info" class="pk-info">
                    <#nested "info">
                </div>
            </#if>
        </div>
        <div class="pk-help">
            <#if pkHelp?markup_string?trim?has_content>
                <p>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M9.6 9.3a2.5 2.5 0 0 1 4.8.9c0 1.7-2.4 2.2-2.4 3.6"/><path d="M12 17h.01"/></svg>
                    <span>${pkHelp}</span>
                </p>
            </#if>
        </div>
    </main>
    <@hero.render/>
</div>
</body>
</html>
</#macro>
