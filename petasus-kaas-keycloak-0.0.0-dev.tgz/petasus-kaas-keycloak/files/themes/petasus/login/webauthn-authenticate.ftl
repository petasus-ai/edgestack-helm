<#import "template.ftl" as layout>
<#import "buttons.ftl" as buttons>
<#--
  The second step of a login with a security key or passkey: the user's keys, when the
  realm lists them, and the button that opens the browser's dialog.
-->
<@layout.registrationLayout displayInfo=(realm.registrationAllowed && !registrationDisabled??); section>
    <#if section = "header">
        ${msg("petasusKeyLoginTitle")}
    <#elseif section = "lead">
        ${msg("petasusKeyLoginLead")}
    <#elseif section = "form">
        <div id="kc-form-webauthn" class="pk-form">
            <form id="webauth" action="${url.loginAction}" method="post" hidden="hidden">
                <input type="hidden" id="clientDataJSON" name="clientDataJSON"/>
                <input type="hidden" id="authenticatorData" name="authenticatorData"/>
                <input type="hidden" id="signature" name="signature"/>
                <input type="hidden" id="credentialId" name="credentialId"/>
                <input type="hidden" id="userHandle" name="userHandle"/>
                <input type="hidden" id="error" name="error"/>
            </form>

            <#if authenticators??>
                <form id="authn_select" hidden="hidden">
                    <#list authenticators.authenticators as authenticator>
                        <input type="hidden" name="authn_use_chk" value="${authenticator.credentialId}"/>
                    </#list>
                </form>

                <#if shouldDisplayAuthenticators?? && shouldDisplayAuthenticators>
                    <#if authenticators.authenticators?size gt 1>
                        <p class="pk-label">${msg("webauthn-available-authenticators")}</p>
                    </#if>
                    <ul class="pk-choices" role="list">
                        <#list authenticators.authenticators as authenticator>
                            <li>
                                <div id="kc-webauthn-authenticator-item-${authenticator?index}" class="pk-choice pk-static">
                                    <span class="pk-choice-icon pk-ic-key" aria-hidden="true"></span>
                                    <span class="pk-choice-body">
                                        <span id="kc-webauthn-authenticator-label-${authenticator?index}" class="pk-choice-title">${authenticator.label}</span>
                                        <#if authenticator.authenticatorProvider?? && authenticator.authenticatorProvider?has_content>
                                            <span class="pk-choice-desc">${authenticator.authenticatorProvider}</span>
                                        <#elseif authenticator.transports?? && authenticator.transports.displayNameProperties?has_content>
                                            <span class="pk-choice-desc" id="kc-webauthn-authenticator-transport-${authenticator?index}"><#list authenticator.transports.displayNameProperties as nameProperty>${msg(nameProperty)}<#sep>, </#sep></#list></span>
                                        </#if>
                                        <span class="pk-choice-desc">${msg('webauthn-createdAt-label')} <span id="kc-webauthn-authenticator-created-${authenticator?index}">${authenticator.createdAt}</span></span>
                                    </span>
                                </div>
                            </li>
                        </#list>
                    </ul>
                </#if>
            </#if>

            <@buttons.actionGroup>
                <button type="button" id="authenticateWebAuthnButton" class="pk-button pk-primary" autofocus>
                    <span>${msg("petasusKeyLoginButton")}</span><@buttons.arrowIcon/>
                </button>
            </@buttons.actionGroup>
        </div>
        <script type="module">
            <#outputformat "JavaScript">
            import { authenticateByWebAuthn } from "${url.resourcesPath}/js/webauthnAuthenticate.js";
            const authButton = document.getElementById('authenticateWebAuthnButton');
            authButton.addEventListener("click", function() {
                const input = {
                    isUserIdentified : ${isUserIdentified},
                    challenge : ${challenge?c},
                    userVerification : ${userVerification?c},
                    rpId : ${rpId?c},
                    createTimeout : ${createTimeout?c},
                    errmsg : ${msg("webauthn-unsupported-browser-text")?c}
                };
                authenticateByWebAuthn(input);
            }, { once: true });
            </#outputformat>
        </script>
    <#elseif section = "info">
        <#if realm.registrationAllowed && !registrationDisabled??>
            <p class="pk-note">${msg("noAccount")} <a href="${url.registrationUrl}">${msg("doRegister")}</a></p>
        </#if>
    </#if>
</@layout.registrationLayout>
