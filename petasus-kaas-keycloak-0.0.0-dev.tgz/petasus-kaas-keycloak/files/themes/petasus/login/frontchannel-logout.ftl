<#import "template.ftl" as layout>
<#import "buttons.ftl" as buttons>
<#-- Logging out of the applications that take a front-channel logout -->
<@layout.registrationLayout; section>
    <#if section = "header">
        ${msg("frontchannel-logout.title")}
    <#elseif section = "lead">
        ${msg("frontchannel-logout.message")}
    <#elseif section = "form">
        <div class="pk-form">
            <ul class="pk-tags">
                <#list logout.clients as client>
                    <li>${client.name}<iframe src="${client.frontChannelLogoutUrl}" style="display:none;"></iframe></li>
                </#list>
            </ul>
            <#if logout.logoutRedirectUri?has_content>
                <script>
                    <#outputformat "JavaScript">
                    function readystatechange(event) {
                        if (document.readyState=='complete') {
                            window.location.replace(${logout.logoutRedirectUri?c});
                        }
                    }
                    document.addEventListener('readystatechange', readystatechange);
                    </#outputformat>
                </script>
                <@buttons.actionGroup>
                    <a id="continue" class="pk-button pk-primary" href="${logout.logoutRedirectUri}"><span>${msg("doContinue")}</span><@buttons.arrowIcon/></a>
                </@buttons.actionGroup>
            </#if>
        </div>
    </#if>
</@layout.registrationLayout>
