<#--
  Buttons in the console's login look. The primary one is the accent's gradient with
  an arrow that nudges on hover; a secondary one is outlined, as the console's other
  sign-in buttons are; a way out (cancel, decline, back) is quiet text under them, as
  the console's "Back" is. The macros keep keycloak.v2's names and parameters.
-->
<#macro actionGroup horizontal=false>
    <div class="pk-actions">
        <#nested>
    </div>
</#macro>

<#function quiet name label>
    <#return name == "cancel-aia" || label == "doCancel" || label == "doDecline" || label == "backToLogin">
</#function>

<#macro arrowIcon>
    <svg class="pk-arrow" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"/><path d="M13 6l6 6-6 6"/></svg>
</#macro>

<#macro button label id="" name="" type="primary" fullWidth=true class=[] arrow=true extra...>
    <#if quiet(name, label)>
        <button class="pk-back<#list class as c> ${properties[c]!}</#list>" name="${name}" id="${id}" type="submit" <#list extra as attrName, attrVal>${attrName}="${attrVal}" </#list>>${msg(label)}</button>
    <#else>
        <button class="pk-button pk-${type}<#list class as c> ${properties[c]!}</#list>" name="${name}" id="${id}" type="submit" <#list extra as attrName, attrVal>${attrName}="${attrVal}" </#list>>
            <span>${msg(label)}</span><#if type == "primary" && arrow><@arrowIcon/></#if>
        </button>
    </#if>
</#macro>

<#macro buttonLink href label id="" class=["kcButtonSecondaryClass", "kcButtonBlockClass"]>
    <#if quiet("", label)>
        <a id="${id}" href="${href}" class="pk-back">${msg(label)}</a>
    <#else>
        <a id="${id}" href="${href}" class="pk-button pk-secondary">${msg(label)}</a>
    </#if>
</#macro>

<#macro loginButton>
    <@actionGroup>
        <@button id="kc-login" name="login" label="doLogIn"/>
    </@actionGroup>
</#macro>
