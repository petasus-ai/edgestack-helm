<#--
  Form fields in the console's login look: a label over a 44px outlined input, an
  optional icon inside it on the left (icon="user" or "lock"), and the error in red
  under it. The macros keep keycloak.v2's names and parameters, so its pages that this
  theme does not replace (user-profile-commons.ftl among them) draw the same fields.
-->
<#macro group name label error="" required=false icon="">
<div class="pk-field<#if icon?has_content> pk-with-icon pk-icon-${icon}</#if><#if error?has_content> pk-has-error</#if>">
    <label for="${name}" class="pk-label">${label}<#if required><span class="pk-required" aria-hidden="true">*</span></#if></label>
    <div class="pk-field-control">
        <#nested>
    </div>
    <div id="input-error-container-${name}">
        <#if error?has_content>
            <div class="pk-error-text" id="input-error-${name}" aria-live="polite">${error}</div>
        </#if>
    </div>
</div>
</#macro>

<#-- keycloak.v2 marks an invalid field with an icon in the input; the red outline does here -->
<#macro errorIcon error="">
</#macro>

<#macro input name label value="" required=false autocomplete="off" fieldName=name error=messagesPerField.get(fieldName) autofocus=false icon="" placeholder="" type="text">
    <@group name=name label=label error=error required=required icon=icon>
        <input id="${name}" name="${name}" value="${value}" type="${type}" autocomplete="${autocomplete}"<#if autofocus> autofocus</#if><#if placeholder?has_content> placeholder="${placeholder}"</#if>
               <#if autocomplete == "one-time-code">inputmode="numeric"</#if>
               aria-invalid="<#if error?has_content>true</#if>"<#if error?has_content> aria-describedby="input-error-${name}"</#if>/>
    </@group>
</#macro>

<#macro password name label value="" required=false forgotPassword=false fieldName=name error=messagesPerField.get(fieldName) autocomplete="off" autofocus=false icon="lock" placeholder="">
    <@group name=name label=label error=error required=required icon=icon>
        <div class="pk-password">
            <input id="${name}" name="${name}" value="${value}" type="password" autocomplete="${autocomplete}"<#if autofocus> autofocus</#if><#if placeholder?has_content> placeholder="${placeholder}"</#if>
                   aria-invalid="<#if error?has_content>true</#if>"<#if error?has_content> aria-describedby="input-error-${name}"</#if>/>
            <button class="pk-eye" type="button" aria-label="${msg('showPassword')}"
                    aria-controls="${name}" data-password-toggle
                    data-icon-show="pk-eye-closed" data-icon-hide="pk-eye-open"
                    data-label-show="${msg('showPassword')}" data-label-hide="${msg('hidePassword')}" id="${name}-show-password">
                <i class="pk-eye-closed" aria-hidden="true"></i>
            </button>
        </div>
        <#nested>
        <#if forgotPassword>
            <div class="pk-helper"><a href="${url.loginResetCredentialsUrl}">${msg("doForgotPassword")}</a></div>
        </#if>
    </@group>
</#macro>

<#macro clipboard name label ariaLabel=label value="" readonly=true>
    <@group name=name label=label>
        <div class="pk-clipboard" id="kc-${name}-clipboard">
            <input id="${name}" name="${name}" value="${value}" type="text"<#if readonly> readonly</#if> aria-label="${ariaLabel}"/>
            <button class="pk-copy" type="button" id="kc-${name}-copy-button" data-copy="${name}"
                    aria-label="${msg("code-copy-label")}" data-success-label="${msg("code-copy-success")}" data-failure-label="${msg("code-copy-failure")}">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>
            </button>
        </div>
    </@group>
</#macro>

<#macro checkbox name label value=false required=false>
    <div class="pk-check">
        <label for="${name}">
            <input class="pk-check-input" type="checkbox" id="${name}" name="${name}"<#if value> checked</#if>/>
            <span class="pk-check-label">${label}</span>
            <#if required><span class="pk-required" aria-hidden="true">*</span></#if>
        </label>
    </div>
</#macro>
