<#import "template.ftl" as layout>
<#import "password-commons.ftl" as passwordCommons>
<#import "buttons.ftl" as buttons>
<#--
  Registering a security key (webauthn-register), or a passkey (webauthn-register-
  passwordless, named in the form's action, or any registration that asks for a
  discoverable credential). The browser's own dialog does the rest and shows the realm's
  relying party name, the console title.
-->
<#assign pkPasskey = url.loginAction?contains("execution=webauthn-register-passwordless") || (residentKey!'') == "Required" || (requireResidentKey!'') == "Yes">
<@layout.registrationLayout; section>
    <#if section = "header">
        <#if pkPasskey>${msg("petasusPasskeyRegisterTitle")}<#else>${msg("petasusKeyRegisterTitle")}</#if>
    <#elseif section = "lead">
        <#if pkPasskey>${msg("petasusPasskeyRegisterLead")}<#else>${msg("petasusKeyRegisterLead")}</#if>
    <#elseif section = "form">
        <div class="pk-hint-card">
            <span class="pk-badge" aria-hidden="true">
                <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="7.5" cy="15.5" r="4.5"/><path d="M10.7 12.3 20 3"/><path d="m16 7 3 3"/><path d="m18.5 4.5 2 2"/></svg>
            </span>
            <p><#if pkPasskey>${msg("petasusPasskeyRegisterHint")}<#else>${msg("petasusKeyRegisterHint")}</#if></p>
        </div>
        <form id="register" class="pk-form" action="${url.loginAction}" method="post">
            <input type="hidden" id="clientDataJSON" name="clientDataJSON"/>
            <input type="hidden" id="attestationObject" name="attestationObject"/>
            <input type="hidden" id="publicKeyCredentialId" name="publicKeyCredentialId"/>
            <input type="hidden" id="authenticatorLabel" name="authenticatorLabel"/>
            <input type="hidden" id="transports" name="transports"/>
            <input type="hidden" id="authenticatorAttachment" name="authenticatorAttachment"/>
            <input type="hidden" id="error" name="error"/>
            <@passwordCommons.logoutOtherSessions/>
        </form>

        <script type="module">
            <#outputformat "JavaScript">
            import { registerByWebAuthn } from "${url.resourcesPath}/js/webauthnRegister.js";
            const registerButton = document.getElementById('registerWebAuthn');
            registerButton.addEventListener("click", function() {
                const input = {
                    challenge : ${challenge?c},
                    userid : ${userid?c},
                    username : ${username?c},
                    signatureAlgorithms : [<#list signatureAlgorithms as sigAlg>${sigAlg?c},</#list>],
                    rpEntityName : ${rpEntityName?c},
                    rpId : ${rpId?c},
                    attestationConveyancePreference : ${attestationConveyancePreference?c},
                    authenticatorAttachment : ${authenticatorAttachment?c},
                    requireResidentKey : ${requireResidentKey?c},
                    residentKey : ${residentKey?c},
                    userVerificationRequirement : ${userVerificationRequirement?c},
                    createTimeout : ${createTimeout?c},
                    excludeCredentialIds : ${excludeCredentialIds?c},
                    initLabel : ${msg(pkPasskey?then("petasusPasskeyLabel", "webauthn-registration-init-label"))?c},
                    initLabelPrompt : ${msg(pkPasskey?then("petasusPasskeyLabelPrompt", "webauthn-registration-init-label-prompt"))?c},
                    errmsg : ${msg("webauthn-unsupported-browser-text")?c}
                };
                registerByWebAuthn(input);
            },  { once: true });
            </#outputformat>
        </script>

        <@buttons.actionGroup>
            <button type="button" id="registerWebAuthn" class="pk-button pk-primary">
                <span><#if pkPasskey>${msg("petasusPasskeyRegisterButton")}<#else>${msg("petasusKeyRegisterButton")}</#if></span><@buttons.arrowIcon/>
            </button>
            <#if !isSetRetry?has_content && isAppInitiatedAction?has_content>
                <form action="${url.loginAction}" id="kc-webauthn-settings-form" method="post">
                    <button type="submit" id="cancelWebAuthnAIA" name="cancel-aia" value="true" class="pk-back">${msg("doCancel")}</button>
                </form>
            </#if>
        </@buttons.actionGroup>
    </#if>
</@layout.registrationLayout>
