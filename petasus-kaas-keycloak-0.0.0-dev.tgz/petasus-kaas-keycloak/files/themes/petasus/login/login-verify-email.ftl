<#import "template.ftl" as layout>
<#import "buttons.ftl" as buttons>
<#-- Verifying the email address: where the mail went, and how to have it sent again.
     The lead says why, so the "verify your email" warning is not repeated in a box. -->
<@layout.registrationLayout displayMessage=((message.type)!'') != 'warning'; section>
    <#if section = "header">
        ${msg("emailVerifyTitle")}
    <#elseif section = "lead">
        <#if verifyEmail??>
            ${msg("emailVerifyInstruction1", verifyEmail)}
        <#else>
            ${msg("emailVerifyInstruction4", user.email)}
        </#if>
    <#elseif section = "form">
        <#if isAppInitiatedAction??>
            <form id="kc-verify-email-form" class="pk-form" action="${url.loginAction}" method="post">
                <@buttons.actionGroup>
                    <#if verifyEmail??>
                        <@buttons.button id="kc-resend" label="emailVerifyResend" type="secondary"/>
                    <#else>
                        <@buttons.button id="kc-send" label="emailVerifySend"/>
                    </#if>
                    <@buttons.button id="kc-cancel" label="doCancel" name="cancel-aia" value="true"/>
                </@buttons.actionGroup>
            </form>
        <#else>
            <div class="pk-form">
                <p class="pk-note">${msg("emailVerifyInstruction2")}</p>
                <@buttons.actionGroup>
                    <a class="pk-button pk-secondary" href="${url.loginAction}">${msg("emailVerifyResend")}</a>
                </@buttons.actionGroup>
            </div>
        </#if>
    </#if>
</@layout.registrationLayout>
