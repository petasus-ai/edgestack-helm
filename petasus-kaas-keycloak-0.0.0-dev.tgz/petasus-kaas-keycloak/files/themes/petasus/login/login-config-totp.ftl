<#import "template.ftl" as layout>
<#import "field.ftl" as field>
<#import "buttons.ftl" as buttons>
<#import "password-commons.ftl" as passwordCommons>
<#--
  Setting up an authenticator app, at a login the realm asks for one and from the
  console's Security tab: three numbered steps, the QR code (or the key to type in),
  then the code the app shows and a name for this device.
-->
<@layout.registrationLayout displayMessage=!messagesPerField.existsError('totp','userLabel') && ((message.type)!'') != 'warning'; section>
    <#if section = "header">
        ${msg("loginTotpTitle")}
    <#elseif section = "lead">
        <#if isAppInitiatedAction??>${msg("petasusTotpLeadAia")}<#else>${msg("petasusTotpLead")}</#if>
    <#elseif section = "form">
        <ol class="pk-steps" id="kc-totp-settings">
            <li>
                <p>${msg("loginTotpStep1")}</p>
                <ul class="pk-apps" id="kc-totp-supported-apps">
                    <#list totp.supportedApplications as app>
                        <li>${msg(app)}</li>
                    </#list>
                </ul>
            </li>
            <#if mode?? && mode = "manual">
                <li>
                    <p>${msg("loginTotpManualStep2")}</p>
                    <p class="pk-secret" id="kc-totp-secret-key">${totp.totpSecretEncoded}</p>
                    <p><a href="${totp.qrUrl}" id="mode-barcode">${msg("loginTotpScanBarcode")}</a></p>
                </li>
                <li>
                    <p>${msg("loginTotpManualStep3")}</p>
                    <dl class="pk-facts">
                        <div id="kc-totp-type"><dt>${msg("loginTotpType")}</dt><dd>${msg("loginTotp." + totp.policy.type)}</dd></div>
                        <div id="kc-totp-algorithm"><dt>${msg("loginTotpAlgorithm")}</dt><dd>${totp.policy.getAlgorithmKey()}</dd></div>
                        <div id="kc-totp-digits"><dt>${msg("loginTotpDigits")}</dt><dd>${totp.policy.digits}</dd></div>
                        <#if totp.policy.type = "totp">
                            <div id="kc-totp-period"><dt>${msg("loginTotpInterval")}</dt><dd>${totp.policy.period}</dd></div>
                        <#elseif totp.policy.type = "hotp">
                            <div id="kc-totp-counter"><dt>${msg("loginTotpCounter")}</dt><dd>${totp.policy.initialCounter}</dd></div>
                        </#if>
                    </dl>
                </li>
            <#else>
                <li>
                    <p>${msg("loginTotpStep2")}</p>
                    <div class="pk-qr">
                        <img id="kc-totp-secret-qr-code" src="data:image/png;base64, ${totp.totpSecretQrCode}" alt="${msg("petasusTotpQrAlt")}" width="176" height="176">
                    </div>
                    <p class="pk-qr-alt"><a href="${totp.manualUrl}" id="mode-manual">${msg("loginTotpUnableToScan")}</a></p>
                </li>
            </#if>
            <li>
                <p>${msg("loginTotpStep3")}</p>
            </li>
        </ol>

        <form action="${url.loginAction}" class="pk-form" data-pk-busy="<#if isAppInitiatedAction??>${msg('petasusSaving')}</#if>" id="kc-totp-settings-form" method="post" novalidate="novalidate">
            <@field.input name="totp" label=msg("authenticatorCode") autocomplete="one-time-code" required=true icon="otp" placeholder=msg("petasusOtpPlaceholder")/>
            <input type="hidden" id="totpSecret" name="totpSecret" value="${totp.totpSecret}">
            <#if mode??><input type="hidden" id="mode" name="mode" value="${mode}"></#if>
            <@field.input name="userLabel" label=msg("loginTotpDeviceName") required=(totp.otpCredentials?size gte 1) placeholder=msg("petasusTotpDevicePlaceholder")/>
            <p class="pk-hint">${msg("loginTotpStep3DeviceName")}</p>

            <@passwordCommons.logoutOtherSessions/>

            <@buttons.actionGroup>
                <@buttons.button id="saveTOTPBtn" label="doSubmit"/>
                <#if isAppInitiatedAction??>
                    <@buttons.button id="cancelTOTPBtn" name="cancel-aia" label="doCancel" value="true"/>
                </#if>
            </@buttons.actionGroup>
        </form>
    </#if>
</@layout.registrationLayout>
