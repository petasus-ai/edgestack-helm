<#import "template.ftl" as layout>
<#import "user-profile-commons.ftl" as userProfileCommons>
<#import "buttons.ftl" as buttons>
<#-- The user's profile, when the realm needs it filled in or the console asks for it -->
<@layout.registrationLayout displayMessage=messagesPerField.exists('global') displayRequiredFields=true; section>
    <#if section = "header">
        ${msg("loginProfileTitle")}
    <#elseif section = "lead">
        ${msg("petasusProfileLead")}
    <#elseif section = "form">
        <form id="kc-update-profile-form" class="pk-form" data-pk-busy="<#if isAppInitiatedAction??>${msg('petasusSaving')}</#if>" action="${url.loginAction}" method="post">
            <@userProfileCommons.userProfileFormFields/>
            <@buttons.actionGroup>
                <@buttons.button id="kc-submit" label="doSubmit"/>
                <#if isAppInitiatedAction??>
                    <@buttons.button id="kc-cancel" label="doCancel" name="cancel-aia" value="true"/>
                </#if>
            </@buttons.actionGroup>
        </form>
    </#if>
</@layout.registrationLayout>
