<#import "template.ftl" as layout>
<#import "buttons.ftl" as buttons>
<#-- Asked only when a logout comes without the ID token; the console sends it -->
<@layout.registrationLayout; section>
    <#if section = "header">
        ${msg("logoutConfirmTitle")}
    <#elseif section = "lead">
        ${msg("logoutConfirmHeader")}
    <#elseif section = "form">
        <div id="kc-logout-confirm" class="pk-form">
            <form action="${url.logoutConfirmAction}" onsubmit="confirmLogout.disabled = true; return true;" method="POST">
                <input type="hidden" name="session_code" value="${logoutConfirm.code}">
                <@buttons.actionGroup>
                    <button tabindex="4" class="pk-button pk-primary" name="confirmLogout" id="kc-logout" type="submit"><span>${msg("doLogout")}</span><@buttons.arrowIcon/></button>
                    <#if !logoutConfirm.skipLink && (client.baseUrl)?has_content>
                        <a class="pk-back" href="${client.baseUrl}">${msg("backToApplication")}</a>
                    </#if>
                </@buttons.actionGroup>
            </form>
        </div>
    </#if>
</@layout.registrationLayout>
