<#macro or text=msg("petasusOr")>
    <div class="pk-or">${text}</div>
</#macro>
