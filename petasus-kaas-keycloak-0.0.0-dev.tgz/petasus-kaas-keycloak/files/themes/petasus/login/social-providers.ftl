<#import "divider.ftl" as divider>
<#--
  The company's sign-in servers, as the console offers other sign-in servers: an "or"
  line and an outlined button per server that reads "Log in with <name>".
-->
<#macro show social>
    <div class="pk-alt" id="kc-social-providers">
        <@divider.or/>
        <@buttons social=social/>
    </div>
</#macro>

<#-- The buttons alone, for a page that puts them under its own "or" line -->
<#macro buttons social>
        <#list social.providers as p>
            <a data-once-link data-disabled-class="pk-disabled" id="social-${p.alias}" class="pk-oauth" href="${p.loginUrl}">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--accent-fg)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><path d="M10 17l5-5-5-5"/><path d="M15 12H3"/></svg>
                <span>${msg("signInWithProvider", p.displayName!)}</span>
            </a>
        </#list>
</#macro>
