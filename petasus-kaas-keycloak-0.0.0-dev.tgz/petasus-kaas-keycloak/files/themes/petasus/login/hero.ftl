<#--
  The right-hand side of the login screens: what the console is for, over the accent's
  dark page. A copy of ks-console src/core/containers/Login/Hero: the diagram is drawn
  on a 560 x 400 box, the Kubernetes engine in the middle, seven GPUs on the corners of
  a heptagon of radius 118 around it, and the AI workloads on an orbit outside them.
  Its coordinates are those the console computes.
-->
<#macro gpu x y kind>
    <g transform="translate(${x} ${y})" class="pk-gpu-${kind}">
        <#if kind != "idle">
            <rect x="-4" y="-4" width="50" height="50" rx="14" class="pk-gpu-halo"/>
        </#if>
        <rect width="42" height="42" rx="11" class="pk-gpu-tile"/>
        <use href="#pk-gpu-icon" width="42" height="42" class="pk-gpu-icon"/>
    </g>
</#macro>

<#macro render>
<aside class="pk-hero">
    <p class="pk-eyebrow">
        <svg width="12" height="12" viewBox="-100 -100 200 200" aria-hidden="true"><polygon points="0,-100 78.18,-62.35 97.49,22.25 43.39,90.1 -43.39,90.1 -97.49,22.25 -78.18,-62.35" fill="var(--login-training)"/></svg>
        <span>${msg("petasusHeroEyebrow")}</span>
    </p>
    <h2 class="pk-headline">${msg("petasusHeroTitle")}</h2>
    <p class="pk-hero-lead">${msg("petasusHeroDesc")}</p>
    <div class="pk-diagram" role="img" aria-label="${msg("petasusHeroDiagram")}">
        <svg viewBox="0 0 560 400" aria-hidden="true">
            <defs>
                <radialGradient id="pk-hero-glow">
                    <stop offset="0" stop-color="var(--login-core-glow)" stop-opacity="0.5"/>
                    <stop offset="0.7" stop-color="var(--login-core-glow)" stop-opacity="0"/>
                </radialGradient>
                <linearGradient id="pk-hero-core" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0" stop-color="var(--login-core-1)"/>
                    <stop offset="1" stop-color="var(--login-core-2)"/>
                </linearGradient>
                <#-- Lucide "cpu", on its 24 x 24 grid -->
                <symbol id="pk-gpu-icon" viewBox="0 0 42 42">
                    <g fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" transform="translate(11 11) scale(0.8333)">
                        <rect width="16" height="16" x="4" y="4" rx="2"/>
                        <rect width="6" height="6" x="9" y="9" rx="1"/>
                        <path d="M15 2v2M15 20v2M2 15h2M2 9h2M20 15h2M20 9h2M9 2v2M9 20v2"/>
                    </g>
                </symbol>
            </defs>
            <circle cx="280" cy="200" r="160" fill="url(#pk-hero-glow)"/>
            <g class="pk-orbit">
                <circle cx="280" cy="200" r="195" fill="none" stroke="rgba(255, 255, 255, 0.2)" stroke-dasharray="4 6"/>
                <circle cx="429.4" cy="325.3" r="3.5" fill="var(--login-training)"/>
                <circle cx="96.8" cy="133.3" r="3" fill="var(--login-inference)"/>
            </g>
            <polygon points="280,82 372.2524,126.427 395.0382,226.255 331.2002,306.318 228.7998,306.318 164.9618,226.255 187.7476,126.427" fill="rgba(var(--login-training-rgb), 0.06)" stroke="rgba(var(--login-training-rgb), 0.42)" stroke-width="1.2" stroke-linejoin="round"/>
            <g stroke="rgba(255, 255, 255, 0.18)" stroke-dasharray="3 4">
                <line x1="280" y1="200" x2="280" y2="82"/>
                <line x1="280" y1="200" x2="372.2524" y2="126.427"/>
                <line x1="280" y1="200" x2="395.0382" y2="226.255"/>
                <line x1="280" y1="200" x2="331.2002" y2="306.318"/>
                <line x1="280" y1="200" x2="228.7998" y2="306.318"/>
                <line x1="280" y1="200" x2="164.9618" y2="226.255"/>
                <line x1="280" y1="200" x2="187.7476" y2="126.427"/>
            </g>
            <polygon points="280,140 326.908,162.59 338.494,213.35 306.034,254.06 253.966,254.06 221.506,213.35 233.092,162.59" fill="url(#pk-hero-core)" stroke="rgba(255, 255, 255, 0.6)" stroke-width="1.6" stroke-linejoin="round"/>
            <polygon points="280,153 316.7446,170.6955 325.8203,210.4575 300.3933,242.347 259.6067,242.347 234.1797,210.4575 243.2554,170.6955" fill="none" stroke="rgba(255, 255, 255, 0.28)" stroke-width="1.6" stroke-linejoin="round"/>
            <text class="pk-core-label" x="280" y="197">Petasus</text>
            <text class="pk-core-label" x="280" y="213">Kubernetes</text>
            <@gpu x="259" y="61" kind="training"/>
            <@gpu x="351.2524" y="105.427" kind="training"/>
            <@gpu x="374.0382" y="205.255" kind="inference"/>
            <@gpu x="310.2002" y="285.318" kind="inference"/>
            <@gpu x="207.7998" y="285.318" kind="training"/>
            <@gpu x="143.9618" y="205.255" kind="idle"/>
            <@gpu x="166.7476" y="105.427" kind="training"/>
        </svg>
        <ul class="pk-chips">
            <li class="pk-chip pk-chip-1"><span class="pk-dot pk-training"></span>${msg("petasusHeroDistributedTraining")}</li>
            <li class="pk-chip pk-chip-2"><span class="pk-dot pk-training"></span>${msg("petasusHeroFineTuning")}</li>
            <li class="pk-chip pk-chip-3"><span class="pk-dot pk-inference"></span>${msg("petasusHeroRealtimeInference")}</li>
            <li class="pk-chip pk-chip-4"><span class="pk-dot pk-inference"></span>${msg("petasusHeroBatchInference")}</li>
        </ul>
    </div>
    <ul class="pk-legend">
        <li><span class="pk-dot pk-training"></span>${msg("petasusHeroTrainingGpu")}</li>
        <li><span class="pk-dot pk-inference"></span>${msg("petasusHeroInferenceGpu")}</li>
        <li><span class="pk-dot pk-idle"></span>${msg("petasusHeroIdleGpu")}</li>
    </ul>
</aside>
</#macro>
