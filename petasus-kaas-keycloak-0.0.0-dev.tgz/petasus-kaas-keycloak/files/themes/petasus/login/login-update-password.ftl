<#import "template.ftl" as layout>
<#import "password-commons.ftl" as passwordCommons>
<#import "field.ftl" as field>
<#import "buttons.ftl" as buttons>
<#import "password-rules.ftl" as rules>
<#--
  A new password: at the first login, when the password has to change, and from the
  console's Security tab (application-initiated). The lead line says why, so the
  "you need to change your password" warning is not repeated in a box.
-->
<@layout.registrationLayout displayMessage=!messagesPerField.existsError('password','password-confirm') && ((message.type)!'') != 'warning'; section>
    <#if section = "header">
        <#if isAppInitiatedAction??>${msg("petasusChangePasswordTitle")}<#else>${msg("petasusSetPasswordTitle")}</#if>
    <#elseif section = "lead">
        <#if isAppInitiatedAction??>${msg("petasusChangePasswordLead")}<#else>${msg("petasusSetPasswordLead")}</#if>
    <#elseif section = "form">
        <form id="kc-passwd-update-form" class="pk-form" data-pk-busy="<#if isAppInitiatedAction??>${msg('petasusSaving')}</#if>" action="${url.loginAction}" method="post" novalidate="novalidate">
            <input type="text" id="username" name="username" value="${(auth.attemptedUsername)!''}" autocomplete="username" readonly hidden>
            <@field.password name="password-new" label=msg("passwordNew") fieldName="password" autocomplete="new-password" autofocus=true/>
            <@rules.rules field="password-new"/>
            <@field.password name="password-confirm" label=msg("passwordConfirm") autocomplete="new-password"/>

            <@passwordCommons.logoutOtherSessions/>

            <@buttons.actionGroup>
                <@buttons.button id="kc-submit" name="login" label="doSubmit"/>
                <#if isAppInitiatedAction??>
                    <@buttons.button id="kc-cancel" label="doCancel" name="cancel-aia"/>
                </#if>
            </@buttons.actionGroup>
        </form>

    </#if>
</@layout.registrationLayout>
