<#import "template.ftl" as layout>
<#-- "Try another way": each way to log in as a card that submits its choice -->
<@layout.registrationLayout displayInfo=false; section>
    <#if section = "header">
        ${msg("loginChooseAuthenticator")}
    <#elseif section = "lead">
        ${msg("petasusChooseLead")}
    <#elseif section = "form">
        <ul class="pk-choices" role="list">
            <#list auth.authenticationSelections as authenticationSelection>
                <li>
                    <form id="kc-select-credential-form-${authenticationSelection?index}" action="${url.loginAction}" method="post">
                        <input type="hidden" name="authenticationExecution" value="${authenticationSelection.authExecId}">
                        <button type="submit" class="pk-choice">
                            <span class="pk-choice-icon ${properties['${authenticationSelection.iconCssClass}']!'pk-ic-key'}" aria-hidden="true"></span>
                            <span class="pk-choice-body">
                                <span class="pk-choice-title">${msg('${authenticationSelection.displayName}')}</span>
                                <span class="pk-choice-desc">${msg('${authenticationSelection.helpText}')}</span>
                            </span>
                            <svg class="pk-choice-arrow" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 6 6 6-6 6"/></svg>
                        </button>
                    </form>
                </li>
            </#list>
        </ul>
    </#if>
</@layout.registrationLayout>
