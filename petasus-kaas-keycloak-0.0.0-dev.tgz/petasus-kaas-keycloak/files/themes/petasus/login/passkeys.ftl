<#--
  Passkey login on the login page, when the realm offers passkeys (an https console):
  the browser can offer a saved passkey in the username field, and a button under the
  form does it on request. The button sits with the company sign-ins under the "or"
  line, outlined as they are. The hidden forms and the script are keycloak.v2's.
-->
<#macro conditionalUIData>
    <#if enableWebAuthnConditionalUI?has_content>
        <form id="webauth" action="${url.loginAction}" method="post" hidden>
            <input type="hidden" id="clientDataJSON" name="clientDataJSON"/>
            <input type="hidden" id="authenticatorData" name="authenticatorData"/>
            <input type="hidden" id="signature" name="signature"/>
            <input type="hidden" id="credentialId" name="credentialId"/>
            <input type="hidden" id="userHandle" name="userHandle"/>
            <input type="hidden" id="error" name="error"/>
        </form>
        <#if authenticators??>
            <form id="authn_select" hidden>
                <#list authenticators.authenticators as authenticator>
                    <input type="hidden" name="authn_use_chk" value="${authenticator.credentialId}"/>
                </#list>
            </form>
        </#if>
        <script type="module">
            <#outputformat "JavaScript">
            import { authenticateByWebAuthn } from "${url.resourcesPath}/js/webauthnAuthenticate.js";
            import { initAuthenticate } from "${url.resourcesPath}/js/passkeysConditionalAuth.js";

            const args = {
                isUserIdentified : ${isUserIdentified},
                challenge : ${challenge?c},
                userVerification : ${userVerification?c},
                rpId : ${rpId?c},
                createTimeout : ${createTimeout?c},
                mediation : ${(mediation!'conditional')?c},
                authenticatorAttachment : ${authenticatorAttachment?c},
            };

            document.addEventListener("DOMContentLoaded", (event) => initAuthenticate({errmsg : ${msg("passkey-unsupported-browser-text")?c}, ...args}));
            const authButton = document.getElementById('authenticateWebAuthnButton');
            if (authButton) {
                authButton.addEventListener("click", (event) => {
                    event.preventDefault();
                    authenticateByWebAuthn({errmsg : ${msg("webauthn-unsupported-browser-text")?c}, ...args});
                }, { once: true });
            }
            </#outputformat>
        </script>
        <a id="authenticateWebAuthnButton" href="#" class="pk-oauth">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--accent-fg)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="9" cy="7.5" r="3.5"/><path d="M2.5 20c.8-3.6 3.4-5.5 6.5-5.5 1.2 0 2.3.3 3.2.8"/><circle cx="17.5" cy="12.5" r="2.5"/><path d="M17.5 15v6l1.5-1.2-1.5-1.3 1.5-1.2"/></svg>
            <span>${msg("petasusPasskeyLogin")}</span>
        </a>
    </#if>
</#macro>
