<#import "template.ftl" as layout>
<#import "field.ftl" as field>
<#import "buttons.ftl" as buttons>
<#--
  The second step of a login with an authenticator app: the user's apps to choose from
  when there are several, and the one-time code.
-->
<@layout.registrationLayout displayMessage=!messagesPerField.existsError('totp'); section>
    <#if section = "header">
        ${msg("petasusOtpTitle")}
    <#elseif section = "lead">
        ${msg("petasusOtpLead")}
    <#elseif section = "form">
        <form id="kc-otp-login-form" class="pk-form" data-pk-busy action="${url.loginAction}" method="post" novalidate="novalidate">
            <input id="selectedCredentialId" type="hidden" name="selectedCredentialId" value="${otpLogin.selectedCredentialId!''}">
            <#if otpLogin.userOtpCredentials?size gt 1>
                <div class="pk-field">
                    <span class="pk-label">${msg("petasusOtpDevice")}</span>
                    <div class="pk-devices" role="radiogroup" aria-label="${msg("petasusOtpDevice")}">
                        <#list otpLogin.userOtpCredentials as otpCredential>
                            <button type="button" role="radio" id="kc-otp-credential-${otpCredential?index}"
                                    class="pk-device<#if otpCredential.id == otpLogin.selectedCredentialId!''> pk-selected</#if>"
                                    aria-checked="${(otpCredential.id == otpLogin.selectedCredentialId!'')?c}"
                                    data-credential="${otpCredential.id}">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="6" y="2.5" width="12" height="19" rx="2.5"/><path d="M11 18.5h2"/></svg>
                                <span>${otpCredential.userLabel}</span>
                            </button>
                        </#list>
                    </div>
                </div>
            </#if>

            <@field.input name="otp" label=msg("loginOtpOneTime") autocomplete="one-time-code" fieldName="totp" autofocus=true icon="otp" placeholder=msg("petasusOtpPlaceholder")/>

            <@buttons.loginButton/>
        </form>
    </#if>
</@layout.registrationLayout>
