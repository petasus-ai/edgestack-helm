<#import "template.ftl" as layout>
<#import "buttons.ftl" as buttons>
<#--
  A notice: the account was updated, the email was verified, an action from an email
  link waits, a device has logged in. Its title is the notice's own when it has one.
-->
<@layout.registrationLayout displayMessage=false; section>
    <#if section = "header">
        <#if messageHeader??>
            ${kcSanitize(msg("${messageHeader}"))?no_esc}
        <#else>
            ${message.summary}
        </#if>
    <#elseif section = "lead">
        <#if messageHeader??>${message.summary}</#if>
    <#elseif section = "form">
        <div id="kc-info-message" class="pk-form">
            <#if requiredActions??>
                <ul class="pk-tags">
                    <#list requiredActions as reqActionItem>
                        <li>${kcSanitize(msg("requiredAction.${reqActionItem}"))?no_esc}</li>
                    </#list>
                </ul>
            </#if>
            <@buttons.actionGroup>
                <#if !skipLink?? && pageRedirectUri?has_content>
                    <a class="pk-button pk-primary" href="${pageRedirectUri}"><span>${msg("backToApplication")}</span><@buttons.arrowIcon/></a>
                <#elseif !skipLink?? && actionUri?has_content>
                    <a class="pk-button pk-primary" href="${actionUri}"><span>${msg("proceedWithAction")}</span><@buttons.arrowIcon/></a>
                <#elseif !skipLink?? && (client.baseUrl)?has_content>
                    <a class="pk-button pk-primary" href="${client.baseUrl}"><span>${msg("backToApplication")}</span><@buttons.arrowIcon/></a>
                <#else>
                    <#-- Nowhere to go back to (a logout, a link opened in another browser): the console is -->
                    <a class="pk-back" href="/">${msg("petasusGoToConsole")}</a>
                </#if>
            </@buttons.actionGroup>
        </div>
    </#if>
</@layout.registrationLayout>
