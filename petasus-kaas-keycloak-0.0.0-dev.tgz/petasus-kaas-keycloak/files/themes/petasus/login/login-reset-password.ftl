<#import "template.ftl" as layout>
<#import "field.ftl" as field>
<#import "buttons.ftl" as buttons>
<#-- "Forgot your password?" with mail: the username or email to send the link to -->
<@layout.registrationLayout displayMessage=!messagesPerField.existsError('username'); section>
    <#if section = "header">
        ${msg("emailForgotTitle")}
    <#elseif section = "lead">
        <#if realm.duplicateEmailsAllowed>${msg("emailInstructionUsername")}<#else>${msg("emailInstruction")}</#if>
    <#elseif section = "form">
        <form id="kc-reset-password-form" class="pk-form" data-pk-busy action="${url.loginAction}" method="post" novalidate="novalidate">
            <#assign label>
                <#if !realm.loginWithEmailAllowed>${msg("username")}<#elseif !realm.registrationEmailAsUsername>${msg("usernameOrEmail")}<#else>${msg("email")}</#if>
            </#assign>
            <@field.input name="username" label=label value=auth.attemptedUsername!'' autofocus=true icon="user" placeholder="user@example.com" autocomplete="username"/>
            <@buttons.actionGroup>
                <@buttons.button id="kc-form-buttons" label="petasusSendLink"/>
                <@buttons.buttonLink href=url.loginUrl label="backToLogin"/>
            </@buttons.actionGroup>
        </form>
    </#if>
</@layout.registrationLayout>
