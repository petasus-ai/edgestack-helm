<#import "template.ftl" as layout>
<#import "buttons.ftl" as buttons>
<#-- Something went wrong: what, and the way back -->
<@layout.registrationLayout displayMessage=false; section>
    <#if section = "header">
        ${kcSanitize(msg("errorTitle"))?no_esc}
    <#elseif section = "lead">
        ${kcSanitize(message.summary)?no_esc}
    <#elseif section = "form">
        <div id="kc-error-message" class="pk-form">
            <#if traceId??>
                <p class="pk-note" id="traceId">${msg("traceIdSupportMessage", traceId)}</p>
            </#if>
            <#if !skipLink??>
                <@buttons.actionGroup>
                    <#if client?? && client.baseUrl?has_content>
                        <a id="backToApplication" class="pk-button pk-primary" href="${client.baseUrl}"><span>${msg("backToApplication")}</span><@buttons.arrowIcon/></a>
                    <#else>
                        <a id="backToConsole" class="pk-back" href="/">${msg("petasusGoToConsole")}</a>
                    </#if>
                </@buttons.actionGroup>
            </#if>
        </div>
    </#if>
</@layout.registrationLayout>
