# Petasus theme for the login service (Keycloak 26.8.2)

The login service's screens look like the console's login page
(ks-console `src/core/containers/Login` and its `Hero`), in both accents and the
console's five languages, and never name the product behind them.

| Type | What it covers |
|---|---|
| `login` | Every login screen: login, first-login password, authenticator app set-up and code, security key and passkey, "try another way", company sign-in and its profile review, reset by email, errors and notices, logout, kubectl's device code, and the screens the console's Security tab opens (`kc_action`). Extends `keycloak.v2` for its page logic; PatternFly is not loaded. |
| `email` | Password reset, email verification, actions an admin asks for, company sign-in link, SMTP test: HTML and text. |
| `admin` | The admin console keeps its own screens with the console's logo, favicon and purple. |

## What it needs from its surroundings

- **The console on the same origin.** Fonts (`/assets/resources/fonts/Pretendard-*.woff`),
  the logo (`/assets/logo.svg`) and the favicon (`/assets/favicon.ico`) are the console's;
  the theme carries none. The console proxies `/auth/` to the service.
- **Realm settings** (the chart sets them):
  - themes `petasus` for login, email and admin;
  - internationalization on, supported locales `en, ko, ja, zh-CN, zh-TW`. Keycloak 26.8.2
    reads `messages_zh_Hans` for `zh-CN` and `messages_zh_Hant` for `zh-TW`; realm locales
    `zh-Hans`/`zh-Hant` cannot select Traditional Chinese. The console sends `ui_locales`
    `zh-CN` for `zh` and `zh-TW` for `tc`;
  - display name = the console title: it is the tab title and the TOTP issuer;
    `webAuthnPolicyRpEntityName` and `webAuthnPolicyPasswordlessRpEntityName` the same;
  - with `webAuthnPolicyPasswordlessPasskeysEnabled` (https consoles) the login page adds
    "Log in with a passkey" under the "or" line, outlined like the company sign-ins;
  - `resetPasswordAllowed` only with SMTP: without it the login page says "ask your
    platform admin", as the console's does.
- **Cookies.** The console's `accent` cookie (`purple`, `green`) picks the colours before
  the page paints. The language comes from `ui_locales`; the login form posts it back as
  `kc_locale`, so the screens after the password keep it even when the user's profile
  holds another language, and the profile takes it for later mails.

## Packaging

Each type goes into its own ConfigMap (all under 1 MiB together) mounted at
`/opt/keycloak/themes/petasus/<type>/`. ConfigMap keys cannot hold `/`, so nested files
(`messages/…`, `resources/css/…`, `html/…`) are flattened and mapped back with `items`.

## Messages

`messages_en.properties` is the source; `ko`, `zh_Hans`, `zh_Hant` and `ja` carry the same
keys in the same order. Keys starting with `petasus` are the theme's own; the others replace
Keycloak's wording with the console's ("Log In", never "Sign In", no product or realm
names). Terms follow ks-console `docs/localization/glossary-*.md`, and strings the
console's login page has are copied from its `locales/*/l10n-logIn.js`.
