{{- /*
The realm petasus, in two files built from the pieces below.

realm-import.json (keycloak.realm.initial) is the realm the first start of Keycloak
imports (--import-realm). Keycloak skips it once the realm exists, so what is only in it is
the first install's and belongs to the administrators afterwards: the password policy, the
session times, brute force detection, the MFA policy (the mapping of the role
petasus-mfa-required), identity providers, users and group memberships. The console's
login settings and Keycloak's admin console change them, and no upgrade puts them back.

realm-config.json (keycloak.realm.managed) is what keycloak-config-cli applies after every
install and upgrade: the chart's own settings, put back when someone changes them. A field
the file leaves out, the realm keeps as it is; that is how the administrators' settings
survive. Lists the tool manages as a whole are set in configCli's job (config-cli.yaml) so
that it never deletes what the chart did not make (workspace groups, application clients).

Both are written as YAML here and printed as JSON.
*/ -}}

{{- /* The theme types the chart ships (files/themes/petasus/<type>/), as a dict. */ -}}
{{- define "keycloak.themeTypes" -}}
{{- $types := dict }}
{{- range $path, $_ := .Files.Glob "files/themes/petasus/*/theme.properties" }}
{{- $_ := set $types (base (dir $path)) true }}
{{- end }}
{{- toJson $types }}
{{- end }}

{{- /*
Settings the chart keeps, in both files. The theme of a type is set only when the chart
ships it; without one Keycloak shows its own.
*/ -}}
{{- define "keycloak.realm.settings" -}}
{{- $https := include "keycloak.https" . }}
{{- $webauthn := include "keycloak.webauthn" . }}
{{- $themes := include "keycloak.themeTypes" . | fromJson }}
realm: petasus
enabled: true
displayName: {{ .Values.brand.title | quote }}
# An http console cannot meet external: Keycloak would refuse every request from outside
# the private address ranges.
sslRequired: {{ ternary "external" "none" (eq $https "true") }}
registrationAllowed: false
registrationEmailAsUsername: false
loginWithEmailAllowed: true
duplicateEmailsAllowed: false
editUsernameAllowed: false
# The console's login page has no "keep me signed in".
rememberMe: false
internationalizationEnabled: true
# Keycloak 26.8 matches ui_locales by language and country only: zh-Hans and zh-Hant would
# both pick the first Chinese locale. The console sends zh-CN and zh-TW; the themes' message
# files are messages_zh_Hans and messages_zh_Hant.
supportedLocales: [en, ko, ja, zh-CN, zh-TW]
defaultLocale: en
{{- if hasKey $themes "login" }}
loginTheme: petasus
{{- end }}
{{- if hasKey $themes "email" }}
emailTheme: petasus
{{- end }}
{{- if hasKey $themes "admin" }}
adminTheme: petasus
{{- end }}
# What a passkey or security key dialog names (the default would be "keycloak"). Where
# browsers allow WebAuthn (keycloak.webauthn) a registered passkey also signs in from the
# username field.
webAuthnPolicyRpEntityName: {{ .Values.brand.title | quote }}
webAuthnPolicyPasswordlessRpEntityName: {{ .Values.brand.title | quote }}
webAuthnPolicyPasswordlessPasskeysEnabled: {{ eq $webauthn "true" }}
# No offline tokens: no client offers the scope offline_access (new clients do not get it
# either: keycloak.realm.managed) and users do not hold the role (default roles,
# config-cli.yaml). Should one be issued anyway, it lives no longer than an SSO session.
offlineSessionIdleTimeout: {{ int .Values.session.idleTimeout }}
offlineSessionMaxLifespanEnabled: true
offlineSessionMaxLifespan: {{ int .Values.session.maxLifespan }}
# Login and admin events, in the database for the admin console and through jboss-logging
# into Keycloak's log. Admin events leave the representation out: it can carry a client
# secret.
eventsEnabled: true
eventsExpiration: {{ mul .Values.eventsExpirationDays 86400 }}
eventsListeners: [jboss-logging]
adminEventsEnabled: true
adminEventsDetailsEnabled: false
attributes:
  adminEventsExpiration: {{ mul .Values.eventsExpirationDays 86400 | quote }}
{{- end }}

{{- /*
The settings that are the first install's only: the console's login settings and the admin
console change them afterwards.
*/ -}}
{{- define "keycloak.realm.adminOwned" -}}
passwordPolicy: "length(8) and maxLength(32) and upperCase(1) and lowerCase(1) and digits(1) and specialChars(1) and notUsername"
ssoSessionIdleTimeout: {{ int .Values.session.idleTimeout }}
ssoSessionMaxLifespan: {{ int .Values.session.maxLifespan }}
bruteForceProtected: true
permanentLockout: false
failureFactor: 10
waitIncrementSeconds: 60
maxFailureWaitSeconds: 900
{{- end }}

{{- /*
The mail server (D9: chart values only, the console has no screen for it), with what
depends on it: forgotten passwords and e-mail verification. Applied on every upgrade, so
smtp.enabled false takes a server set in the admin console away again. The password is
read from smtp.passwordSecret into keycloak-config-cli's environment (config-cli.yaml).
*/ -}}
{{- define "keycloak.realm.smtp" -}}
{{- with .Values.smtp }}
{{- if .enabled }}
resetPasswordAllowed: true
verifyEmail: true
smtpServer:
  host: {{ required "smtp.host is required with smtp.enabled" .host | quote }}
  port: {{ .port | quote }}
  from: {{ required "smtp.from is required with smtp.enabled" .from | quote }}
  fromDisplayName: {{ default $.Values.brand.title .fromDisplayName | quote }}
  starttls: {{ .starttls | quote }}
  ssl: {{ .ssl | quote }}
  auth: {{ .auth | quote }}
  {{- if .auth }}
  user: {{ .user | quote }}
  password: $(env:SMTP_PASSWORD_JSON)
  {{- end }}
{{- else }}
resetPasswordAllowed: false
verifyEmail: false
smtpServer: {}
{{- end }}
{{- end }}
{{- end }}

{{- /*
The user profile. Usernames follow the console's rule for KubeSphere user names (lowercase
letters, digits, '-' and '.'). No attribute is required: the console does not ask for
names, a user may have no e-mail address, and a required attribute a user lacks stops the
login at "Account is not fully set up". Only administrators change an e-mail address (the
console's user management, D32): it is a login name and where password resets go, so a
user who could change it could keep an account a stolen session gave them. ks_username, the
KubeSphere user name ks-apiserver writes and the token mappers send, is declared, or
Keycloak would drop it; only administrators see it.
*/ -}}
{{- define "keycloak.realm.userProfile" -}}
attributes:
- name: username
  displayName: "${username}"
  validations:
    length: {min: 1, max: 255}
    username-prohibited-characters: {}
    up-username-not-idn-homograph: {}
    pattern:
      pattern: "^[a-z0-9]([-a-z0-9]*[a-z0-9])?(\\.[a-z0-9]([-a-z0-9]*[a-z0-9])?)*$"
      error-message: invalidUsernameMessage
  permissions: {view: [admin, user], edit: [admin, user]}
  multivalued: false
- name: email
  displayName: "${email}"
  validations:
    email: {}
    length: {max: 255}
  permissions: {view: [admin, user], edit: [admin]}
  multivalued: false
- name: firstName
  displayName: "${firstName}"
  validations:
    length: {max: 255}
    person-name-prohibited-characters: {}
  permissions: {view: [admin, user], edit: [admin, user]}
  multivalued: false
- name: lastName
  displayName: "${lastName}"
  validations:
    length: {max: 255}
    person-name-prohibited-characters: {}
  permissions: {view: [admin, user], edit: [admin, user]}
  multivalued: false
- name: ks_username
  displayName: KubeSphere user name
  validations:
    length: {max: 255}
  permissions: {view: [admin], edit: [admin]}
  multivalued: false
groups:
- name: user-metadata
  displayHeader: User metadata
  displayDescription: Attributes, which refer to user metadata
{{- end }}

{{- /*
The MFA policy's role. Where it is mapped is the policy (none: nowhere; admins: the group
/platform/admins; all: the composite default-roles-petasus), and the administrators' to
change; the chart only keeps the role.
*/ -}}
{{- define "keycloak.realm.roles" -}}
realm:
- name: petasus-mfa-required
  description: Users with this role must set up a second factor before they finish signing in.
  composite: false
  clientRole: false
{{- end }}

{{- /*
Required actions the console starts as application-initiated actions (kc_action) and the
login flow needs; e-mail verification goes with the mail server.
*/ -}}
{{- define "keycloak.realm.requiredActions" -}}
- {alias: UPDATE_PROFILE, name: Update Profile, providerId: UPDATE_PROFILE, enabled: true, defaultAction: false, priority: 40, config: {}}
- {alias: VERIFY_EMAIL, name: Verify Email, providerId: VERIFY_EMAIL, enabled: {{ .Values.smtp.enabled }}, defaultAction: false, priority: 50, config: {}}
- {alias: CONFIGURE_TOTP, name: Configure OTP, providerId: CONFIGURE_TOTP, enabled: true, defaultAction: false, priority: 54, config: {}}
- {alias: UPDATE_PASSWORD, name: Update Password, providerId: UPDATE_PASSWORD, enabled: true, defaultAction: false, priority: 57, config: {}}
- {alias: delete_credential, name: Delete Credential, providerId: delete_credential, enabled: true, defaultAction: false, priority: 110, config: {}}
# Linking an external account to one's own (application-initiated) would be a second way
# in, past the password and the second factor; the console offers no linking.
- {alias: idp_link, name: Linking Identity Provider, providerId: idp_link, enabled: false, defaultAction: false, priority: 120, config: {}}
{{- end }}

{{- /*
The WebAuthn required actions (security key, passkey), enabled as the argument says
("true" or "false").
*/ -}}
{{- define "keycloak.realm.webauthnActions" -}}
- {alias: webauthn-register, name: Webauthn Register, providerId: webauthn-register, enabled: {{ . }}, defaultAction: false, priority: 80, config: {}}
- {alias: webauthn-register-passwordless, name: Webauthn Register Passwordless, providerId: webauthn-register-passwordless, enabled: {{ . }}, defaultAction: false, priority: 90, config: {}}
{{- end }}

{{- /*
What an upgrade does to the WebAuthn required actions: "false" where browsers have no
WebAuthn (http, or https on an IP address: keycloak.webauthn); where they have it, the
actions are the administrators' (the console's login settings turn the methods on and
off), so nothing, except "true" once when the console has just become WebAuthn-capable
(the identity provider Secret the release wrote last says webauthn: false). The first
install sets them from keycloak.webauthn (keycloak.realm.initial).
*/ -}}
{{- define "keycloak.realm.webauthnUpgrade" -}}
{{- if ne (include "keycloak.webauthn" .) "true" }}false
{{- else }}
{{- $secret := lookup "v1" "Secret" .Release.Namespace "identity-provider-keycloak" }}
{{- if and $secret $secret.data (index $secret.data "configuration.yaml") }}
{{- $previous := index $secret.data "configuration.yaml" | b64dec | fromYaml }}
{{- if and $previous.loginService (eq (toString $previous.loginService.webauthn) "false") }}true{{ end }}
{{- end }}
{{- end }}
{{- end }}

{{- /*
The rest of Keycloak 26.8's required actions, for the first import, which replaces
Keycloak's list with the file's.
*/ -}}
{{- define "keycloak.realm.otherRequiredActions" -}}
- {alias: TERMS_AND_CONDITIONS, name: Terms and Conditions, providerId: TERMS_AND_CONDITIONS, enabled: false, defaultAction: false, priority: 20, config: {}}
- {alias: delete_account, name: Delete Account, providerId: delete_account, enabled: false, defaultAction: false, priority: 60, config: {}}
- {alias: UPDATE_EMAIL, name: Update Email, providerId: UPDATE_EMAIL, enabled: false, defaultAction: false, priority: 70, config: {}}
- {alias: VERIFY_PROFILE, name: Verify Profile, providerId: VERIFY_PROFILE, enabled: true, defaultAction: false, priority: 100, config: {}}
- {alias: CONFIGURE_RECOVERY_AUTHN_CODES, name: Recovery Authentication Codes, providerId: CONFIGURE_RECOVERY_AUTHN_CODES, enabled: false, defaultAction: false, priority: 130, config: {}}
- {alias: update_user_locale, name: Update User Locale, providerId: update_user_locale, enabled: true, defaultAction: false, priority: 1000, config: {}}
{{- end }}

{{- /*
The second factor, as two conditional sub-flows of a flow named by the argument's prefix
(dict root, prefix, passkey), shared by the browser, post-broker-login and reset flows:

- "<prefix> second factor": a user who has OTP or a security key (WebAuthn, where browsers
  allow it) set up is asked for it, with "try another way" between the two;
- "<prefix> second factor setup": a user who has neither but holds petasus-mfa-required
  must set up OTP before the flow ends (CONFIGURE_TOTP); a security key or passkey can be
  added afterwards from the console.

With passkey, a sign-in with a passkey (already two factors) is asked for nothing more.
*/ -}}
{{- define "keycloak.realm.secondFactorFlows" -}}
{{- $webauthn := eq (include "keycloak.webauthn" .root) "true" }}
- alias: {{ .prefix }} second factor
  description: Asks a user who has a second factor for it
  providerId: basic-flow
  topLevel: false
  builtIn: false
  authenticationExecutions:
  - {authenticator: conditional-user-configured, requirement: REQUIRED, priority: 10, authenticatorFlow: false, userSetupAllowed: false}
  {{- if .passkey }}
  - {authenticator: conditional-credential, authenticatorConfig: {{ .prefix }} not passkey, requirement: REQUIRED, priority: 20, authenticatorFlow: false, userSetupAllowed: false}
  {{- end }}
  - {authenticator: auth-otp-form, requirement: ALTERNATIVE, priority: 30, authenticatorFlow: false, userSetupAllowed: false}
  - {authenticator: webauthn-authenticator, requirement: {{ ternary "ALTERNATIVE" "DISABLED" $webauthn }}, priority: 40, authenticatorFlow: false, userSetupAllowed: false}
- alias: {{ .prefix }} second factor setup
  description: Makes a user who must have a second factor and has none set up OTP
  providerId: basic-flow
  topLevel: false
  builtIn: false
  authenticationExecutions:
  - {authenticator: conditional-user-role, authenticatorConfig: {{ .prefix }} mfa required, requirement: REQUIRED, priority: 10, authenticatorFlow: false, userSetupAllowed: false}
  - {authenticator: conditional-sub-flow-executed, authenticatorConfig: {{ .prefix }} no second factor, requirement: REQUIRED, priority: 20, authenticatorFlow: false, userSetupAllowed: false}
  {{- if .passkey }}
  - {authenticator: conditional-credential, authenticatorConfig: {{ .prefix }} setup not passkey, requirement: REQUIRED, priority: 30, authenticatorFlow: false, userSetupAllowed: false}
  {{- end }}
  - {authenticator: auth-otp-form, requirement: REQUIRED, priority: 40, authenticatorFlow: false, userSetupAllowed: false}
{{- end }}

{{- define "keycloak.realm.secondFactorConfigs" -}}
{{- if .passkey }}
- alias: {{ .prefix }} not passkey
  config: {credentials: webauthn-passwordless, included: "false"}
- alias: {{ .prefix }} setup not passkey
  config: {credentials: webauthn-passwordless, included: "false"}
{{- end }}
- alias: {{ .prefix }} mfa required
  config: {condUserRole: petasus-mfa-required, negate: "false"}
- alias: {{ .prefix }} no second factor
  config: {flow_to_check: {{ .prefix }} second factor, check_result: not-executed}
{{- end }}

{{- /*
The realm's flows, all chart-managed:

- petasus-browser, the browser flow: the SSO cookie, an identity provider named by
  kc_idp_hint, then username and password and the second factor.
- petasus-post-broker, the post-login flow of identity providers: a login through an
  identity provider is finished by the broker and never runs the browser flow's second
  factor, so this one runs it after every such login. config-cli.yaml sets it on every
  identity provider that has no post-login flow; one added in the admin console needs it
  set there (README).
- petasus-reset-credentials, "forgot password" (with a mail server): the e-mailed link, then
  the second factor the user has, then the new password. Keycloak's own flow ends by making
  the user set up a new OTP instead of asking for the old one, so the mailbox alone would
  get past the second factor.
- petasus-direct-grant, the password grant: refused. No client of the realm may sign users
  in with a password alone (KC-12); the clients' own switches are off too.
*/ -}}
{{- define "keycloak.realm.flows" -}}
browserFlow: petasus-browser
resetCredentialsFlow: petasus-reset-credentials
directGrantFlow: petasus-direct-grant
authenticationFlows:
- alias: petasus-browser
  description: Browser login of the console (SSO cookie, identity provider, password and a second factor)
  providerId: basic-flow
  topLevel: true
  builtIn: false
  authenticationExecutions:
  - {authenticator: auth-cookie, requirement: ALTERNATIVE, priority: 10, authenticatorFlow: false, userSetupAllowed: false}
  - {authenticator: identity-provider-redirector, requirement: ALTERNATIVE, priority: 25, authenticatorFlow: false, userSetupAllowed: false}
  - {flowAlias: petasus-browser forms, requirement: ALTERNATIVE, priority: 30, authenticatorFlow: true, userSetupAllowed: false}
- alias: petasus-browser forms
  description: Username and password, then the second factor
  providerId: basic-flow
  topLevel: false
  builtIn: false
  authenticationExecutions:
  - {authenticator: auth-username-password-form, requirement: REQUIRED, priority: 10, authenticatorFlow: false, userSetupAllowed: false}
  - {flowAlias: petasus-browser second factor, requirement: CONDITIONAL, priority: 20, authenticatorFlow: true, userSetupAllowed: false}
  - {flowAlias: petasus-browser second factor setup, requirement: CONDITIONAL, priority: 30, authenticatorFlow: true, userSetupAllowed: false}
{{ include "keycloak.realm.secondFactorFlows" (dict "root" . "prefix" "petasus-browser" "passkey" true) }}
- alias: petasus-post-broker
  description: After a login through an identity provider, the second factor of the browser flow
  providerId: basic-flow
  topLevel: true
  builtIn: false
  authenticationExecutions:
  - {flowAlias: petasus-post-broker second factor, requirement: CONDITIONAL, priority: 10, authenticatorFlow: true, userSetupAllowed: false}
  - {flowAlias: petasus-post-broker second factor setup, requirement: CONDITIONAL, priority: 20, authenticatorFlow: true, userSetupAllowed: false}
  # A flow of conditional sub-flows alone fails when none of them runs (a user without a
  # second factor, under the policy "none"); this step makes it succeed then.
  - {authenticator: allow-access-authenticator, requirement: REQUIRED, priority: 30, authenticatorFlow: false, userSetupAllowed: false}
{{ include "keycloak.realm.secondFactorFlows" (dict "root" . "prefix" "petasus-post-broker" "passkey" false) }}
- alias: petasus-reset-credentials
  description: Forgot password, the e-mailed link and then the second factor the user has
  providerId: basic-flow
  topLevel: true
  builtIn: false
  authenticationExecutions:
  - {authenticator: reset-credentials-choose-user, requirement: REQUIRED, priority: 10, authenticatorFlow: false, userSetupAllowed: false}
  - {authenticator: reset-credential-email, requirement: REQUIRED, priority: 20, authenticatorFlow: false, userSetupAllowed: false}
  - {flowAlias: petasus-reset-credentials second factor, requirement: CONDITIONAL, priority: 30, authenticatorFlow: true, userSetupAllowed: false}
  - {flowAlias: petasus-reset-credentials second factor setup, requirement: CONDITIONAL, priority: 40, authenticatorFlow: true, userSetupAllowed: false}
  - {authenticator: reset-password, requirement: REQUIRED, priority: 50, authenticatorFlow: false, userSetupAllowed: false}
{{ include "keycloak.realm.secondFactorFlows" (dict "root" . "prefix" "petasus-reset-credentials" "passkey" false) }}
- alias: petasus-direct-grant
  description: The password grant, refused
  providerId: basic-flow
  topLevel: true
  builtIn: false
  authenticationExecutions:
  - {authenticator: deny-access-authenticator, requirement: REQUIRED, priority: 10, authenticatorFlow: false, userSetupAllowed: false}
authenticatorConfig:
{{ include "keycloak.realm.secondFactorConfigs" (dict "prefix" "petasus-browser" "passkey" true) }}
{{ include "keycloak.realm.secondFactorConfigs" (dict "prefix" "petasus-post-broker" "passkey" false) }}
{{ include "keycloak.realm.secondFactorConfigs" (dict "prefix" "petasus-reset-credentials" "passkey" false) }}
{{- end }}

{{- /*
The clients. Their secrets are read from the job's environment (keycloak-clients) when
keycloak-config-cli substitutes $(env:...), so they are not in the ConfigMap.
*/ -}}
{{- define "keycloak.realm.clients" -}}
{{- $console := include "keycloak.consoleURL" . }}
{{- $ksUsername := dict "name" "ks_username" "protocol" "openid-connect" "protocolMapper" "oidc-usermodel-attribute-mapper" "consentRequired" false "config" (dict "user.attribute" "ks_username" "claim.name" "ks_username" "jsonType.label" "String" "id.token.claim" "true" "access.token.claim" "true" "userinfo.token.claim" "true" "introspection.token.claim" "true") }}
# The console's client: ks-apiserver signs users in with it (authorization code), and
# Keycloak tells ks-apiserver of every ended session (back-channel logout).
- clientId: ks-console
  name: {{ .Values.brand.title | quote }}
  enabled: true
  protocol: openid-connect
  publicClient: false
  clientAuthenticatorType: client-secret
  secret: $(env:KS_CONSOLE_CLIENT_SECRET)
  standardFlowEnabled: true
  implicitFlowEnabled: false
  directAccessGrantsEnabled: false
  serviceAccountsEnabled: false
  consentRequired: false
  frontchannelLogout: false
  # Its tokens carry the user and the groups mapper's claim, not the user's roles, and
  # cannot be offline tokens.
  fullScopeAllowed: false
  defaultClientScopes: [acr, basic, email, profile, roles, web-origins]
  optionalClientScopes: []
  rootUrl: {{ $console | quote }}
  baseUrl: {{ printf "%s/" $console | quote }}
  redirectUris: [{{ printf "%s/oauth/redirect/keycloak" $console | quote }}]
  webOrigins: []
  attributes:
    post.logout.redirect.uris: {{ printf "%s/login" $console | quote }}
    backchannel.logout.url: {{ printf "%s/oauth/backchannel-logout/keycloak" (trimSuffix "/" .Values.apiserverURL) | quote }}
    backchannel.logout.session.required: "true"
    backchannel.logout.revoke.offline.tokens: "false"
  protocolMappers:
  - name: groups
    protocol: openid-connect
    protocolMapper: oidc-group-membership-mapper
    consentRequired: false
    config:
      full.path: "true"
      claim.name: groups
      id.token.claim: "true"
      access.token.claim: "true"
      userinfo.token.claim: "true"
      introspection.token.claim: "true"
  - {{ toJson $ksUsername }}
# ks-apiserver's own account for Keycloak's admin API (users, groups, sessions, the login
# settings, application clients). Its service account is realm-admin of the realm: adding
# a user to /platform/admins, which grants realm-admin, takes realm-admin. The admin API
# takes only tokens with the scope kc-admin-api, which Keycloak does not give a new client
# by default.
- clientId: ks-apiserver-admin
  name: ks-apiserver
  enabled: true
  protocol: openid-connect
  publicClient: false
  clientAuthenticatorType: client-secret
  secret: $(env:KS_APISERVER_ADMIN_CLIENT_SECRET)
  standardFlowEnabled: false
  implicitFlowEnabled: false
  directAccessGrantsEnabled: false
  serviceAccountsEnabled: true
  consentRequired: false
  frontchannelLogout: false
  defaultClientScopes: [acr, basic, email, kc-admin-api, profile, roles, service_account, web-origins]
  optionalClientScopes: []
# kubectl through kubelogin (kubectl oidc-login): a browser login to the local redirect
# kubelogin listens on, or the device authorization grant without a browser. The API
# server takes the user name from ks_username. PKCE is not required: Keycloak would then
# require it of the device grant too, which kubelogin does not send.
- clientId: kubectl
  name: kubectl
  enabled: true
  protocol: openid-connect
  publicClient: true
  standardFlowEnabled: true
  implicitFlowEnabled: false
  directAccessGrantsEnabled: false
  serviceAccountsEnabled: false
  consentRequired: false
  frontchannelLogout: false
  fullScopeAllowed: false
  # No offline tokens, which would outlive the SSO session.
  defaultClientScopes: [acr, basic, email, profile, roles, web-origins]
  optionalClientScopes: []
  redirectUris: [http://localhost:8000, http://localhost:18000]
  webOrigins: []
  attributes:
    oauth2.device.authorization.grant.enabled: "true"
    pkce.code.challenge.method: ""
  protocolMappers:
  - {{ toJson $ksUsername }}
# Keycloak's own clients of the realm, only as far as the grants go. None takes a password
# directly (the resource owner password grant): that grant skips petasus-browser, so a
# password alone, without the WebAuthn or passkey second factor and the MFA policy, would
# get a token (KC-12), and admin-cli's would carry the admin API's scope and the user's
# realm administration. The realm's direct grant flow refuses it as well.
# Nothing uses admin-cli in this realm (keycloak-config-cli signs in to master; ks-apiserver
# and keycloak-migrate use ks-apiserver-admin; the admin console is security-admin-console
# with the browser flow), so it is off with no grant and no scope. broker and
# realm-management are bearer-only, issue no tokens, and Keycloak refuses changes to them.
{{- range list "account" "account-console" "security-admin-console" "admin-cli" }}
- clientId: {{ . }}
  implicitFlowEnabled: false
  directAccessGrantsEnabled: false
  {{- if eq . "admin-cli" }}
  enabled: false
  standardFlowEnabled: false
  serviceAccountsEnabled: false
  defaultClientScopes: []
  optionalClientScopes: []
  {{- end }}
  attributes:
    oauth2.device.authorization.grant.enabled: "false"
    oidc.ciba.grant.enabled: "false"
{{- end }}
{{- end }}

{{- /*
The groups. /workspaces holds a group per workspace, which ks-controller-manager makes;
/platform/admins administer the realm too (KC-13), through the admin console at
<consoleURL>/auth/admin/petasus/console/. The managed file leaves the groups' realm roles
out, so the MFA policy's mapping stays the administrators'.
*/ -}}
{{- define "keycloak.realm.groups" -}}
- name: platform
  subGroups:
  - name: admins
    clientRoles:
      realm-management: [realm-admin]
  - name: regular
- name: workspaces
{{- end }}

{{- define "keycloak.realm.managed" -}}
{{ include "keycloak.realm.smtp" . }}
{{ include "keycloak.realm.settings" . }}
  # keycloak-config-cli applies userProfile only with this attribute.
  userProfileEnabled: "true"
# The optional scopes a new client gets, without offline_access. Only here: in the first
# import a list of optional scopes alone would leave the realm with no default ones.
defaultOptionalClientScopes: [address, phone, microprofile-jwt, organization]
userProfile:
{{ include "keycloak.realm.userProfile" . | indent 2 }}
roles:
{{ include "keycloak.realm.roles" . | indent 2 }}
groups:
{{ include "keycloak.realm.groups" . }}
clients:
{{ include "keycloak.realm.clients" . }}
users:
- username: service-account-ks-apiserver-admin
  enabled: true
  serviceAccountClientId: ks-apiserver-admin
  clientRoles:
    realm-management: [realm-admin]
requiredActions:
{{ include "keycloak.realm.requiredActions" . }}
{{- with include "keycloak.realm.webauthnUpgrade" . }}
{{ include "keycloak.realm.webauthnActions" . }}
{{- end }}
{{ include "keycloak.realm.flows" . }}
{{- end }}

{{- /*
The realm user admin is KubeSphere's admin (D26): its ID is the one petasus-resource-manager
chose, and its first password, temporary, is the one the hub shows. Keycloak fills the
${...} placeholders from its environment when it imports the file. It has no e-mail
address: one address on every cluster would receive every cluster's password resets; the
customer sets theirs. A migrated cluster gets no admin (keycloak.bootstrap).
*/ -}}
{{- define "keycloak.realm.initial" -}}
{{ include "keycloak.realm.settings" . }}
{{ include "keycloak.realm.adminOwned" . }}
roles:
{{ include "keycloak.realm.roles" . | indent 2 }}
groups:
{{ include "keycloak.realm.groups" . }}
{{- if (include "keycloak.bootstrap" . | fromJson).admin }}
users:
- id: "${PETASUS_ADMIN_USER_ID}"
  username: admin
  enabled: true
  attributes:
    ks_username: [admin]
  groups: [/platform/admins]
  requiredActions: [UPDATE_PASSWORD]
  credentials:
  - type: password
    value: "${PETASUS_ADMIN_PASSWORD}"
    temporary: true
{{- end }}
requiredActions:
{{ include "keycloak.realm.requiredActions" . }}
{{ include "keycloak.realm.webauthnActions" (include "keycloak.webauthn" . | eq "true" | toString) }}
{{ include "keycloak.realm.otherRequiredActions" . }}
components:
  org.keycloak.userprofile.UserProfileProvider:
  - providerId: declarative-user-profile
    subComponents: {}
    config:
      kc.user.profile.config:
      - {{ include "keycloak.realm.userProfile" . | fromYaml | toJson | quote }}
{{- end }}

{{- /*
A realm file as JSON: the YAML above, parsed, or a failed render naming the file. fromYaml
gives a map with the key Error for YAML it cannot parse, and that map would otherwise be
written as the realm.
*/ -}}
{{- define "keycloak.realmJSON" -}}
{{- $realm := include .name .root | fromYaml }}
{{- if hasKey $realm "Error" }}
{{- fail (printf "%s is not valid YAML: %s" .name (get $realm "Error")) }}
{{- end }}
{{- toPrettyJson $realm }}
{{- end }}
