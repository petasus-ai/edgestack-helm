{{- define "keycloak.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
app.kubernetes.io/part-of: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- /*
consoleURL, checked: scheme, host and port, no path. Every public address of the realm is
built from it.
*/ -}}
{{- /*
The realm's display name: the issuer an authenticator app shows beside the user name, the
service a passkey dialog names, the login page's tab title and the mail's sender name.
"<cluster> · <shortTitle>" for a cluster that brand.cluster names, else brand.title.
*/ -}}
{{- define "keycloak.displayName" -}}
{{- if .Values.brand.cluster -}}
{{- printf "%s · %s" .Values.brand.cluster .Values.brand.shortTitle -}}
{{- else -}}
{{- .Values.brand.title -}}
{{- end -}}
{{- end }}

{{- define "keycloak.consoleURL" -}}
{{- $url := required "consoleURL is required, e.g. https://10.1.2.3:30880" .Values.consoleURL | trimSuffix "/" }}
{{- if not (regexMatch "^https?://[^/?#]+$" $url) }}
{{- fail (printf "consoleURL %q must be http(s)://host[:port], without a path" $url) }}
{{- end }}
{{- $url }}
{{- end }}

{{- /* "true" when the console is served over https, else "". */ -}}
{{- define "keycloak.https" -}}
{{- if hasPrefix "https://" (include "keycloak.consoleURL" .) }}true{{ end }}
{{- end }}

{{- /*
"true" when browsers allow WebAuthn (security keys, passkeys) on the console, else "": an
https console addressed by a DNS name. A WebAuthn relying party is a domain; browsers
refuse an IP address ("This is an invalid domain"), and RM gives a console without a
published domain https://<IP>:<port>. Such a console is like an http one for WebAuthn: OTP
only.
*/ -}}
{{- define "keycloak.webauthn" -}}
{{- if include "keycloak.https" . }}
{{- $host := regexReplaceAll "^https://([^/:]+|\\[[^]]*\\])(:[0-9]+)?$" (include "keycloak.consoleURL" .) "${1}" }}
{{- if not (or (hasPrefix "[" $host) (regexMatch "^[0-9]+(\\.[0-9]+){3}$" $host)) }}true{{ end }}
{{- end }}
{{- end }}

{{- define "keycloak.issuer" -}}
{{- include "keycloak.consoleURL" . }}/auth/realms/petasus
{{- end }}

{{- /* Keycloak inside the cluster, with its relative path. */ -}}
{{- define "keycloak.internalURL" -}}
http://keycloak.{{ .Release.Namespace }}.svc:8080/auth
{{- end }}

{{- define "keycloak.image" -}}
{{ .Values.image.repository }}:{{ .Values.image.tag }}
{{- end }}

{{- define "keycloak.postgresImage" -}}
{{ .Values.postgres.image.repository }}:{{ .Values.postgres.image.tag }}
{{- end }}

{{- /*
The container security context of every container of the chart, with the pod's
runAsNonRoot and RuntimeDefault seccomp profile: the restricted Pod Security profile.
*/ -}}
{{- define "keycloak.containerSecurityContext" -}}
allowPrivilegeEscalation: false
capabilities:
  drop: [ALL]
{{- end }}

{{- /*
The client secrets, generated at the first install and read back from the Secret
keycloak-clients after that, so the realm's clients and ks-apiserver's identity provider
configuration keep the same values. Prints a JSON object {ks-console, ks-apiserver-admin}.
*/ -}}
{{- define "keycloak.clientSecrets" -}}
{{- $existing := lookup "v1" "Secret" .Release.Namespace "keycloak-clients" }}
{{- $data := dict }}
{{- if and $existing $existing.data }}
{{- $data = $existing.data }}
{{- end }}
{{- $secrets := dict }}
{{- range $client := list "ks-console" "ks-apiserver-admin" }}
{{- $value := "" }}
{{- if index $data $client }}
{{- $value = index $data $client | b64dec }}
{{- end }}
{{- if not $value }}
{{- $value = randAlphaNum 40 }}
{{- end }}
{{- $_ := set $secrets $client $value }}
{{- end }}
{{- toJson $secrets }}
{{- end }}

{{- /*
What the bootstrap Secret holds, as JSON {"admin": bool, "uid": "..."}. master-username and
master-password are required; installing without them fails here, with the Secret's name,
rather than later in a pod that cannot start. admin-user-id and admin-password are there
for a new cluster, whose realm user admin is KubeSphere's admin (D26); on a cluster that
existed before and is migrated (KC-11), petasus-resource-manager leaves them out, the realm
gets no admin and ks-apiserver no bootstrapAdmin link, and the local admin stays the
customer's emergency account. When the chart is only rendered (helm template), lookup sees
no cluster and the result is a new cluster's, with an empty ID.
*/ -}}
{{- define "keycloak.bootstrap" -}}
{{- $result := dict "admin" true "uid" "" }}
{{- if lookup "v1" "Namespace" "" .Release.Namespace }}
{{- $secret := lookup "v1" "Secret" .Release.Namespace .Values.bootstrapSecret }}
{{- $data := dict }}
{{- if and $secret $secret.data }}
{{- $data = $secret.data }}
{{- end }}
{{- if not (and (index $data "master-username") (index $data "master-password")) }}
{{- fail (printf "Secret %s/%s with the keys master-username and master-password is missing: petasus-resource-manager writes it before it installs this chart" .Release.Namespace .Values.bootstrapSecret) }}
{{- end }}
{{- if and (index $data "admin-user-id") (index $data "admin-password") }}
{{- $_ := set $result "uid" (index $data "admin-user-id" | b64dec) }}
{{- else }}
{{- $_ := set $result "admin" false }}
{{- end }}
{{- end }}
{{- toJson $result }}
{{- end }}

{{- /*
A checksum of the files under a directory of the chart, to restart Keycloak when a theme or
a provider changes: production mode caches themes, and providers are built in at start.
*/ -}}
{{- define "keycloak.filesChecksum" -}}
{{- $sums := list }}
{{- range $path, $_ := $.root.Files.Glob (printf "%s/**" $.dir) }}
{{- $sums = append $sums (printf "%s:%s" $path ($.root.Files.Get $path | sha256sum)) }}
{{- end }}
{{- join "\n" $sums | sha256sum }}
{{- end }}

{{- /*
The ConfigMap key of a theme file: its path under the theme type, '/' written as '__'.
*/ -}}
{{- define "keycloak.fileKey" -}}
{{- $key := replace "/" "__" . }}
{{- if not (regexMatch "^[-._a-zA-Z0-9]+$" $key) }}
{{- fail (printf "theme file %q: a ConfigMap key takes only letters, digits, '-', '_' and '.'" .) }}
{{- end }}
{{- $key }}
{{- end }}
