# petasus-kaas-keycloak

The login service of a Petasus KaaS cluster's console: Keycloak, its PostgreSQL, a daily
`pg_dump`, the realm `petasus` and the identity provider Secret ks-apiserver reads.
petasus-resource-manager installs it as the release `keycloak` in `petasus-system` on new
clusters labelled `addons.petasus.io/keycloak: enabled`, after it has written the Secret
`keycloak-bootstrap`. `values.yaml` describes every value.

## What it makes

| Object | Name |
|---|---|
| Keycloak Deployment and Service (8080 http, 9000 management) | `keycloak` |
| PostgreSQL StatefulSet and Service (5432), claim `data-keycloak-postgres-0` | `keycloak-postgres` |
| Database credentials (kept when the release goes) | Secret `keycloak-postgres` |
| Client secrets of `ks-console` and `ks-apiserver-admin` (kept) | Secret `keycloak-clients` |
| ks-apiserver's identity provider configuration | Secret `identity-provider-keycloak` |
| Backup CronJob and volume (volume made by a hook, kept) | `keycloak-postgres-backup` |
| First import of the realm | ConfigMap `keycloak-realm-import` |
| Chart-managed realm settings, applied by the hook Job `keycloak-config` | ConfigMap `keycloak-realm-config` |
| Theme `petasus`, one per type under `files/themes/petasus/` | ConfigMaps `keycloak-theme-<type>` |
| Provider JARs from `files/providers/*.jar` | ConfigMap `keycloak-providers` |
| Who may reach Keycloak and PostgreSQL | NetworkPolicies `keycloak`, `keycloak-postgres` |

Keycloak serves under `<consoleURL>/auth`, which the console proxies to the Service. Its
issuer is `<consoleURL>/auth/realms/petasus`; inside the cluster it is reached at
`http://keycloak.petasus-system.svc:8080/auth`, and calls made there get in-cluster token,
JWKS and userinfo addresses back while tokens keep the public issuer.

The master realm's administrator (`master-username`, `master-password` of the bootstrap
Secret) is the emergency way into Keycloak itself. The console does not proxy the master
realm; reach it with a port-forward:

```sh
kubectl -n petasus-system port-forward svc/keycloak 8080:8080
# http://localhost:8080/auth/admin/master/console/
```

Keycloak makes that administrator at its first start only; changing the Secret later does
not change the password.

### Network

The NetworkPolicies (`networkPolicy.enabled`, on by default) let only the console,
ks-apiserver, ks-controller-manager (and keycloak-migrate run in it) and the realm
configuration job reach Keycloak's HTTP port, and only Keycloak and the backup and restore
pods reach PostgreSQL. Nothing reaches the management port 9000 but the kubelet's probes,
which come from the node. Browsers, kubectl's API server (KC-15) and applications with
clients of their own (KC-14) come through the console's address. A NodePort or another
direct way to Keycloak needs a peer in `networkPolicy.extraIngress` (e.g. an `ipBlock`);
the master realm is meant to be reached with the port-forward above, which no policy
stops. A network plugin that does not enforce NetworkPolicies ignores them.

## Who owns which realm setting

The realm is made in two steps, and the split decides what an upgrade does.

- **First install only** (`realm-import.json`, imported at Keycloak's first start, skipped
  once the realm exists). After that the settings belong to the cluster's administrators,
  who change them in the console's login settings or Keycloak's admin console, and no
  upgrade puts them back: the password policy, the SSO session times (`session`), brute
  force detection, the MFA policy (where the role `petasus-mfa-required` is mapped:
  nowhere, the group `/platform/admins`, or the composite `default-roles-petasus`),
  identity providers, users and group memberships. The realm user `admin` is made here too
  (below).
- **Every install, upgrade and rollback** (`realm-config.json`, applied by
  keycloak-config-cli in the hook Job `keycloak-config`, then `files/scripts/realm-finish.sh`):
  the clients `ks-console`, `ks-apiserver-admin` (its service account is the realm's
  `realm-admin`) and `kubectl` with their secrets, redirect URIs, back-channel logout
  address and mappers, and none of them, nor Keycloak's own clients, with the password
  grant (`admin-cli` is off); the default roles without account management, account
  linking and offline tokens; the realm's flows (below);
  the display name, SSL requirement, locales, themes, login options (no remember-me, login
  by e-mail, usernames not editable), the WebAuthn display names, events; the mail server
  from `smtp` with forgotten passwords and e-mail verification (on with it, off and no
  server without it; the console has no screen for it); the user
  profile (the username rule, `ks_username`); the role `petasus-mfa-required` itself; the
  groups `/platform`, `/platform/admins` (with `realm-management: realm-admin`),
  `/platform/regular` and `/workspaces`; the required actions the console starts (the
  WebAuthn ones only where browsers lack WebAuthn, below; linking an external account,
  `idp_link`, off); the post-login flow of identity providers that have none. Changing any
  of these in the admin console lasts until the next upgrade.

keycloak-config-cli never deletes clients, groups, sub-groups, flows or required actions,
deletes roles only when it made them and the chart no longer has them, changes no client
but the chart's three, and touches no group membership: the application clients and the
groups under `/workspaces` ks-controller-manager makes, the members of `/platform/admins`
and `/platform/regular`, and whatever the administrators add stay. The user profile is the
exception: the chart owns it whole, so an attribute must be declared in the chart
(`_realm.tpl`) to survive an upgrade.

### The realm user admin

On a new cluster the bootstrap Secret holds `admin-user-id` and `admin-password`: the realm
user `admin` gets that ID, that password as a temporary one (the first login asks for a new
one), the group `/platform/admins` and `ks_username=admin`, and no e-mail address (the
customer sets theirs in the console), and the identity provider Secret carries
`bootstrapAdmin`, which links KubeSphere's `admin` to it. A cluster that
existed before and is migrated has neither key: the realm has no `admin`, the Secret no
`bootstrapAdmin`, and the local `admin` stays the customer's emergency account.

### Login flow and MFA

Every way into the realm asks for the same second factor:

- `petasus-browser`, the browser flow: the SSO cookie, an identity provider named by
  `kc_idp_hint`, then the username and password form and the second factor.
- `petasus-post-broker`, the post-login flow of identity providers: a login through an
  identity provider (Entra ID, Google, Okta, SAML) is finished by the broker and never
  reaches the browser flow's second factor; LDAP users sign in through the browser flow. Every upgrade gives each identity provider
  without a post-login flow this one. **An identity provider added in the admin console
  needs it set by hand until then**: Identity providers, the provider, Advanced settings,
  Post login flow `petasus-post-broker`.
- `petasus-reset-credentials`, "forgot password" (with a mail server): the e-mailed link,
  then the second factor the user has, then the new password. Keycloak's own flow would
  instead make the user set up a new OTP, so the mailbox alone would get past the second
  factor.
- `petasus-direct-grant`, the password grant: refused. No client of the realm takes a
  password directly (KC-12).

The second factor in each:

- a user who has OTP or a security key is asked for it ("try another way" between them);
- a user who has neither and holds `petasus-mfa-required` must set up OTP before the login
  ends; a security key or passkey can be added later from the console;
- a passkey sign-in is asked for nothing more.

Users see their e-mail address but cannot change it on any page of the login service; the
console's user management does (D32). The account console and its API, and the linking of
external accounts to one's own, are closed: the default roles hold neither, and `idp_link`
is off.

WebAuthn (security keys, passkeys) needs an https console addressed by a DNS name:
browsers refuse it on http and on an IP address (`https://<IP>:<port>`, a console without a
published domain). Without it, the security key step, the WebAuthn required actions and
passkey sign-in are disabled on every upgrade, `loginService.webauthn` is false, and users
have OTP only; the realm's SSL requirement is `none` on http only. With it, the two WebAuthn
required actions (security key, passkey) belong to the administrators, whose login settings
turn the methods on and off: the first install enables them, an upgrade that gives the
console WebAuthn (http or an IP address to a DNS name) enables them once, and other
upgrades leave them as they are.

A console that loses WebAuthn (https back to http, or to an IP address) also loses the
security keys as a second factor: a user whose only second factor is a security key then
signs in with the password alone, or, holding `petasus-mfa-required`, is made to set up OTP.
Nothing tells them or the administrators; tell the users with security keys to set up OTP
before such a change.

## Backups

The CronJob `keycloak-postgres-backup` runs `pg_dump --format=custom` at `backup.schedule`
into the volume `keycloak-postgres-backup` and keeps the newest `backup.keep` dumps (1 or
more), named `keycloak-<UTC time>.dump`. Each run first removes all but the newest
`backup.keep - 1`, so a full volume frees itself, and fails, saying so in its log, when the
volume has less room left than the database takes: watch for failed Jobs of the CronJob, and
enlarge the claim (or lower `backup.keep`) when it happens. A dump is read back with
`pg_restore --list` before it gets its name, so every `keycloak-*.dump` is complete. Take
one now:

```sh
kubectl -n petasus-system create job --from=cronjob/keycloak-postgres-backup keycloak-backup-manual
kubectl -n petasus-system logs -f job/keycloak-backup-manual
```

The volume is made by the install (or the upgrade that turns backups on) as a Helm hook,
not as a resource of the release: on a class that binds a volume to its first consumer it
stays Pending until the first backup, which `helm --wait` would otherwise wait for forever.
Helm never deletes it, so it outlives upgrades and the release, and a later install uses it
again; `backup.size` and `backup.storageClass` count only when it is made.

The volume is the cluster's own: it protects against a broken database or a realm deleted
by mistake, not against losing the cluster. Copy dumps elsewhere for that (`kubectl cp`
from the restore pod below).

## Restoring the database

Restoring puts back the realm as it was at the dump: users, groups, credentials (and MFA
registrations), sessions and settings made after it are lost. Users created in the
console since then still have a KubeSphere User but no Keycloak user; create them again.
Keycloak migrates an older database at start, never a newer one: restore with the same or
a newer Keycloak than the one that wrote the dump. If the database is lost, ks-controller-manager
disables every KubeSphere user linked to Keycloak except the emergency `admin` (they come
back once the backup is restored): restore from the backup first, before anything else.

1. Stop Keycloak and the backups, so nothing writes while the database is replaced:

   ```sh
   kubectl -n petasus-system scale deployment keycloak --replicas=0
   kubectl -n petasus-system patch cronjob keycloak-postgres-backup -p '{"spec":{"suspend":true}}'
   ```

2. Start a pod with the backup volume and the database credentials (the image is the
   chart's `postgres.image`):

   ```sh
   IMAGE=$(kubectl -n petasus-system get statefulset keycloak-postgres -o jsonpath='{.spec.template.spec.containers[0].image}')
   kubectl apply -f - <<EOF
   apiVersion: v1
   kind: Pod
   metadata:
     name: keycloak-restore
     namespace: petasus-system
     # The NetworkPolicy keycloak-postgres lets this pod in.
     labels: {app.kubernetes.io/name: keycloak-restore, app.kubernetes.io/instance: keycloak}
   spec:
     restartPolicy: Never
     securityContext:
       runAsNonRoot: true
       runAsUser: 70
       runAsGroup: 70
       fsGroup: 70
       seccompProfile: {type: RuntimeDefault}
     containers:
     - name: restore
       image: $IMAGE
       command: [sleep, infinity]
       env:
       - {name: PGHOST, value: keycloak-postgres}
       - name: PGUSER
         valueFrom: {secretKeyRef: {name: keycloak-postgres, key: username}}
       - name: PGPASSWORD
         valueFrom: {secretKeyRef: {name: keycloak-postgres, key: password}}
       securityContext:
         allowPrivilegeEscalation: false
         capabilities: {drop: [ALL]}
       volumeMounts:
       - {name: backup, mountPath: /backup}
     volumes:
     - name: backup
       persistentVolumeClaim: {claimName: keycloak-postgres-backup}
   EOF
   kubectl -n petasus-system wait --for=condition=Ready pod/keycloak-restore
   kubectl -n petasus-system exec keycloak-restore -- ls -l /backup
   ```

3. Restore the dump you choose into a new database, check it, and only then swap it in,
   in one transaction; the database it replaces is kept as `keycloak_before_<time>`:

   ```sh
   kubectl -n petasus-system exec keycloak-restore -- \
     env DUMP=/backup/keycloak-20261119T033000Z.dump sh -ec '
       psql --dbname=keycloak --command="select 1" > /dev/null
       pg_restore --list "$DUMP" > /dev/null
       dropdb --if-exists keycloak_restore
       createdb keycloak_restore
       pg_restore --exit-on-error --single-transaction --dbname=keycloak_restore "$DUMP"
       psql --dbname=keycloak_restore --tuples-only --no-align \
         --command="select name from realm order by name" | tee /dev/stderr | grep -qx petasus
       old=keycloak_before_$(date -u +%Y%m%d%H%M%S)_$$
       psql --dbname=postgres --single-transaction -v ON_ERROR_STOP=1 \
         --command="ALTER DATABASE keycloak RENAME TO $old" \
         --command="ALTER DATABASE keycloak_restore RENAME TO keycloak"
       echo "restored; the database it replaced is $old"'
   ```

   It lists the realms of the restored dump (`master` and `petasus`). Nothing is dropped but
   the scratch `keycloak_restore`, and the swap happens whole or not at all, so the step can
   be run again after any failure. The first line stops when there is no database
   `keycloak` at all: then rename the newest `keycloak_before_<time>` back to `keycloak`
   first. Never start Keycloak on an empty `keycloak` database: it would make a new realm
   from the first-install import, with none of the users.

4. Remove the pod and start Keycloak and the backups again (the replicas are the release's
   `replicas`, 1 by default):

   ```sh
   kubectl -n petasus-system delete pod keycloak-restore
   kubectl -n petasus-system scale deployment keycloak --replicas=1
   kubectl -n petasus-system rollout status deployment keycloak
   kubectl -n petasus-system patch cronjob keycloak-postgres-backup -p '{"spec":{"suspend":false}}'
   ```

5. When the console's logins work again, drop the replaced databases:

   ```sh
   kubectl -n petasus-system exec keycloak-postgres-0 -- sh -c '
     export PGUSER="$POSTGRES_USER"
     for db in $(psql --dbname=postgres --tuples-only --no-align \
         --command="select datname from pg_database where datname like '"'"'keycloak_before_%'"'"'"); do
       echo "dropping $db"; dropdb "$db"
     done'
   ```

The chart-managed settings come back as they were at the dump; the next upgrade of the
release applies the current ones. The client secrets in the dump match `keycloak-clients`
unless that Secret was made again since; an upgrade puts the Secret's values back into the
realm.

## Upgrading Keycloak

Raise `image.tag` (and `configCli.image.tag` when keycloak-config-cli has a build for it)
and upgrade the release; Keycloak migrates the database at start. Take a dump first. The
Deployment stops every Keycloak pod before the new one starts (Recreate): two versions
never share the database. New logins pause for about a minute; signed-in users carry on. Check
on a test cluster, for each new version: the realm's supported locale codes (26.8 matches
`ui_locales` by language and country, hence `zh-CN` and `zh-TW`), the theme's templates
(they follow Keycloak's), the required actions list in `_realm.tpl`, and that the flow and
AIA still behave as above.

## Upgrading PostgreSQL

A new patch release of the same major version (`18-alpine` again, rebuilt) needs nothing
but the upgrade. A new major version does not read the old one's data: its data directory
is `/var/lib/postgresql/<major>/docker`, and the image refuses to start (it does not create
an empty database) while another major version's data is there. Move the data with a dump:
take a backup, stop Keycloak (`--replicas=0`), upgrade the release with the new
`postgres.image.tag`, and while PostgreSQL refuses to start, move the old directory away
(`kubectl exec` is not possible then; use a pod that mounts `data-keycloak-postgres-0`),
let the new PostgreSQL create its database, and restore the dump as above.
