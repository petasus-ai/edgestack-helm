# Moving an existing KaaS cluster to the login service (KC-11)

This runbook moves the local users of a KaaS cluster that runs without Keycloak to the cluster's
Keycloak, without a password reset. New clusters do not need it: they start with Keycloak.

## What the migration does

`keycloak-migrate` (`cmd/keycloak-migrate` in this repository) does the following for each local
KubeSphere user:

- It creates a Keycloak user in the realm `petasus` with the same name and email (marked as
  verified) and the attribute `ks_username`. The Keycloak user's id is the User's UID.
- The password stays the same: the Keycloak credential is the User's bcrypt hash, and the
  password hash provider `bcrypt` checks it (`files/providers/petasus-bcrypt.jar`, which the chart
  mounts into `/opt/keycloak/providers`). The user does not reset anything.
- It links the User to the Keycloak user with the labels `iam.kubesphere.io/identify-provider:
  keycloak` and `iam.kubesphere.io/origin-uid: <Keycloak user id>`, and removes the User's local
  password in the same change. On a Keycloak cluster only `admin` keeps a local password (KC-12).
- Platform roles become group membership (D28):
  - A user with the global role `platform-admin` becomes a member of exactly `/platform/admins`.
    A user with `platform-regular` becomes a member of exactly `/platform/regular`. The groups
    come from `groupMapping.platform` of the identity provider Secret.
  - The console's binding of that role (`<user>-platform-admin`) is replaced by the group's
    binding. That is the binding the group sync makes at sign-in: `<user>-platform-admin-group`,
    labelled `iam.kubesphere.io/managed-by: keycloak`.
  - From then on the role follows the group: the rights, the login service's administration and
    its MFA policy for administrators. Taking a user out of `/platform/admins` takes
    platform-admin away at their next sign-in or refresh.
  - The tool creates the group's binding before it deletes the console's, so the user never
    lacks the role.
  - All other bindings stay as they are: other global roles (`users-manager`,
    `workspaces-manager`), workspace roles and project roles.
- A disabled User becomes a disabled Keycloak user. A User that has never set its own password
  (annotation `iam.kubesphere.io/uninitialized`) must set one at its first sign-in.
- It writes the removed hashes and the replaced bindings to the Secret
  `petasus-system/keycloak-migration-backup`, for `keycloak-migrate rollback`.

The migration leaves these users alone:

- `admin`. On a cluster that existed before Keycloak, the realm has no `admin` user and nothing
  links the two. `keycloak-bootstrap` holds only the credentials of the master realm. The local
  `admin` keeps the customer's password and is the emergency account. Its link,
  `/login?route=localuser`, appears only on the "login service is getting ready" page (KC-12,
  D23).
- Users linked to another identity provider.
- Users without a local password.

The tool **refuses** a user, and changes nothing for it, in these cases:

- Keycloak already has a user of that name that the tool did not create. It never links by name
  (KC-8).
- Another User or Keycloak user has the same email.
- The name breaks the console's rule.
- The password is not a bcrypt hash yet, or its bcrypt cost is outside 4 to 14. The provider
  refuses costs above 14, so that one planted hash cannot keep Keycloak busy. Give such a user a
  new password first; the console hashes at cost 10.
- A GlobalRoleBinding gives the user's platform role to other subjects too. Give each its own
  binding first.

Among users that are linked already, it also refuses these:

- One other than `admin` that still has a local password. That password would sign in at
  `/login?route=localuser` without the login service's MFA.
- One the tool migrated that still has a console binding of a platform role while it is in none
  of the role's groups. Someone took the user out of the group, but the binding still gives the
  role. Add the user to the group, or delete the binding.

Running the tool again is safe. It skips what is done and continues where an earlier run
stopped. It relinks a Keycloak user that a rollback kept, and that user then follows the User as
it is now: it becomes a member of exactly the platform groups of the User's current roles, and
its enabled state follows the User's.

How Keycloak treats the hashes (Keycloak 26.8.2, see [Observed behaviour](#observed-behaviour-keycloak-2682)):
at a user's first successful sign-in, Keycloak re-hashes the password with the realm's algorithm
(argon2). The bcrypt hash of a user who never signs in stays, so the provider stays installed.

## Before you start

- The cluster's KubeSphere release must be one that ships the Keycloak support. Its
  ks-controller-manager image carries the tool at `/usr/local/bin/keycloak-migrate`. You run it
  in that pod, with that pod's service account and the in-cluster Keycloak address, so it needs
  no download and no network path from your machine.
- You need the hub's kubeconfig and the workload cluster's kubeconfig. Below, `kubectl` on the
  hub is marked "hub". Everything else runs against the workload cluster.
- Plan a short maintenance window. Between step 3 and step 4 nobody but `admin` can sign in:
  the local passwords are gone, and the login service is not switched on yet. Sessions that are
  already open keep working.

## Steps

1. **Install Keycloak switched off.** On the hub, label the Cluster for Keycloak (KC-1):

   ```bash
   # hub
   kubectl -n <cluster namespace> label cluster <cluster> addons.petasus.io/keycloak=enabled
   ```

   For a cluster that was created before Keycloak, RM installs the release with
   `identityProvider.disabled: true` for as long as the Cluster lacks the annotation
   `addons.petasus.io/keycloak-migrated: "true"`. ks-apiserver then ignores the identity
   provider, and sign-in works as before. Wait until RM marks the Cluster
   `addons.petasus.io/keycloak-ready: "true"`, then check the workload cluster:

   ```bash
   kubectl -n petasus-system get pods
   kubectl -n petasus-system get secret identity-provider-keycloak \
     -o jsonpath='{.data.configuration\.yaml}' | base64 -d | grep '^disabled:'
   ```

   The second command must print `disabled: true`.

2. **Dry run.** Nothing changes:

   ```bash
   kubectl -n petasus-system exec deploy/ks-controller-manager -- keycloak-migrate --dry-run
   ```

   First the tool checks two things. Keycloak must have the `bcrypt` provider, and the admin
   client must be able to call the admin API (client scope `kc-admin-api`). Then it prints one
   line for each User and a summary, which includes how many users go into each group. The exit
   status is 1 while any user is `refused` or `failed`. Fix those and run the dry run again:

   | Detail | What to do |
   |---|---|
   | the email belongs to several Users | Give each User its own email. |
   | the Keycloak user ... already has the email | Find out whose address it is, then change one of the two. |
   | Keycloak already has a user with this name that was not created from this User | Someone created it in Keycloak. If it is not this person, rename or delete it in the Keycloak administration. Never link the two by hand. |
   | the password is not a bcrypt hash yet | ks-controller-manager has not hashed it yet. Wait, and run again. |
   | the name does not follow the console's rule for user names | Such a User cannot sign in to Keycloak. Make a new user for that person. |
   | the Keycloak group ... does not exist | The realm is not complete. Check the Keycloak release. |

   `--user alice,bob` limits a run to some users, and `-o json` prints the report as JSON.
   `keycloak-migrate --help` lists the other flags.

3. **Migrate.** Run the same command without `--dry-run` and keep the report:

   ```bash
   kubectl -n petasus-system exec deploy/ks-controller-manager -- keycloak-migrate
   ```

   Users who are refused keep their local login.

4. **Switch on.** On the hub, annotate the Cluster:

   ```bash
   # hub
   kubectl -n <cluster namespace> annotate cluster <cluster> addons.petasus.io/keycloak-migrated=true
   ```

   RM applies the release again with `identityProvider.disabled: false`. ks-apiserver reads the
   Secret again without a restart, and the console sends sign-ins to the login service.

## Verification

- The identity provider Secret prints `disabled: false` (the command in step 1).
- Every migrated User is linked, and only `admin` and the users the tool left alone keep a
  local password:

  ```bash
  kubectl get users -L iam.kubesphere.io/identify-provider
  kubectl get users -o go-template='{{range .items}}{{.metadata.name}} {{if .spec.password}}local password{{else}}-{{end}}{{"\n"}}{{end}}'
  ```

- The platform roles of migrated users come from the groups' bindings. Those bindings carry the
  label `iam.kubesphere.io/managed-by: keycloak`, and no console binding of a platform role is
  left for them:

  ```bash
  kubectl get globalrolebindings -L iam.kubesphere.io/managed-by
  ```

- `keycloak-migrate --dry-run` (as in step 2) reports `already linked` for every migrated user.
- A migrated user signs in at the console with their old password and sees the same workspaces
  and projects as before.
- A platform administrator reaches the login settings and the login service's administration.
- The emergency path `/login?route=localuser` takes `admin` with the customer's password.
- The Keycloak pod's log (login events, KC-18) has no `LOGIN_ERROR` with
  `error="invalid_user_credentials"` for migrated users who typed their old password.

## Rollback

Roll back only while the identity provider is off. That holds before step 4. After step 4,
remove the annotation on the hub first (`kubectl -n <cluster namespace> annotate cluster
<cluster> addons.petasus.io/keycloak-migrated-`), and wait until the Secret says
`disabled: true` again. The tool refuses a rollback while the identity provider is on, unless
you pass `--force`: a user unlinked then fails at the next sign-in through the login service.

Roll back **before** removing the Keycloak release. A rollback needs the identity provider
Secret only for `--delete-keycloak-users`, so it still gives the passwords back after the
release is gone. The Keycloak users, though, can then only be removed by hand. Then:

```bash
kubectl -n petasus-system exec deploy/ks-controller-manager -- keycloak-migrate rollback --dry-run
kubectl -n petasus-system exec deploy/ks-controller-manager -- keycloak-migrate rollback
```

The rollback acts on each user in the backup Secret:

- It creates the console's bindings of platform roles again, with their names, labels and
  annotations. Then it deletes the groups' bindings of the same roles.
- It removes the two labels and gives the User back the local password it had before the
  migration. A User that has a local password again by then keeps that newer password.
- The Keycloak users stay. Add `--delete-keycloak-users` to delete them too. Delete them when
  you want a later migration to start from the users' current local passwords: a later run
  links a kept Keycloak user only if the User's password hash has not changed.
- A user whose User was deleted, or deleted and made again, still has a Keycloak user. Once the
  login service is on, that Keycloak user could sign in and get a new User. Without
  `--delete-keycloak-users` such a user is `refused`. With it, the tool deletes the Keycloak
  user and drops the backup entry.
- The exit status is 1 while any user is `refused` or `failed`. Running the rollback again is
  safe.

Some things a rollback does not undo:

- A password a user changed in the login service after step 4 is lost. They sign in with their
  old password again.
- The platform roles go back to what they were before the migration, even if an administrator
  changed a user's groups in the meantime.
- Other bindings that the group sync made stay, such as the workspace roles of workspace
  groups. Find them with
  `kubectl get globalrolebindings,workspacerolebindings,clusterrolebindings,rolebindings -A -l iam.kubesphere.io/managed-by=keycloak`.
  Delete the ones the users should not keep.
- Users made in the console after step 4 have no local password. An administrator gives them
  one.

Once the migration is final, delete the backup Secret. Like the Users, it holds password hashes.

```bash
kubectl -n petasus-system delete secret keycloak-migration-backup
```

## Permissions

In the pod, the tool uses ks-controller-manager's service account. The KaaS chart binds that
account to `cluster-admin`. If that binding is ever narrowed, the tool needs these permissions:

- `get` on the Secret `identity-provider-keycloak`, and `get`, `create` and `update` on the
  Secret `keycloak-migration-backup`, both in `petasus-system`;
- `list`, `get` and `patch` on `users.iam.kubesphere.io`;
- `list`, `get`, `create` and `delete` on `globalrolebindings.iam.kubesphere.io`.

## When Keycloak is upgraded

The provider uses the internal SPI `password-hashing`, which Keycloak may change without
notice. Keycloak logs `KC-SERVICES0047` about it at startup. For every new Keycloak image of
the chart:

1. Set `keycloak.version` in `providers/bcrypt/pom.xml` to the image's version.
2. Run `providers/bcrypt/build.sh`. It needs JDK 21 and Maven. It runs the unit tests and
   writes `files/providers/petasus-bcrypt.jar`. The JAR is reproducible: the same source gives
   the same SHA-256.
3. Run `providers/bcrypt/verify.sh`. It needs docker. It starts the image with the JAR, imports
   a user with a KubeSphere hash the way the tool does, and signs in with the password. It also
   checks that a wrong password fails, that Keycloak re-hashed the password after the sign-in,
   and that a hash of cost 31 is refused at once.
4. Commit `pom.xml` and the JAR together.

Keep the provider while any password in the realm is still bcrypt. The admin API returns each
password's algorithm in the `credentialData` of `GET /admin/realms/petasus/users/{id}/credentials`.

## The provider

- Source: `providers/bcrypt` (Java 21, Maven), id `bcrypt`. It reads the whole hash from the
  credential's secret data `value`, and the cost from `hashIterations`.
- It verifies hashes the way KubeSphere's Go code does (`golang.org/x/crypto/bcrypt`):
  - The prefixes `$2a$`, `$2b$` and `$2y$` all work.
  - It reads only the first 72 bytes of a password.
- It refuses hashes of a cost above 14 without computing them, and logs
  `Refused the bcrypt password hash of credential <id>: its cost <n> is above 14`. The log line
  does not contain the hash.
- It only verifies. It never writes a hash:
  - Its order is 0, below argon2 (300) and pbkdf2-sha512 (200), so it is never Keycloak's
    default.
  - Do not set `hashAlgorithm(bcrypt)` in the realm's password policy. Setting a password then
    fails with an error that says so.
- It contains `at.favre.lib:bcrypt` 0.10.2 and `at.favre.lib:bytes` 1.5.0, both licensed under
  Apache-2.0, relocated under `io.petasus.keycloak.bcrypt.shaded`. One class of bcrypt comes
  from jBCrypt, under an ISC notice. The JAR carries `META-INF/LICENSE` and
  `META-INF/THIRD-PARTY-NOTICES`.
- The chart mounts `files/providers/*.jar` into `/opt/keycloak/providers`. `kc.sh start` without
  `--optimized` rebuilds Keycloak's server image at startup when the providers change.

## Observed behaviour (Keycloak 26.8.2)

Checked on 2026-11-19 with `quay.io/keycloak/keycloak:26.8.2` in docker (`start-dev`,
PostgreSQL 18), the JAR above, and users that `keycloak-migrate` imported from a kind cluster.
Hashes and salts are shown as `<redacted>`.

The credential right after the import is unchanged. The `credential` table holds the following:

```json
{"type": "password", "credential_data": {"algorithm": "bcrypt", "hashIterations": 10},
 "secret_data": {"value": "$2y$10$<redacted>"}}
```

After one successful sign-in through the browser flow (authorization code), the same credential
row holds this:

```json
{"type": "password",
 "credential_data": {"hashIterations": 5, "algorithm": "argon2",
   "additionalParameters": {"hashLength": ["32"], "memory": ["7168"], "type": ["id"], "version": ["1.3"], "parallelism": ["1"]}},
 "secret_data": {"value": "<redacted>", "salt": "<redacted>", "additionalParameters": {}}}
```

- The re-hash keeps the credential's id and creation date. Keycloak does it after the request
  that checked the password, and only if that request completes. A user who must set a new
  password (`UPDATE_PASSWORD`) is re-hashed when the password step passes, before the new
  password is set.
- A failed sign-in does not change the credential.
- With the direct grant, a sign-in that ends in an error after the password check rolls back,
  and the hash stays bcrypt. One example is "Account is not fully set up". The console uses the
  browser flow.
- Sign-ins with the re-hashed password work. Sign-ins with a wrong password fail.
- `$2a$` and `$2y$` hashes both signed in. A disabled user's sign-in fails with "Account
  disabled".
- Users can also sign in with their email.

Keycloak 26.8 also requires two things of the realm, and the chart provides them (contract §4):

- The admin client needs the client scope `kc-admin-api`. Without it the admin API answers 401,
  and the tool asks for that scope.
- The user profile must declare `ks_username`, and first and last names must be optional.
  Otherwise Keycloak drops the attribute, and a sign-in stops at "update your profile".
