# EdgeStack VM Images Installation Helm Chart

Renders CDI [DataVolume](https://github.com/kubevirt/containerized-data-importer/blob/main/doc/datavolumes.md) resources that import EdgeStack golden VM images (generic OS and Kubernetes pre-installed variants) from a container registry into cluster storage.

## Values

| Key | Default | Description |
|---|---|---|
| `image.registry` | `""` | Private registry prefix. When set, image URLs become `docker://<registry>/quay.io/edgestack/...`; when empty, images pull directly from `quay.io`. |
| `image.kubernetes.ubuntu` | `["1.36"]` | Kubernetes minor version of the Ubuntu kube images (single-entry list; resolved via `kubeVersions`). |
| `image.kubernetes.rocky` | `["1.36"]` | Kubernetes minor version of the Rocky kube images (single-entry list; resolved via `kubeVersions`). |
| `image.accelerator.nvidia.enable` | `true` | Render the NVIDIA/DOCA image variants (`templates/nvidia/`). |
| `image.accelerator.nvidia.version` | `595` | NVIDIA driver version embedded in the generic NVIDIA VM image name and tag (integer or digit string). |
| `kubeVersions` | `{"1.36": v1.36.2}` | Full Kubernetes version per supported minor; drives the `kubeVersion` annotation and image tags. Rendering fails if an `image.kubernetes` entry has no mapping here. |
| `namespace` | `imagevolume` | Namespace the DataVolumes are created in. |
| `storageClass` | `nfs-csi` | StorageClass for the image PVCs. |
| `volumeMode` | `Filesystem` | PVC volume mode. `Filesystem` avoids the non-root CDI importer failure on Block devices with default containerd settings; set `Block` only on clusters with [`device_ownership_from_security_context = true`](https://github.com/kubevirt/containerized-data-importer/blob/main/doc/block_cri_ownership_config.md). |
| `storageSize.vm` | `20Gi` | Requested size for generic VM images (qcow2 virtual size is 16GiB; headroom covers Filesystem-mode fs overhead). |
| `storageSize.nvidiaVm` | `40Gi` | Requested size for NVIDIA generic VM images. |
| `storageSize.kube` | `32Gi` | Requested size for Kubernetes pre-installed images. |
| `pullMethod` | `node` | CDI registry import method (`node` or `pod`). |
| `archType` | `amd64` | Which architecture variants to render: `amd64`, `arm64`, or `multiarch` (both). |

Values are validated by `values.schema.json` at install/lint time.

## Usage

```sh
helm install edgetron-images . -n imagevolume \
  --set archType=multiarch \
  --set storageClass=hpe-standard
```
