#!/usr/bin/env bash
# Writes files/fluentbit-crds.yaml.gz, the fluent-bit CRDs (fluentbit.fluent.io) of the
# fluent-operator chart vendored in charts/fluent-operator, which the chart's pre-upgrade
# job applies (templates/crds.yaml). Run it after moving that chart (see Chart.yaml). gzip,
# so that the CRDs fit in one ConfigMap; -n, so that the same CRDs give the same file.
set -euo pipefail

cd "$(dirname "$0")/.."
cat charts/fluent-operator/crds/fluentbit.fluent.io_*.yaml | gzip -9n > files/fluentbit-crds.yaml.gz
echo "files/fluentbit-crds.yaml.gz from charts/fluent-operator $(sed -n 's/^version: //p' charts/fluent-operator/Chart.yaml)"
