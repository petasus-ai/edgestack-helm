
### Added

- `excludePath` support for the Fluent Bit tail input ([#2074](https://github.com/fluent/fluent-operator/pull/2074))
- `autoExtractTimestamp` support for the Splunk Fluent Bit output ([#2063](https://github.com/fluent/fluent-operator/pull/2063))
- `workers` support for the HTTP Fluent Bit output ([#2076](https://github.com/fluent/fluent-operator/pull/2076))
- `timeStrict` support for Fluent Bit parsers ([#2081](https://github.com/fluent/fluent-operator/pull/2081))

### Changed

- Updated CRDs with the latest Kubernetes API schemas ([#2041](https://github.com/fluent/fluent-operator/pull/2041))
- Bumped default Fluent Bit image tag to `5.1.5` ([#2079](https://github.com/fluent/fluent-operator/pull/2079))
- Bumped fluent-operator to v3.11.0
