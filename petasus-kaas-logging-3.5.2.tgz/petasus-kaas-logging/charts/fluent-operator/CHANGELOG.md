# Fluent Operator Helm Chart Changelog

> [!NOTE]
> All notable changes to this project will be documented in this file; the format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

<!--
### Added - For new features.
### Changed - For changes in existing functionality.
### Deprecated - For soon-to-be removed features.
### Removed - For now removed features.
### Fixed - For any bug fixes.
### Security - In case of vulnerabilities.
-->

## [UNRELEASED]

## [v4.4.0] - 2026-10-28

### Added

- `excludePath` support for the Fluent Bit tail input ([#2074](https://github.com/fluent/fluent-operator/pull/2074))
- `autoExtractTimestamp` support for the Splunk Fluent Bit output ([#2063](https://github.com/fluent/fluent-operator/pull/2063))
- `workers` support for the HTTP Fluent Bit output ([#2076](https://github.com/fluent/fluent-operator/pull/2076))
- `timeStrict` support for Fluent Bit parsers ([#2081](https://github.com/fluent/fluent-operator/pull/2081))

### Changed

- Updated CRDs with the latest Kubernetes API schemas ([#2041](https://github.com/fluent/fluent-operator/pull/2041))
- Bumped default Fluent Bit image tag to `5.1.5` ([#2079](https://github.com/fluent/fluent-operator/pull/2079))
- Bumped fluent-operator to v3.11.0

## [v4.3.0] - 2026-08-17

### Added

- `batchSize` support for the OpenTelemetry Fluent Bit output ([#2015](https://github.com/fluent/fluent-operator/pull/2015))
- `rawLogKey` and raw format support for the Kafka Fluent Bit output ([#2000](https://github.com/fluent/fluent-operator/pull/2000))
- `totalLimitSize` (storage total limit) support for the Splunk Fluent Bit output ([#2009](https://github.com/fluent/fluent-operator/pull/2009))

### Changed

- `fluentbit.service` value now accepts any valid Fluent Bit `[service]` field, merged over the chart defaults ([#2010](https://github.com/fluent/fluent-operator/pull/2010))
- Bumped default Fluent Bit image tag to `5.1.0` ([#2027](https://github.com/fluent/fluent-operator/pull/2027))
- Bumped fluent-operator to v3.10.0

## [v4.2.0] - 2026-06-09

### Added

- `fluentd.forward.retainMetadataInForwardMode` value to configure metadata retention when forwarding in forward mode ([#1973](https://github.com/fluent/fluent-operator/pull/1973))
- `fluentbit.metadata.annotations` value to add custom annotations to the FluentBit resource ([#1986](https://github.com/fluent/fluent-operator/pull/1986))

### Changed

- Bumped default Fluent Bit image tag to `5.0.6` ([#1977](https://github.com/fluent/fluent-operator/pull/1977))
- Bumped fluent-operator to v3.9.0

## [v4.1.0] - 2026-05-21

### Added

- Operator deployment now includes configurable liveness and readiness probes (hitting `/healthz` and `/readyz`) ([#1956](https://github.com/fluent/fluent-operator/pull/1956))

### Changed

- Hardened default `podSecurityContext` and `securityContext` for the operator: `runAsNonRoot`, `runAsUser/Group 65532`, `readOnlyRootFilesystem`, drop `ALL` capabilities, `seccompProfile: RuntimeDefault` ([#1956](https://github.com/fluent/fluent-operator/pull/1956))
- Bumped default Fluent Bit image tag to `v5.0.5` ([#1968](https://github.com/fluent/fluent-operator/pull/1968))
- Bumped fluent-operator to v3.8.0

## [v4.0.0] - 2026-04-19

### Changed

- Initial release of v4 chart

<!--
RELEASE LINKS
-->
[UNRELEASED]: https://github.com/fluent/helm-charts/tree/main/charts/fluent-operator
[v4.4.0]: https://github.com/fluent/helm-charts/releases/tag/fluent-operator-4.4.0
[v4.3.0]: https://github.com/fluent/helm-charts/releases/tag/fluent-operator-4.3.0
[v4.2.0]: https://github.com/fluent/helm-charts/releases/tag/fluent-operator-4.2.0
[v4.1.0]: https://github.com/fluent/helm-charts/releases/tag/fluent-operator-4.1.0
[v4.0.0]: https://github.com/fluent/helm-charts/releases/tag/fluent-operator-4.0.0
