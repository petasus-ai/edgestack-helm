#!/bin/bash
# Brings the log store to the state the release asks for, after every install and upgrade
# (templates/setup.yaml): the hub's opensearch-setup.py (edgespray roles/petasus/files/
# logging), in bash and curl as the job's image has no python. Then hands KubeSphere's
# account to ks-apiserver.
#
# The admin certificate (plugins.security.authcz.admin_dn) authenticates every call.
# Environment: OPENSEARCH (the URL), KINDS (the kinds of record kept, space-separated),
# RETENTION_<KIND> (days), FLUENTBIT_PASSWORD, KUBESPHERE_PASSWORD, KS_NAMESPACE,
# KS_SECRET, KS_DEPLOYMENT.
set -euo pipefail

curl_os=(curl -sS --max-time 30 --cacert /admin/ca.crt --cert /admin/tls.crt --key /admin/tls.key
         -H 'Content-Type: application/json')

# call METHOD PATH [BODY]: the answer in RESP; succeeds on a 2xx answer.
call() {
  local out code args=(-X "$1" -w '\n%{http_code}' "$OPENSEARCH$2")
  [ $# -lt 3 ] || args+=(--data "$3")
  out=$("${curl_os[@]}" "${args[@]}") || {
    RESP="no answer"
    return 1
  }
  code=${out##*$'\n'}
  RESP=${out%$'\n'*}
  [ "$code" -ge 200 ] && [ "$code" -lt 300 ]
}

must() {
  call "$@" || { echo "$1 $2: $RESP" >&2; exit 1; }
}

# The node answers before its security index is set up.
ready=""
for _ in $(seq 1 120); do
  if call GET /_cluster/health && grep -q -E '"status":"(green|yellow)"' <<< "$RESP" &&
     call GET /_plugins/_security/health && grep -q '"status":"UP"' <<< "$RESP"; then
    ready=1
    break
  fi
  sleep 5
done
[ -n "$ready" ] || { echo "OpenSearch did not become ready: $RESP" >&2; exit 1; }

# fluent-bit's bulk requests, creating the day's index on its first record; KubeSphere's
# searches, scrolls and counts.
must PUT /_plugins/_security/api/roles/petasus_logging_writer '{
  "cluster_permissions": ["indices:data/write/bulk"],
  "index_permissions": [{"index_patterns": ["ks-petasus-*"], "allowed_actions": ["create_index", "index"]}]
}'
must PUT /_plugins/_security/api/roles/petasus_logging_reader '{
  "cluster_permissions": ["cluster_monitor", "cluster_composite_ops_ro", "indices:data/read/scroll*"],
  "index_permissions": [{"index_patterns": ["ks-petasus-*"], "allowed_actions": ["read"]}]
}'
must PUT /_plugins/_security/api/internalusers/fluentbit "{\"password\": \"$FLUENTBIT_PASSWORD\"}"
must PUT /_plugins/_security/api/internalusers/kubesphere "{\"password\": \"$KUBESPHERE_PASSWORD\"}"
must PUT /_plugins/_security/api/rolesmapping/petasus_logging_writer '{"users": ["fluentbit"]}'
must PUT /_plugins/_security/api/rolesmapping/petasus_logging_reader '{"users": ["kubesphere"]}'

# The fields KubeSphere sorts and ranges by, whatever the day's first record. No other field
# becomes a date: one that did would refuse every later record of the day with text in it.
must PUT /_index_template/ks-petasus '{
  "index_patterns": ["ks-petasus-*"],
  "priority": 100,
  "template": {
    "settings": {"index": {"number_of_shards": 1, "number_of_replicas": 0, "codec": "best_compression",
                           "refresh_interval": "30s", "mapping": {"total_fields": {"limit": 2000}}}},
    "mappings": {
      "date_detection": false,
      "properties": {
        "@timestamp": {"type": "date"}, "time": {"type": "date"}, "lastTimestamp": {"type": "date"},
        "firstTimestamp": {"type": "date"}, "eventTime": {"type": "date"},
        "RequestReceivedTimestamp": {"type": "date"}, "StageTimestamp": {"type": "date"}
      }
    }
  },
  "_meta": {"managed_by": "petasus-kaas-logging"}
}'

# One retention policy per kind of record, by the age of the index (the day it was made).
for kind in $KINDS; do
  var=RETENTION_${kind^^}
  age="${!var}d"
  id=ks-petasus-$kind
  pattern="ks-petasus-$kind-*"
  policy="{\"policy\": {
    \"description\": \"Delete $pattern indices $age after they are created.\",
    \"default_state\": \"open\",
    \"states\": [
      {\"name\": \"open\", \"actions\": [], \"transitions\": [{\"state_name\": \"delete\", \"conditions\": {\"min_index_age\": \"$age\"}}]},
      {\"name\": \"delete\", \"actions\": [{\"delete\": {}}], \"transitions\": []}
    ],
    \"ism_template\": [{\"index_patterns\": [\"$pattern\"], \"priority\": 100}]
  }}"
  if call GET "/_plugins/_ism/policies/$id"; then
    current=$(grep -o '"min_index_age":"[^"]*"' <<< "$RESP" | head -1 | cut -d'"' -f4)
    if [ "$current" != "$age" ]; then
      seq_no=$(grep -o '"_seq_no":[0-9]*' <<< "$RESP" | head -1 | cut -d: -f2)
      term=$(grep -o '"_primary_term":[0-9]*' <<< "$RESP" | head -1 | cut -d: -f2)
      must PUT "/_plugins/_ism/policies/$id?if_seq_no=$seq_no&if_primary_term=$term" "$policy"
      # Indices keep the policy version they started with until told otherwise.
      must POST "/_plugins/_ism/change_policy/$pattern" "{\"policy_id\": \"$id\"}"
    fi
  else
    must PUT "/_plugins/_ism/policies/$id" "$policy"
  fi
  # The template only reaches indices made after it; give the policy to any older one.
  must POST "/_plugins/_ism/add/$pattern" "{\"policy_id\": \"$id\"}"
done
echo "OpenSearch set up for: $KINDS"

# KubeSphere's account, in the Secret ks-apiserver reads its password from as it starts
# (petasus-kaas-kubesphere). KubeSphere's core comes with its own release, which may not be
# there yet.
for _ in $(seq 1 60); do
  kubectl get namespace "$KS_NAMESPACE" >/dev/null 2>&1 && break
  sleep 10
done
if ! kubectl get namespace "$KS_NAMESPACE" >/dev/null 2>&1; then
  echo "No namespace $KS_NAMESPACE: KubeSphere's account is handed over at the next upgrade" >&2
  exit 0
fi
stored=$(kubectl -n "$KS_NAMESPACE" get secret "$KS_SECRET" -o jsonpath='{.data.password}' 2>/dev/null | base64 -d 2>/dev/null || true)
if [ "$stored" != "$KUBESPHERE_PASSWORD" ]; then
  kubectl -n "$KS_NAMESPACE" create secret generic "$KS_SECRET" --type=kubernetes.io/basic-auth \
    --from-literal=username=kubesphere --from-literal=password="$KUBESPHERE_PASSWORD" \
    --dry-run=client -o yaml |
    kubectl annotate --local -f - -o yaml logging.petasus.io/updated="$(date -u +%Y-%m-%dT%H:%M:%SZ)" |
    kubectl apply -f -
fi

# A ks-apiserver that started before the password was there runs without it: start it again.
updated=$(kubectl -n "$KS_NAMESPACE" get secret "$KS_SECRET" -o jsonpath='{.metadata.annotations.logging\.petasus\.io/updated}')
if [ -n "$updated" ] && kubectl -n "$KS_NAMESPACE" get deployment "$KS_DEPLOYMENT" >/dev/null 2>&1; then
  started=$(kubectl -n "$KS_NAMESPACE" get pods -l app="$KS_DEPLOYMENT" \
              -o jsonpath='{range .items[*]}{.status.startTime}{"\n"}{end}')
  if awk -v t="$updated" 'NF && $1 < t { found = 1 } END { exit !found }' <<< "$started"; then
    kubectl -n "$KS_NAMESPACE" rollout restart deployment "$KS_DEPLOYMENT"
  fi
fi
