-- Record shaping for the KaaS cluster's fluent-bit (templates/pipeline.yaml), so that the
-- records have the fields KubeSphere searches and sorts by. Called with the record time as a
-- table (time_as_table). The hub's, edgespray roles/petasus/files/logging/petasus-logging.lua,
-- as it is: change both together.

-- "2026-10-21T08:26:36.254Z" with nanoseconds, in UTC.
local function rfc3339(timestamp)
  return os.date("!%Y-%m-%dT%H:%M:%S", timestamp["sec"]) .. string.format(".%09dZ", timestamp["nsec"])
end

-- Seconds since the epoch of a Kubernetes time ("2026-10-21T08:26:36Z", with or without a
-- fraction; always UTC). Not os.time, which takes its argument as local time.
local function epoch(value)
  local y, mo, d, h, mi, s = string.match(value, "^(%d+)-(%d+)-(%d+)T(%d+):(%d+):(%d+)")
  if y == nil then
    return nil
  end
  y, mo, d = tonumber(y), tonumber(mo), tonumber(d)
  if mo <= 2 then
    y = y - 1
  end
  local era = math.floor(y / 400)
  local yoe = y - era * 400
  local doy = math.floor((153 * ((mo + 9) % 12) + 2) / 5) + d - 1
  local doe = yoe * 365 + math.floor(yoe / 4) - math.floor(yoe / 100) + doy
  local days = era * 146097 + doe - 719468
  return days * 86400 + tonumber(h) * 3600 + tonumber(mi) * 60 + tonumber(s)
end

-- Container logs: KubeSphere sorts and ranges them by time. _p is the runtime's
-- partial-line flag, which the cri parser has already acted on.
function container_log(tag, timestamp, record)
  record["time"] = rfc3339(timestamp)
  record["_p"] = nil
  return 2, timestamp, record
end

-- kubelet and containerd journals, shown as kube-system logs of a pod named after the node.
function journal_log(tag, timestamp, record)
  local kubernetes = {}
  kubernetes["namespace_name"] = "kube-system"
  kubernetes["pod_name"] = record["_HOSTNAME"]
  kubernetes["container_name"] = record["SYSLOG_IDENTIFIER"]
  local out = {}
  out["time"] = rfc3339(timestamp)
  out["log"] = record["MESSAGE"]
  out["kubernetes"] = kubernetes
  return 2, timestamp, out
end

-- Events: the core/v1 Event as the API serves it. KubeSphere sorts and ranges them by
-- lastTimestamp, which events written through events.k8s.io leave empty; it becomes the
-- time the event was last seen, and so does the record time, which picks the day's index.
function kube_event(tag, timestamp, record)
  local metadata = record["metadata"]
  local series = record["series"]
  record["kind"] = nil
  record["apiVersion"] = nil
  if metadata ~= nil then
    metadata["managedFields"] = nil
  end
  local last = record["lastTimestamp"]
  if last == nil then
    if series ~= nil then
      last = series["lastObservedTime"]
    end
    last = last or record["eventTime"] or record["firstTimestamp"]
    if last == nil and metadata ~= nil then
      last = metadata["creationTimestamp"]
    end
    record["lastTimestamp"] = last
  end
  local sec = nil
  if last ~= nil then
    sec = epoch(last)
  end
  if sec == nil then
    return 2, timestamp, record
  end
  return 1, { sec = sec, nsec = 0 }, record
end
