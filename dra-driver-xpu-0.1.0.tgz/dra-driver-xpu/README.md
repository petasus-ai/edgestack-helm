# dra-driver-xpu

Vendor-neutral DRA driver that advertises a node's VFIO passthrough devices and
mediated devices, and hands them to KubeVirt VMs.

One release covers every vendor on the cluster. There is no per-vendor
installation and, in the common case, nothing to configure.

## Install

```bash
helm install dra-driver-xpu deployments/helm/dra-driver-xpu \
  --namespace dra-system --create-namespace
```

No values are required. The defaults publish:

| | |
|---|---|
| Passthrough-ready | bound to `vfio-pci` **or** carrying mediated devices |
| PCI class | `0300` (VGA), `0302` (3D controller), `0380` (display other), `1200` (processing accelerator) |
| Vendor | **any** |

## Requirements

| | |
|---|---|
| Kubernetes | v1.35 or newer (`resource.k8s.io/v1`); enforced by `kubeVersion` |
| KubeVirt | v1.9.0 or newer, with the `GPUsWithDRA` and `HostDevicesWithDRA` feature gates |
| containerd | v2.2.3 or newer |

DRA-backed GPUs and host devices bypass the KubeVirt CR's
`permittedHostDevices` allowlist entirely, so nothing has to be registered
there.

## What it installs

| Kind | Created when |
|---|---|
| `DaemonSet` | always |
| `ServiceAccount` | `serviceAccount.create` |
| `ClusterRole`, `ClusterRoleBinding` | always |
| `DeviceClass` | `deviceClass.create` |
| `ConfigMap` | `config.vendors` is non-empty and `config.existingConfigMap` is unset |

The DaemonSet is privileged and mounts `/sys`, `/dev`, the kubelet plugin
directories and the CDI directory: it opens VFIO character devices and writes
the CDI specs the container runtime reads.

---

# Configuration

## Why there is no device ID or PCI address list

**The `vfio-pci` binding already is the allowlist.** Which devices go to VMs is
decided when the node is provisioned — by `sriov-daemon`, `vfio-manager` or
whatever else binds them — and that decision is expressed as the binding.
Restating it here as a list of device IDs would put the same decision in two
places, and the day they disagree a device silently stops being offered.

A device the host is still using is never bound to `vfio-pci`, so this one rule
carries the safety property without anything to opt out of.

Network classes (`0200`) are deliberately absent from the defaults. SR-IOV VFs
belong to `dra-driver-sriov`, and publishing them from both drivers would let
the scheduler hand the same VF to two workloads.

To select a *particular* device, use the claim's CEL selector rather than the
driver's configuration — what the node has and what a workload wants are
different questions. See [Published attributes](#published-attributes).

## Mediated device parents are not on vfio-pci

A vGPU parent GPU stays bound to the vendor's own driver:

| Technology | Parent GPU's driver |
|---|---|
| NVIDIA vGPU | `nvidia` (vGPU Manager) |
| Intel GVT-g | `i915` |
| AMD MxGPU | `gim` |

vfio only enters the picture for the mdev instances. Requiring `vfio-pci` of
every device would therefore make mediated device support dead code, so the
rule is:

```
bound to vfio-pci   OR   carrying mdev instances
```

A GPU on its vendor driver with no mdevs is in use by the host and is not
published.

## Narrowing what is published

One `vendors` list is the whole schema. Each entry is a vendor: **who it is**
(name, domain) and **what of it to publish** (classes).

The configuration file accepts **YAML or JSON** — JSON is valid YAML. A
ConfigMap is written in YAML and is often applied directly, so YAML with
comments is the better form. The key is **`config.yaml`**.

Through the chart:

```yaml
config:
  vendors:
    # 10de and 1002 are in the built-in table, so the ID is enough.
    - vendor_id: "0x10de"
      device_classes: ["0x030200", "0x030000"]
    - vendor_id: "0x1002"
      device_classes: ["0x120000"]
    # Not in the table, so name it here.
    - vendor_id: "0x1f56"
      vendor_name: sapeon
      vendor_domain: sapeon.com
```

Or as a ConfigMap applied on its own — see
[`deployments/examples`](../../examples), which are ready to apply as they are:

```bash
# The examples use namespace: dra-system; it has to match the install namespace.
kubectl apply -f deployments/examples/configmap-restrict-to-gpu-vendors.yaml
helm upgrade dra-driver-xpu deployments/helm/dra-driver-xpu \
  --namespace dra-system \
  --set config.existingConfigMap=dra-driver-xpu-config
```

| Field | When omitted | Meaning |
|---|---|---|
| `vendor_id` | **any vendor** | PCI vendor ID. A `0x` prefix is accepted; normalised to 4 lower-case hex digits. |
| `vendor_name` | built-in table, then `pci.ids` | The `vendorName` attribute. |
| `vendor_domain` | built-in table, then `xpu.petasus.io` | Prefixes the `resourceName` attribute. |
| `device_classes` | `0300` `0302` `0380` `1200` | 4-digit and 6-digit forms both accepted; the programming interface is ignored. |
| `device_class` | — | Singular form kept for backward compatibility; folded into `device_classes`. |

### Listing vendors restricts publishing to them

**A `vendors` list replaces the defaults rather than adding to them.** Read it
as a declaration of the fleet.

So naming SAPEON alone, just to get its domain right, stops NVIDIA and AMD from
being published. Every vendor in the fleet has to appear — see
[`configmap-full-fleet.yaml`](../../examples/configmap-full-fleet.yaml).

If that is a burden, the right answer is to have no ConfigMap at all: an
unlisted vendor is still published, as `xpu.petasus.io/<PRODUCT>`, so the only
thing lost is the domain label.

- The same `vendor_id` twice is a parse error — the second entry would be dead.
  Collect a vendor's classes into one entry's `device_classes`.
- Omitting `vendor_id` matches any vendor; use it to narrow classes only.
- `vendors: []` (an explicit empty list) publishes **nothing** — a kill switch
  for a node, without deleting the DaemonSet.
- An **empty document** is a parse error, and deliberately not the same as
  `vendors: []`. Read literally it says nothing about vendors, which would mean
  the built-in rule: publish every device on the node. That is the widest
  possible allowlist to arrive at by accident, so it is refused. Delete the
  ConfigMap for the defaults, or write `vendors: []` to publish nothing.
- Unknown fields are a parse error. A ConfigMap typo failing at start-up beats
  it silently changing the allowlist.
- Deleting the ConfigMap reverts to the defaults, without a restart.

### Six-digit class codes

The existing device-plugin values use the 6-digit form (`0x030200`,
`0x030000`, `0x120000`), so they can be pasted in unchanged. A value that is
neither 4 nor 6 digits, such as `03020`, is rejected: padding it would turn a
typo into a silently different class.

A `values.schema.json` rejects unquoted IDs and unknown fields while
rendering, rather than leaving the driver to fail at start-up with the
ConfigMap already applied. Quote these values — an unquoted `1002` is a number
to YAML, and an unquoted `0300` is octal 192.

## Where the vendor name and domain come from

Each step is a fallback for what the previous one does not know, not a
competing source for the same fact.

| Attribute | 1st | 2nd | 3rd |
|---|---|---|---|
| `vendorName` | the entry's `vendor_name` | built-in vendor table | the `pci.ids` vendor string |
| `resourceName` domain | the entry's `vendor_domain` | built-in vendor table | `xpu.petasus.io` |

Parsed from `configmap-full-fleet.yaml` for real:

| Configuration | Published `vendorName` | Published `resourceName` | Source |
|---|---|---|---|
| `vendor_id: 0x10de` only | `nvidia` | `nvidia.com/GH100_H100_SXM5_80GB` | **built-in table** |
| `vendor_id: 0x1002` only | `amd` | `amd.com/AQUA_VANJARAM_INSTINCT_MI300X_VF` | **built-in table** |
| `0x1f56` with name and domain | `sapeon` | `sapeon.com/0001` | **the entry** |
| no configuration, `cabc` (Cambricon) | `Cambricon Technologies Corporation Limited` | `xpu.petasus.io/0100` | pci.ids / driver domain |

So a vendor the built-in table knows needs only its ID. A vendor it does not
know still gets a name from `pci.ids` — just a verbose one, under the driver's
own domain.

### Built-in vendor table

| Vendor ID | Vendor | Domain | Why |
|---|---|---|---|
| `10de` | NVIDIA | `nvidia.com` | **in use by the existing deployment** (edgespray `nvidia-xpu-device-plugin-values.yaml`) |
| `1002` | AMD/ATI | `amd.com` | **in use by the existing deployment** (edgespray `amd-xpu-device-plugin-values.yaml`) |
| `1022` | AMD (non-graphics) | `amd.com` | the vendor's own device plugin |
| `8086` | Intel | `intel.com` | ″ |
| `1da3` | Habana Labs | `habana.ai` | ″ |
| `1d95` | Graphcore | `graphcore.ai` | ″ |
| `1ed2` | FuriosaAI | `furiosa.ai` | ″ |
| `1eff` | Rebellions | `rebellions.ai` | ″ |

**A vendor missing from the table is not an error** — it is published under
`xpu.petasus.io/<PRODUCT>`. The table is a label lookup, never a filter.

> Vendors whose domain could not be established are deliberately absent: a
> guessed domain silently mislabels devices. Accelerator vendors present in
> `pci.ids` but not in the table: SAPEON (`1f56`), Tenstorrent (`1e52`), Hailo
> (`1e60`), Cambricon (`cabc`), Groq (`1de0`), SambaNova (`1e0d`), Moore
> Threads (`1ed5`), Enflame (`1e36`), Kalray (`1d26`), Blaize (`1e38`),
> Untether AI (`1e67`), Axelera (`1f9d`).
>
> Once a domain is settled, add it to `vendors` here or to
> `pkg/vendors/vendors.go`. The name comes from `pci.ids` either way.

## `resourceName` — the device-plugin compatibility label

The extended resource name the old `kubevirt-xpu-device-plugin` registered is
republished as a ResourceSlice attribute, so a cluster can correlate DRA
devices with the resources it used to request. Product catalogue entries key
off these strings, so **the algorithm must not be improved**.

```
resourceName = "<domain>/<SUFFIX>"
```

`SUFFIX` is the `pci.ids` device string with, in order (ported from
`pkg/device_plugin/device_plugin.go:getDeviceName`):

1. upper-case → 2. `/` → `_` → 3. `.` → `_` → 4. whitespace runs → a single
`_` → 5. drop anything outside `[a-zA-Z0-9_.]`

A device absent from `pci.ids` falls back to the raw device ID, as the plugin
did.

Example: `10de:2330` → `GH100 [H100 SXM5 80GB]` →
`nvidia.com/GH100_H100_SXM5_80GB`

A differential test in `pkg/pciids` runs a verbatim port of the old algorithm
against the real `data/pci.ids` and compares, so a migrating node cannot
silently rename its resources.

## Published attributes

Standard, domain-qualified — shared with other DRA drivers, which is what lets
a claim require a GPU and a NIC behind the same PCIe root complex:

- `resource.kubernetes.io/pciBusID`
- `resource.kubernetes.io/pcieRoot`

Driver attributes, **unqualified**: `vendorID`, `deviceID`,
`subsystemVendorID`, `subsystemDeviceID`, `pciClass`, `productName`,
`vendorName`, `numaNode`, `iommuGroup`, `iommufdSupported`,
`parentPciAddress`, `sriovVF`, `driver`, `resourceName`; and for mediated
devices `mdevUUID`, `mdevType`, `mdevTypeName`.

**Do not prefix the driver attributes with `xpu.petasus.io/`** — KubeVirt looks
up the mediated device UUID under the bare name `mdevUUID`.

In a claim's CEL selector they are reached through the driver's domain:

```cel
device.attributes["xpu.petasus.io"].deviceID == "2330"
device.attributes["xpu.petasus.io"].pciClass == "0302"
device.attributes["resource.kubernetes.io"].pcieRoot == "pci0000:00"
```

String values are truncated to the API's 64-character limit. `numaNode` is
omitted when the device reports `-1`.

---

# Values

## Image

| Key | Default | Description |
|---|---|---|
| `image.repository` | `quay.io/edgestack/dra-driver-xpu` | |
| `image.tag` | `""` | Falls back to the chart's `appVersion`. In the repository that is `main`, the tag CI republishes on every push to the default branch, so installing from a checkout works. Publishing overrides it with the packaged commit's `git describe`, so a chart pulled from the shared repository pins an immutable image. It is deliberately not the chart version — nothing builds an image tagged `0.1.0`. |
| `image.pullPolicy` | `IfNotPresent` | |
| `imagePullSecrets` | `[]` | |

## Identity

| Key | Default | Description |
|---|---|---|
| `driverName` | `xpu.petasus.io` | The DRA driver name and the CDI vendor. Changing it means every `DeviceClass` and `ResourceClaim` in the cluster has to follow. |
| `nameOverride` | `""` | |
| `fullnameOverride` | `""` | Use to run more than one release, e.g. one per node profile. |
| `serviceAccount.create` | `true` | |
| `serviceAccount.name` | `""` | |
| `serviceAccount.annotations` | `{}` | |
| `deviceClass.create` | `true` | Creates a catch-all `DeviceClass` selecting everything this driver publishes. Production clusters usually manage narrower classes separately; the driver never depends on a particular class name. |
| `deviceClass.name` | `""` | Defaults to `driverName`. |

## Device selection

| Key | Default | Description |
|---|---|---|
| `config.vendors` | `[]` | The allowlist. Empty means no ConfigMap is created and the driver uses its built-in defaults. Setting it restricts publishing to the vendors listed. |
| `config.existingConfigMap` | `""` | Use a ConfigMap managed outside this chart. Its key must be `config.yaml`. |
| `config.mdev.enabled` | `true` | Discover and publish mediated devices. A PCI function carrying mdevs is in vGPU mode, so **the parent is not published, only its mdev instances**. With this off the parent is excluded and the reason is logged. |
| `config.iommufd` | `auto` | `auto` exposes whichever VFIO access paths the host provides; `enabled` requires IOMMU-FD and fails preparation without it; `disabled` sticks to the group-based path. KubeVirt v1.9.0 emits no iommufd-related XML, so libvirt and QEMU choose — the driver only exposes the character devices. |

## Runtime

| Key | Default | Description |
|---|---|---|
| `resyncInterval` | `60s` | How often the node's hardware is rediscovered. |
| `configPollInterval` | `10s` | How often the allowlist file is re-read. A ConfigMap update swaps a symlink, so it is polled rather than watched. |
| `logLevel` | `2` | klog verbosity. Per-device events are logged at 2. |
| `hostPaths.kubeletPlugins` | `/var/lib/kubelet/plugins` | |
| `hostPaths.kubeletPluginsRegistry` | `/var/lib/kubelet/plugins_registry` | |
| `hostPaths.cdi` | `/var/run/cdi` | Where the container runtime scans for CDI specs. |
| `hostPaths.dev` | `/dev` | |
| `hostPaths.sys` | `/sys` | Mounted read-only. |

## Scheduling

| Key | Default | Description |
|---|---|---|
| `nodeSelector` | `{}` | Optional: a node with no matching device simply publishes an empty pool. |
| `affinity` | `{}` | |
| `tolerations` | `CriticalAddonsOnly` | |
| `priorityClassName` | `system-node-critical` | |
| `resources` | 50m / 64Mi requests, 256Mi limit | |
| `podAnnotations`, `podLabels` | `{}` | |

---

## Changing the allowlist

The driver watches its configuration file, so editing the ConfigMap takes
effect within `configPollInterval` — no rollout, and running VMs are
undisturbed. Deleting it reverts to the built-in defaults, also without a
restart, because absence is a state the watcher tracks like any other.

## Per-node-profile installs

Rarely needed; the default covers a mixed fleet. When a node really does need
a different policy, split the release:

```yaml
config:
  existingConfigMap: dra-xpu-config-vgpu
nodeSelector:
  petasus.io/gpu-mode: vgpu
fullnameOverride: dra-driver-xpu-vgpu
```

## See also

- [`docs/CONTRACT.md`](../../../docs/CONTRACT.md) — the KubeVirt consumer
  contract this driver implements, and the source it was read from.
- [`docs/SRIOV-INTEGRATION.md`](../../../docs/SRIOV-INTEGRATION.md) — what it
  takes to put a GPU from this chart and an SR-IOV VF from
  `dra-driver-sriov` behind one PCIe root complex in the same VM. The
  `pcieRoot` attribute above is this driver's half of that; the other half is
  a question about KubeVirt.
