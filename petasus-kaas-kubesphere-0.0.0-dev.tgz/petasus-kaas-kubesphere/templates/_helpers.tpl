{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "ks-core.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "ks-core.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "ks-core.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "ks-core.labels" -}}
helm.sh/chart: {{ include "ks-core.chart" . }}
{{ include "ks-core.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "ks-core.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ks-core.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "ks-core.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "ks-core.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Create the name of the secret of sa token.
*/}}
{{- define "ks-core.serviceAccountTokenName" -}}
{{-  printf "%s-%s" ( include "ks-core.serviceAccountName" . )   "sa-token" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
The console's image tag. The dev channel's chart (appVersion dev) runs the console's :dev,
as it runs this repository's; a released chart runs the console release its values name.
*/}}
{{- define "ks-core.consoleTag" -}}
{{- if eq .Chart.AppVersion "dev" -}}
dev
{{- else -}}
{{- .Values.image.ks_console_tag | default .Chart.AppVersion -}}
{{- end -}}
{{- end }}

{{/*
The pull policy of ks-apiserver, ks-controller-manager and the console: Always on the dev
channel, where every build is published as :dev and a node's copy may be an old one.
*/}}
{{- define "ks-core.imagePullPolicy" -}}
{{- if eq .Chart.AppVersion "dev" -}}
Always
{{- else -}}
{{- .Values.image.pullPolicy -}}
{{- end -}}
{{- end }}

{{/*
The admin user's password for account.yaml, which makes the user only when there is none:
adminPassword as it is, either a bcrypt hash (what petasus-resource-manager passes) or the
password, which KubeSphere's user controller hashes; without it KubeSphere's default, the
hash of P@88w0rd. A hash must go through unchanged: hashed again here, it would be the
password of a password nobody knows.
*/}}
{{- define "getOrDefaultPass" }}
{{- $pws := (lookup "iam.kubesphere.io/v1alpha2" "User" "" "admin") -}}
{{- if $pws }}
{{- $pws.spec.password  -}}
{{- else -}}
{{- if not .Values.adminPassword -}}
{{- printf "$2a$10$zcHepmzfKPoxCVCYZr5K7ORPZZ/ySe9p/7IUb/8u./xHrnSX2LOCO" -}}
{{- else -}}
{{- printf "%s" .Values.adminPassword -}}
{{- end -}}
{{- end -}}
{{- end }}
